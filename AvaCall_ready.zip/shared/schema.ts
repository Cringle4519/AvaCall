import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const rooms = pgTable("rooms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  isActive: boolean("is_active").default(true),
});

export const participants = pgTable("participants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").references(() => rooms.id),
  userId: varchar("user_id").references(() => users.id),
  joinedAt: timestamp("joined_at").defaultNow(),
  leftAt: timestamp("left_at"),
  isActive: boolean("is_active").default(true),
  // PIRP extensions
  role: text("role").default("participant"), // "host" | "participant"
  currentLevel: integer("current_level").default(0), // 0, 25, 50, 75, 100
  trustScore: integer("trust_score").default(0),
});

// PIRP consent management
export const consents = pgTable("consents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").references(() => rooms.id),
  fromUserId: varchar("from_user_id").references(() => users.id),
  toUserId: varchar("to_user_id").references(() => users.id),
  levelRequested: integer("level_requested").notNull(),
  status: text("status").notNull().default("pending"), // "pending" | "approved" | "rejected"
  createdAt: timestamp("created_at").defaultNow(),
  decidedAt: timestamp("decided_at"),
});

// PIRP trust scoring events
export const trustEvents = pgTable("trust_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").references(() => rooms.id),
  userId: varchar("user_id").references(() => users.id),
  delta: integer("delta").notNull(), // +10, -20, etc
  reason: text("reason").notNull(),
  newScore: integer("new_score").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// PIRP reveal audit logs
export const revealLogs = pgTable("reveal_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").references(() => rooms.id),
  userId: varchar("user_id").references(() => users.id),
  level: integer("level").notNull(),
  approvedBy: varchar("approved_by").references(() => users.id),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Chat messages for in-call communication
export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").references(() => rooms.id),
  userId: varchar("user_id").references(() => users.id),
  message: text("message").notNull(),
  messageType: text("message_type").default("text"), // "text" | "system" | "join" | "leave"
  timestamp: timestamp("timestamp").defaultNow(),
});

// Avatar management for PIRP staged reveal
export const userAvatars = pgTable("user_avatars", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  avatarType: text("avatar_type").notNull(), // "3d" | "stylized"
  avatarUrl: text("avatar_url").notNull(), // Generated avatar URL
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertRoomSchema = createInsertSchema(rooms).pick({
  name: true,
  createdBy: true,
});

export const insertParticipantSchema = createInsertSchema(participants).pick({
  roomId: true,
  userId: true,
  role: true,
  currentLevel: true,
  trustScore: true,
});

// PIRP insert schemas
export const insertConsentSchema = createInsertSchema(consents).pick({
  roomId: true,
  fromUserId: true,
  toUserId: true,
  levelRequested: true,
  status: true,
});

export const insertTrustEventSchema = createInsertSchema(trustEvents).pick({
  roomId: true,
  userId: true,
  delta: true,
  reason: true,
  newScore: true,
});

export const insertRevealLogSchema = createInsertSchema(revealLogs).pick({
  roomId: true,
  userId: true,
  level: true,
  approvedBy: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  roomId: true,
  userId: true,
  message: true,
  messageType: true,
});

export const insertUserAvatarSchema = createInsertSchema(userAvatars).pick({
  userId: true,
  avatarType: true,
  avatarUrl: true,
  isActive: true,
});

// Type exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type Room = typeof rooms.$inferSelect;
export type InsertParticipant = z.infer<typeof insertParticipantSchema>;
export type Participant = typeof participants.$inferSelect;

// PIRP types
export type InsertConsent = z.infer<typeof insertConsentSchema>;
export type Consent = typeof consents.$inferSelect;
export type InsertTrustEvent = z.infer<typeof insertTrustEventSchema>;
export type TrustEvent = typeof trustEvents.$inferSelect;
export type InsertRevealLog = z.infer<typeof insertRevealLogSchema>;
export type RevealLog = typeof revealLogs.$inferSelect;

// Chat types
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

// Avatar types
export type InsertUserAvatar = z.infer<typeof insertUserAvatarSchema>;
export type UserAvatar = typeof userAvatars.$inferSelect;
