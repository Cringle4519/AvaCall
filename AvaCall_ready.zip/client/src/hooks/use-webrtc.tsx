import { useRef, useState, useCallback, useEffect } from "react";
import { useWebSocket } from "./use-websocket";
import { WebRTCManager } from "@/lib/webrtc";
import { requestWakeLock, releaseWakeLock } from "@/utils/wakeLock";

export function useWebRTC(iceServers?: RTCIceServer[], onRevealMessage?: (data: any) => void) {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const [webrtcManager] = useState(() => new WebRTCManager(iceServers));
  const [isConnected, setIsConnected] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [participants, setParticipants] = useState(0);
  const [currentRoomId, setCurrentRoomId] = useState<string | null>(null);
  const [currentClientId, setCurrentClientId] = useState<string | null>(null);
  const [activePeerConnection, setActivePeerConnection] = useState<RTCPeerConnection | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);

  const { socket, isSocketConnected, sendMessage } = useWebSocket();

  // Setup wake lock reacquisition only during active calls
  useEffect(() => {
    if (!('wakeLock' in navigator)) return;

    const handleVisibilityChange = async () => {
      // Only reacquire wake lock if there's an active call
      if (document.visibilityState === 'visible' && (isConnected || currentRoomId)) {
        console.log('Page became visible during call - reacquiring wake lock');
        await requestWakeLock();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Cleanup listener on unmount
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isConnected, currentRoomId]);

  useEffect(() => {
    if (!socket) return;

    const handleMessage = (data: any) => {
      switch (data.type) {
        case 'joined-room':
          setIsConnected(true);
          setParticipants(data.participants.length + 1);
          
          // Forward server-assigned pirpUserId to parent for secure authentication
          if (data.pirpUserId && onRevealMessage) {
            onRevealMessage({
              type: 'PIRP_ASSIGNED', 
              pirpUserId: data.pirpUserId
            });
          }
          
          // Initialize WebRTC offers to existing participants
          data.participants.forEach((participantId: string) => {
            webrtcManager.createOffer(participantId);
          });
          break;

        case 'user-joined':
          setParticipants(prev => prev + 1);
          // Update active peer connection when new users join
          setActivePeerConnection(webrtcManager.getActivePeerConnection());
          break;

        case 'user-left':
          setParticipants(prev => Math.max(0, prev - 1));
          webrtcManager.removePeer(data.clientId);
          // Update active peer connection when users leave
          setActivePeerConnection(webrtcManager.getActivePeerConnection());
          break;

        case 'webrtc-offer':
          webrtcManager.handleOffer(data.senderId, data.offer);
          // Update active peer connection after handling offer
          setActivePeerConnection(webrtcManager.getActivePeerConnection());
          break;

        case 'webrtc-answer':
          webrtcManager.handleAnswer(data.senderId, data.answer);
          // Update active peer connection after handling answer
          setActivePeerConnection(webrtcManager.getActivePeerConnection());
          break;

        case 'webrtc-ice-candidate':
          webrtcManager.handleIceCandidate(data.senderId, data.candidate);
          break;

        case 'REVEAL_REQUEST':
        case 'REVEAL_DECISION':  
        case 'REVEAL_LEVEL':
          // Forward reveal messages to parent component for handling
          // These will be handled by the video call component's reveal logic
          if (onRevealMessage) {
            onRevealMessage(data);
          }
          break;
      }
    };

    socket.addEventListener('message', (event: MessageEvent) => {
      const data = JSON.parse(event.data);
      handleMessage(data);
    });

    // Setup WebRTC callbacks
    webrtcManager.onOffer = (targetId: string, offer: RTCSessionDescriptionInit) => {
      sendMessage({
        type: 'webrtc-offer',
        targetId,
        offer
      });
    };

    webrtcManager.onAnswer = (targetId: string, answer: RTCSessionDescriptionInit) => {
      sendMessage({
        type: 'webrtc-answer',
        targetId,
        answer
      });
    };

    webrtcManager.onIceCandidate = (targetId: string, candidate: RTCIceCandidateInit) => {
      sendMessage({
        type: 'webrtc-ice-candidate',
        targetId,
        candidate
      });
    };

    webrtcManager.onRemoteStream = (stream: MediaStream) => {
      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = stream;
      }
    };

    return () => {
      webrtcManager.cleanup();
    };
  }, [socket, sendMessage]);

  const initializeMedia = async (): Promise<boolean> => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 1280 }, 
          height: { ideal: 720 }, 
          frameRate: { ideal: 30, max: 60 } 
        },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });

      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }

      webrtcManager.setLocalStream(stream);
      setLocalStream(stream);
      return true;
    } catch (error) {
      console.error('Failed to access media devices:', error);
      return false;
    }
  };

  const startCall = useCallback(async (roomId: string): Promise<boolean> => {
    if (!isSocketConnected) return false;

    const mediaInitialized = await initializeMedia();
    if (!mediaInitialized) return false;

    const clientId = Math.random().toString(36).substring(2, 15);
    setCurrentRoomId(roomId);
    setCurrentClientId(clientId);

    // Request wake lock to prevent screen dimming during call
    await requestWakeLock();

    sendMessage({
      type: 'join-room',
      roomId,
      clientId
    });

    return true;
  }, [isSocketConnected, sendMessage]);

  const joinCall = useCallback(async (roomId: string): Promise<boolean> => {
    return startCall(roomId);
  }, [startCall]);

  const endCall = useCallback(() => {
    if (currentRoomId) {
      sendMessage({
        type: 'leave-room'
      });
    }

    // Release wake lock when call ends
    releaseWakeLock();

    webrtcManager.cleanup();
    setIsConnected(false);
    setParticipants(0);
    setCurrentRoomId(null);
    setCurrentClientId(null);
    setActivePeerConnection(null);
    setLocalStream(null);

    // Stop local media
    if (localVideoRef.current?.srcObject) {
      const stream = localVideoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      localVideoRef.current.srcObject = null;
    }
  }, [currentRoomId, sendMessage]);

  const toggleMicrophone = useCallback(() => {
    const stream = localVideoRef.current?.srcObject as MediaStream;
    if (stream) {
      const audioTrack = stream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMuted(!audioTrack.enabled);
      }
    }
  }, []);

  const toggleCamera = useCallback(() => {
    const stream = localVideoRef.current?.srcObject as MediaStream;
    if (stream) {
      const videoTrack = stream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsCameraOn(videoTrack.enabled);
      }
    }
  }, []);

  const shareScreen = useCallback(async () => {
    try {
      const screenStream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true
      });

      // Replace video track in all peer connections
      webrtcManager.replaceVideoTrack(screenStream.getVideoTracks()[0]);

      // When screen sharing stops, revert to camera
      screenStream.getVideoTracks()[0].onended = async () => {
        const cameraStream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true
        });
        webrtcManager.replaceVideoTrack(cameraStream.getVideoTracks()[0]);
      };
    } catch (error) {
      console.error('Failed to start screen sharing:', error);
    }
  }, []);

  // Add function to update local stream (for voice enhancement)
  const updateLocalStream = useCallback((newStream: MediaStream) => {
    setLocalStream(newStream);
    webrtcManager.setLocalStream(newStream);
  }, []);

  return {
    localVideoRef,
    remoteVideoRef,
    isConnected,
    isMuted,
    isCameraOn,
    participants,
    peerConnection: activePeerConnection, // Use stateful activePeerConnection instead of webrtcManager.getActivePeerConnection()
    localStream, // Add localStream for lip-sync integration
    sendMessage, // Expose sendMessage for reveal system
    currentRoomId, // Expose currentRoomId for reveal system
    currentClientId, // Expose currentClientId for chat functionality
    updateLocalStream, // Add function to update local stream state
    startCall,
    joinCall,
    endCall,
    toggleMicrophone,
    toggleCamera,
    shareScreen
  };
}
