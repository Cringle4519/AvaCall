import { useEffect, useRef, useCallback, useState } from 'react';
import { VirtualBackground } from '@/lib/virtual-background';

interface UseVirtualBackgroundProps {
  videoElement: HTMLVideoElement | null;
  selectedBackground: string;
  selectedBackgroundUrl: string;
  blurIntensity: number;
  isEnabled: boolean;
}

export function useVirtualBackground({
  videoElement,
  selectedBackground,
  selectedBackgroundUrl,
  blurIntensity,
  isEnabled
}: UseVirtualBackgroundProps) {
  const virtualBgRef = useRef<VirtualBackground | null>(null);
  const processedStreamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  
  // Use state for reactivity while keeping refs for performance
  const [processedStream, setProcessedStream] = useState<MediaStream | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Initialize virtual background processor
  useEffect(() => {
    if (!isEnabled || !videoElement) {
      cleanup();
      return;
    }

    virtualBgRef.current = new VirtualBackground(640, 480);
    return cleanup;
  }, [isEnabled, videoElement]);

  // Set background image when URL changes
  useEffect(() => {
    if (!virtualBgRef.current || !selectedBackgroundUrl || selectedBackground === 'blur') return;

    virtualBgRef.current.setBackgroundImage(selectedBackgroundUrl).catch(error => {
      console.error('Failed to set background image:', error);
    });
  }, [selectedBackground, selectedBackgroundUrl]);

  const cleanup = useCallback(() => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    
    if (processedStreamRef.current) {
      processedStreamRef.current.getTracks().forEach(track => track.stop());
      processedStreamRef.current = null;
    }
    
    if (virtualBgRef.current) {
      virtualBgRef.current.destroy();
      virtualBgRef.current = null;
    }
    
    // Update state for reactivity
    setProcessedStream(null);
    setIsProcessing(false);
  }, []);

  // Enhanced processing loop with stream reuse
  useEffect(() => {
    if (!isEnabled || !videoElement || !virtualBgRef.current) {
      cleanup();
      return;
    }

    let canvas: HTMLCanvasElement;
    let stream: MediaStream;

    const processFrame = () => {
      if (!virtualBgRef.current || !videoElement || videoElement.videoWidth === 0) {
        animationFrameRef.current = requestAnimationFrame(processFrame);
        return;
      }

      try {
        // Apply background effect - returns the same canvas reference
        canvas = virtualBgRef.current.applyBackground(
          videoElement,
          selectedBackground,
          blurIntensity
        );

        // Create stream once and reuse it
        if (!processedStreamRef.current) {
          stream = canvas.captureStream(30);
          processedStreamRef.current = stream;
          
          // Update state for reactivity
          setProcessedStream(stream);
          setIsProcessing(true);
        }
      } catch (error) {
        console.error('Error processing video frame:', error);
      }

      animationFrameRef.current = requestAnimationFrame(processFrame);
    };

    // Start processing when video is ready
    const startProcessing = () => {
      if (videoElement.readyState >= 2) { // HAVE_CURRENT_DATA
        processFrame();
      } else {
        videoElement.addEventListener('loadeddata', processFrame, { once: true });
      }
    };

    startProcessing();
    return cleanup;
  }, [isEnabled, videoElement, selectedBackground, selectedBackgroundUrl, blurIntensity, cleanup]);

  return {
    processedStream,
    isProcessing
  };
}