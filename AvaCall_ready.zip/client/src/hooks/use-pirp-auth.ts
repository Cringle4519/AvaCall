import { useState, useCallback, useEffect } from "react";
import { apiRequest, setPirpToken } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface PirpUser {
  roomId: string;
  userId: string;
  role: string;
  currentLevel: number;
  trustScore: number;
}

export function usePirpAuth() {
  const [pirpUser, setPirpUser] = useState<PirpUser | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const { toast } = useToast();

  // Load authentication state from localStorage on mount
  useEffect(() => {
    const savedToken = localStorage.getItem('pirp_token');
    const savedUser = localStorage.getItem('pirp_user');
    
    if (savedToken && savedUser) {
      try {
        const user = JSON.parse(savedUser);
        setPirpToken(savedToken);
        setPirpUser(user);
        setIsAuthenticated(true);
      } catch (error) {
        console.error('Failed to restore PIRP auth state:', error);
        // Clear invalid data
        localStorage.removeItem('pirp_token');
        localStorage.removeItem('pirp_user');
      }
    }
  }, []);

  const authenticate = useCallback(async (roomId: string, userId: string) => {
    try {
      const response = await apiRequest('POST', '/api/auth/pirp-token', { roomId, userId });
      const data = await response.json();
      
      // Store the JWT token and user data
      setPirpToken(data.token);
      setPirpUser(data.user);
      setIsAuthenticated(true);
      
      // Persist to localStorage for cross-tab access
      localStorage.setItem('pirp_token', data.token);
      localStorage.setItem('pirp_user', JSON.stringify(data.user));
      
      return { success: true, user: data.user };
    } catch (error: any) {
      console.error('PIRP authentication failed:', error);
      
      toast({
        title: "Authentication Failed",
        description: error.message || "Could not authenticate for privacy controls",
        variant: "destructive",
      });
      
      return { success: false, error: error.message };
    }
  }, [toast]);

  const logout = useCallback(() => {
    setPirpToken(null);
    setPirpUser(null);
    setIsAuthenticated(false);
    
    // Clear localStorage
    localStorage.removeItem('pirp_token');
    localStorage.removeItem('pirp_user');
  }, []);

  return {
    pirpUser,
    isAuthenticated,
    authenticate,
    logout
  };
}