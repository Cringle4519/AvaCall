import { useEffect } from 'react';
export function useSceneHotkeys(setSceneId: (id: string)=>void) {
  useEffect(() => {
    let last = 0, count = 0;
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase(), now = Date.now();
      if (k === 'c') { count = (now - last < 350) ? count + 1 : 1; last = now; if (count >= 2) setSceneId('cabin-call'); return; }
      if (k === 'r') setSceneId('rooftop-night');
      if (k === 'n') setSceneId('neon-city');
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [setSceneId]);
}