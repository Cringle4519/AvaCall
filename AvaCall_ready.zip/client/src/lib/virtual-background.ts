export class VirtualBackground {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private backgroundImage: HTMLImageElement | null = null;

  constructor(width: number = 640, height: number = 480) {
    this.canvas = document.createElement('canvas');
    this.canvas.width = width;
    this.canvas.height = height;
    this.ctx = this.canvas.getContext('2d')!;
  }

  setBackgroundImage(imageUrl: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        this.backgroundImage = img;
        resolve();
      };
      img.onerror = reject;
      img.src = imageUrl;
    });
  }

  applyBackground(
    videoFrame: VideoFrame | HTMLVideoElement,
    backgroundType: string = 'blur',
    blurIntensity: number = 75
  ): HTMLCanvasElement {
    // Clear canvas
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    if (backgroundType === 'blur') {
      this.applyBlurBackground(videoFrame, blurIntensity);
    } else if (this.backgroundImage) {
      this.applyImageBackground(videoFrame);
    } else {
      // Fallback: just draw the original video
      if (videoFrame instanceof HTMLVideoElement) {
        this.ctx.drawImage(videoFrame, 0, 0, this.canvas.width, this.canvas.height);
      }
    }

    return this.canvas;
  }

  private applyBlurBackground(
    videoFrame: VideoFrame | HTMLVideoElement,
    intensity: number
  ) {
    // Draw the original video frame
    if (videoFrame instanceof HTMLVideoElement) {
      this.ctx.filter = `blur(${Math.max(0, intensity / 10)}px)`;
      this.ctx.drawImage(videoFrame, 0, 0, this.canvas.width, this.canvas.height);
      this.ctx.filter = 'none';
    }
  }

  private applyImageBackground(videoFrame: VideoFrame | HTMLVideoElement) {
    if (!this.backgroundImage) return;

    // Draw background image
    this.ctx.drawImage(
      this.backgroundImage,
      0, 0,
      this.canvas.width,
      this.canvas.height
    );

    // In a real implementation, you would use ML models like BodyPix or MediaPipe
    // to segment the person from the background and composite them over the new background.
    // For this demo, we'll just overlay the video with reduced opacity to simulate the effect.
    
    if (videoFrame instanceof HTMLVideoElement) {
      this.ctx.globalAlpha = 0.8;
      this.ctx.drawImage(videoFrame, 0, 0, this.canvas.width, this.canvas.height);
      this.ctx.globalAlpha = 1.0;
    }
  }

  removeBackground() {
    this.backgroundImage = null;
  }

  getCanvas(): HTMLCanvasElement {
    return this.canvas;
  }

  destroy() {
    this.backgroundImage = null;
  }
}
