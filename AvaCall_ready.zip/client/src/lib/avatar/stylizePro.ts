// Professional portrait-like stylization (no cartoon look):
// - gentle skin smoothing
// - subtle color grading  
// - mild clarity/sharpen
// - circular avatar crop

export async function stylizeProLikeness(srcUrl: string, size = 512): Promise<string> {
  console.log('🟠 Processing stylized avatar...');
  
  try {
    const img = await loadImage(srcUrl);
    console.log('Image loaded, dimensions:', img.width, 'x', img.height);
    
    const { canvas, ctx } = makeCanvas(size, size);

    // Center-crop to square
    const s = Math.min(img.width, img.height);
    const sx = (img.width - s) / 2, sy = (img.height - s) / 2;
    ctx.drawImage(img, sx, sy, s, s, 0, 0, size, size);

    // Apply professional stylization effects
    
    // 1) Color enhancement
    const imageData = ctx.getImageData(0, 0, size, size);
    const data = imageData.data;
    
    for (let i = 0; i < data.length; i += 4) {
      // Enhance contrast and warmth
      data[i] = Math.min(255, data[i] * 1.15);     // Red boost
      data[i + 1] = Math.min(255, data[i + 1] * 1.05); // Green slight boost
      data[i + 2] = Math.min(255, data[i + 2] * 0.95); // Blue slight reduce
    }
    
    ctx.putImageData(imageData, 0, 0);

    // 2) Gentle blur for smoothing
    blur(ctx, size, size, 1);

    // 3) Circular crop for avatar
    const out = makeCanvas(size, size);
    out.ctx.drawImage(canvas, 0, 0);
    
    out.ctx.globalCompositeOperation = 'destination-in';
    out.ctx.fillStyle = '#ffffff';
    out.ctx.beginPath();
    out.ctx.arc(size / 2, size / 2, size / 2 - 2, 0, Math.PI * 2);
    out.ctx.fill();

    console.log('🟠 Stylized avatar processed successfully');
    return out.canvas.toDataURL('image/png');
  } catch (error) {
    console.error('Error in stylized processing:', error);
    throw error;
  }
}

// Utility functions
function makeCanvas(w: number, h: number) { 
  const c = document.createElement('canvas'); 
  c.width = w; 
  c.height = h; 
  const ctx = c.getContext('2d')!; 
  return { canvas: c, ctx }; 
}

function loadImage(url: string): Promise<HTMLImageElement> { 
  return new Promise<HTMLImageElement>((res, rej) => { 
    const i = new Image(); 
    i.crossOrigin = 'anonymous'; 
    i.onload = () => res(i); 
    i.onerror = rej; 
    i.src = url; 
  }); 
}

// Tiny separable blur
function blur(ctx: CanvasRenderingContext2D, w: number, h: number, r = 1) {
  const src = ctx.getImageData(0, 0, w, h); 
  const dst = ctx.createImageData(w, h);
  const a = new Uint8ClampedArray(src.data); 
  const d = dst.data;
  
  const pass = (horiz: boolean) => {
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        let rsum = 0, gsum = 0, bsum = 0, asum = 0, count = 0;
        for (let k = -r; k <= r; k++) {
          const xx = horiz ? Math.min(w - 1, Math.max(0, x + k)) : x;
          const yy = horiz ? y : Math.min(h - 1, Math.max(0, y + k));
          const idx = (yy * w + xx) * 4;
          rsum += a[idx]; gsum += a[idx + 1]; bsum += a[idx + 2]; asum += a[idx + 3]; count++;
        }
        const id = (y * w + x) * 4;
        d[id] = rsum / count; d[id + 1] = gsum / count; d[id + 2] = bsum / count; d[id + 3] = asum / count;
      }
    }
    a.set(d);
  };
  
  pass(true); 
  pass(false);
  ctx.putImageData(dst, 0, 0);
}

// Color grade: lift shadows, adjust temp/sat
function grade(ctx: CanvasRenderingContext2D, w: number, h: number, { lift, temp, sat }: { lift: number; temp: number; sat: number }) {
  const img = ctx.getImageData(0, 0, w, h); 
  const d = img.data;
  
  for (let i = 0; i < d.length; i += 4) {
    // lift shadows a touch
    d[i] = clamp(d[i] + lift);
    d[i + 1] = clamp(d[i + 1] + lift);
    d[i + 2] = clamp(d[i + 2] + lift);
    
    // temp: positive -> cooler highlights
    d[i] = clamp(d[i] - temp * 0.5);
    d[i + 2] = clamp(d[i + 2] + temp);
    
    // saturation
    const r = d[i], g = d[i + 1], b = d[i + 2];
    const avg = (r + g + b) / 3;
    d[i] = clamp(avg + (r - avg) * sat);
    d[i + 1] = clamp(avg + (g - avg) * sat);
    d[i + 2] = clamp(avg + (b - avg) * sat);
  }
  
  ctx.putImageData(img, 0, 0);
  
  function clamp(v: number) { 
    return v < 0 ? 0 : v > 255 ? 255 : v | 0; 
  }
}

// Unsharp mask
function unsharpMask(ctx: CanvasRenderingContext2D, w: number, h: number, amount = 1, thresh = 0.3) {
  const src = ctx.getImageData(0, 0, w, h); 
  const blurred = new ImageData(new Uint8ClampedArray(src.data), w, h);
  const c = document.createElement('canvas'); 
  c.width = w; 
  c.height = h; 
  const x = c.getContext('2d')!; 
  x.putImageData(blurred, 0, 0);
  
  // Small blur
  const b = x.getImageData(0, 0, w, h); 
  const bd = b.data;
  for (let i = 0; i < 3; i++) boxBlur(bd, w, h);
  
  const d = src.data;
  for (let i = 0; i < d.length; i += 4) {
    const dr = d[i] - bd[i], dg = d[i + 1] - bd[i + 1], db = d[i + 2] - bd[i + 2];
    const mag = Math.max(Math.abs(dr), Math.abs(dg), Math.abs(db)) / 255;
    if (mag > thresh) {
      d[i] = clamp(d[i] + dr * amount);
      d[i + 1] = clamp(d[i + 1] + dg * amount);
      d[i + 2] = clamp(d[i + 2] + db * amount);
    }
  }
  
  ctx.putImageData(src, 0, 0);
  
  function clamp(v: number) { 
    return v < 0 ? 0 : v > 255 ? 255 : v | 0; 
  }
  
  function boxBlur(p: Uint8ClampedArray, w: number, h: number) {
    // Single-pass box blur for speed
    const tmp = new Uint8ClampedArray(p.length);
    const kernel = 1, size = kernel * 2 + 1;
    
    // Horizontal pass
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        let rs = 0, gs = 0, bs = 0, as = 0;
        for (let k = -kernel; k <= kernel; k++) {
          const xx = Math.min(w - 1, Math.max(0, x + k)); 
          const idx = (y * w + xx) * 4;
          rs += p[idx]; gs += p[idx + 1]; bs += p[idx + 2]; as += p[idx + 3];
        }
        const id = (y * w + x) * 4; 
        tmp[id] = rs / size; tmp[id + 1] = gs / size; tmp[id + 2] = bs / size; tmp[id + 3] = as / size;
      }
    }
    
    // Vertical pass
    for (let x = 0; x < w; x++) {
      for (let y = 0; y < h; y++) {
        let rs = 0, gs = 0, bs = 0, as = 0;
        for (let k = -kernel; k <= kernel; k++) {
          const yy = Math.min(h - 1, Math.max(0, y + k)); 
          const idx = (yy * w + x) * 4;
          rs += tmp[idx]; gs += tmp[idx + 1]; bs += tmp[idx + 2]; as += tmp[idx + 3];
        }
        const id = (y * w + x) * 4; 
        p[id] = rs / size; p[id + 1] = gs / size; p[id + 2] = bs / size; p[id + 3] = as / size;
      }
    }
  }
}

// Vignette effect
function vignette(ctx: CanvasRenderingContext2D, w: number, h: number, intensity = 0.2) {
  const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.max(w, h) * 0.65);
  g.addColorStop(0, 'rgba(0,0,0,0)');
  g.addColorStop(1, `rgba(0,0,0,${intensity})`);
  ctx.fillStyle = g; 
  ctx.fillRect(0, 0, w, h);
}