// 3D Avatar Likeness with Three.js
// Loads a GLTF head model if provided; otherwise falls back to a smooth
// sphere with your photo projected. Subtle rotation = "alive" preview.

import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

type Opts = { headModelUrl?: string }; // e.g., import.meta.env.VITE_HEAD_MODEL_URL

export function mount3DLikeness(el: HTMLDivElement, photoUrl: string, opts: Opts = {}) {
  const W = el.clientWidth || 320, H = el.clientHeight || 320;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(35, W / H, 0.1, 100);
  camera.position.z = 3;

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setSize(W, H);
  renderer.setClearColor(0x000000, 0); // Transparent background
  el.innerHTML = '';
  el.appendChild(renderer.domElement);

  // Lighting setup
  const light1 = new THREE.DirectionalLight(0xffffff, 1.0); 
  light1.position.set(2, 2, 2); 
  scene.add(light1);
  const light2 = new THREE.AmbientLight(0xffffff, 0.4); 
  scene.add(light2);

  const tex = new THREE.TextureLoader().load(photoUrl);
  tex.colorSpace = THREE.SRGBColorSpace;

  let mesh: THREE.Object3D;

  const addFallback = () => {
    const geo = new THREE.SphereGeometry(1.0, 96, 96);
    const mat = new THREE.MeshStandardMaterial({ 
      map: tex, 
      roughness: 0.75, 
      metalness: 0.0 
    });
    mesh = new THREE.Mesh(geo, mat);
    scene.add(mesh);
  };

  if (opts.headModelUrl) {
    const loader = new GLTFLoader();
    loader.load(
      opts.headModelUrl,
      (gltf) => {
        mesh = gltf.scene;
        // Project photo as texture over the head material if possible
        mesh.traverse((o: any) => {
          if (o.isMesh) {
            o.material = new THREE.MeshStandardMaterial({
              map: tex, 
              roughness: 0.7, 
              metalness: 0.0
            });
          }
        });
        scene.add(mesh);
      },
      undefined,
      () => addFallback()
    );
  } else {
    addFallback();
  }

  let raf = 0;
  const animate = () => {
    if (mesh) {
      mesh.rotation.y += 0.005; // Gentle rotation for "alive" effect
    }
    raf = requestAnimationFrame(animate);
    renderer.render(scene, camera);
  };
  animate();

  // Cleanup function
  return () => {
    cancelAnimationFrame(raf);
    renderer.dispose();
    tex.dispose();
    if (mesh) {
      mesh.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          const meshChild = child as THREE.Mesh;
          meshChild.geometry?.dispose();
          if (Array.isArray(meshChild.material)) {
            meshChild.material.forEach(mat => mat.dispose());
          } else {
            meshChild.material?.dispose();
          }
        }
      });
    }
    scene.clear();
  };
}

// Utility function to capture 3D scene as PNG for avatar storage
export function capture3DAvatar(el: HTMLDivElement): string | null {
  console.log('🔵 Capturing 3D avatar...');
  
  const canvas = el.querySelector('canvas');
  if (!canvas) {
    console.warn('No 3D canvas found, creating fallback avatar');
    
    // Create a stylized fallback when 3D isn't available
    const fallbackCanvas = document.createElement('canvas');
    fallbackCanvas.width = 512;
    fallbackCanvas.height = 512;
    const ctx = fallbackCanvas.getContext('2d')!;
    
    // Create a gradient background
    const gradient = ctx.createRadialGradient(256, 256, 0, 256, 256, 256);
    gradient.addColorStop(0, '#4f46e5');
    gradient.addColorStop(1, '#1e1b4b');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 512, 512);
    
    // Add avatar placeholder
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(256, 200, 80, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.beginPath();
    ctx.arc(256, 350, 120, 0, Math.PI, true);
    ctx.fill();
    
    console.log('🔵 Returning 3D fallback avatar');
    return fallbackCanvas.toDataURL('image/png');
  }
  
  try {
    const dataUrl = canvas.toDataURL('image/png');
    console.log('🔵 3D avatar captured successfully');
    return dataUrl;
  } catch (error) {
    console.error('Error capturing 3D avatar:', error);
    return null;
  }
}