export class WebRTCManager {
  private peerConnections: Map<string, RTCPeerConnection> = new Map();
  private localStream: MediaStream | null = null;
  private screenStream: MediaStream | null = null;
  private cameraStream: MediaStream | null = null;
  private isScreenSharing: boolean = false;
  private pendingNegotiations: Set<string> = new Set();
  private configuration: RTCConfiguration;

  constructor(iceServers?: RTCIceServer[]) {
    // Build ICE servers configuration with TURN support
    const defaultServers = [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:stun2.l.google.com:19302' },
      { urls: 'stun:stun3.l.google.com:19302' }
    ];

    // Always try to add TURN servers from environment
    const turnServers = [];
    const turnUrls = import.meta.env.VITE_TURN_URLS;
    const turnUsername = import.meta.env.VITE_TURN_USERNAME;
    const turnCredential = import.meta.env.VITE_TURN_CREDENTIAL;
    
    if (turnUrls && turnUsername && turnCredential) {
      turnServers.push({
        urls: turnUrls.split(','),
        username: turnUsername,
        credential: turnCredential
      });
    }

    // Merge provided servers with defaults and TURN servers from environment
    const allServers = iceServers ? [...iceServers, ...turnServers] : [...defaultServers, ...turnServers];

    this.configuration = {
      iceServers: allServers,
      iceCandidatePoolSize: 10,
      bundlePolicy: 'max-bundle',
      rtcpMuxPolicy: 'require',
      iceTransportPolicy: 'all' // Use both STUN and TURN
    };
  }

  public onOffer?: (targetId: string, offer: RTCSessionDescriptionInit) => void;
  public onAnswer?: (targetId: string, answer: RTCSessionDescriptionInit) => void;
  public onIceCandidate?: (targetId: string, candidate: RTCIceCandidateInit) => void;
  public onRemoteStream?: (stream: MediaStream) => void;
  public onScreenShareEnded?: () => void;

  setLocalStream(stream: MediaStream) {
    this.localStream = stream;
    // Store as camera stream if not screen sharing
    if (!this.isScreenSharing) {
      this.cameraStream = stream;
    }
  }

  getLocalStream(): MediaStream | null {
    return this.localStream;
  }

  isCurrentlyScreenSharing(): boolean {
    return this.isScreenSharing;
  }

  private createPeerConnection(peerId: string): RTCPeerConnection {
    const pc = new RTCPeerConnection(this.configuration);

    // Add local stream tracks with enhanced simulcast and codec preferences
    if (this.localStream) {
      this.localStream.getTracks().forEach(track => {
        if (track.kind === 'video') {
          try {
            // Prefer VP9/AV1 for SVC support where available
            const codecs = RTCRtpSender.getCapabilities('video')?.codecs;
            let sendEncodings = [
              { rid: 'q', scaleResolutionDownBy: 4, maxBitrate: 150000 },  // Low: 150kbps
              { rid: 'h', scaleResolutionDownBy: 2, maxBitrate: 500000 },  // Mid: 500kbps  
              { rid: 'f', maxBitrate: 1500000 }                            // Full: 1.5Mbps
            ];

            if (codecs) {
              const preferred = [...codecs].sort((a, b) => {
                // Prioritize AV1 > VP9 > others for better SVC support
                const aScore = a.mimeType.includes('AV1') ? 3 : a.mimeType.includes('VP9') ? 2 : 1;
                const bScore = b.mimeType.includes('AV1') ? 3 : b.mimeType.includes('VP9') ? 2 : 1;
                return bScore - aScore;
              });

              // Add scalabilityMode for true SVC when using VP9/AV1
              const topCodec = preferred[0];
              if (topCodec && (topCodec.mimeType.includes('VP9') || topCodec.mimeType.includes('AV1'))) {
                try {
                  // Cast to any to avoid TypeScript errors with experimental scalabilityMode
                  sendEncodings = [
                    { rid: 'q', scalabilityMode: 'L1T3', maxBitrate: 150000 } as any,
                    { rid: 'h', scalabilityMode: 'L1T3', maxBitrate: 500000 } as any, 
                    { rid: 'f', scalabilityMode: 'L1T3', maxBitrate: 1500000 } as any
                  ];
                  console.log('SVC enabled with scalabilityMode for', topCodec.mimeType);
                } catch (svcError) {
                  console.warn('SVC scalabilityMode not supported, using simulcast:', svcError);
                }
              }
            }

            // Enhanced simulcast/SVC with optimized bitrates for real networks
            const transceiver = pc.addTransceiver(track, {
              direction: 'sendrecv',
              sendEncodings
            });

            if (codecs) {
              const preferred = [...codecs].sort((a, b) => {
                const aScore = a.mimeType.includes('AV1') ? 3 : a.mimeType.includes('VP9') ? 2 : 1;
                const bScore = b.mimeType.includes('AV1') ? 3 : b.mimeType.includes('VP9') ? 2 : 1;
                return bScore - aScore;
              });
              
              try {
                transceiver.setCodecPreferences(preferred);
                console.log('Enhanced simulcast/SVC with codec preferences enabled');
              } catch (codecError) {
                console.warn('Codec preferences not supported:', codecError);
              }
            }
            
            console.log('Enhanced simulcast enabled for video track');
          } catch (error) {
            // Fallback to single layer if simulcast not supported
            console.warn('Simulcast not supported, falling back to single layer:', error);
            pc.addTrack(track, this.localStream!);
          }
        } else {
          // Audio tracks don't need simulcast
          pc.addTrack(track, this.localStream!);
        }
      });
    }

    // Handle remote stream
    pc.ontrack = (event) => {
      if (this.onRemoteStream) {
        this.onRemoteStream(event.streams[0]);
      }
    };

    // Handle ICE candidates
    pc.onicecandidate = (event) => {
      if (event.candidate && this.onIceCandidate) {
        this.onIceCandidate(peerId, event.candidate.toJSON());
      }
    };

    pc.oniceconnectionstatechange = () => {
      console.log(`ICE connection state for ${peerId}:`, pc.iceConnectionState);
    };

    // Handle negotiation needed for renegotiation
    pc.onnegotiationneeded = async () => {
      if (this.pendingNegotiations.has(peerId)) {
        console.log(`Skipping negotiation for ${peerId} - already pending`);
        return;
      }

      this.pendingNegotiations.add(peerId);
      console.log(`Renegotiation needed for ${peerId}`);
      
      try {
        // Create new offer for renegotiation
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        
        if (this.onOffer) {
          this.onOffer(peerId, offer);
        }
      } catch (error) {
        console.error('Error during renegotiation:', error);
      } finally {
        this.pendingNegotiations.delete(peerId);
      }
    };

    this.peerConnections.set(peerId, pc);
    return pc;
  }

  async createOffer(peerId: string) {
    const pc = this.createPeerConnection(peerId);
    
    try {
      // Use modern approach instead of deprecated options
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      
      if (this.onOffer) {
        this.onOffer(peerId, offer);
      }
    } catch (error) {
      console.error('Error creating offer:', error);
    }
  }

  async handleOffer(peerId: string, offer: RTCSessionDescriptionInit) {
    const pc = this.createPeerConnection(peerId);
    
    try {
      await pc.setRemoteDescription(offer);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      
      if (this.onAnswer) {
        this.onAnswer(peerId, answer);
      }
    } catch (error) {
      console.error('Error handling offer:', error);
    }
  }

  async handleAnswer(peerId: string, answer: RTCSessionDescriptionInit) {
    const pc = this.peerConnections.get(peerId);
    if (!pc) return;
    
    try {
      await pc.setRemoteDescription(answer);
    } catch (error) {
      console.error('Error handling answer:', error);
    }
  }

  async handleIceCandidate(peerId: string, candidate: RTCIceCandidateInit) {
    const pc = this.peerConnections.get(peerId);
    if (!pc) return;
    
    try {
      await pc.addIceCandidate(new RTCIceCandidate(candidate));
    } catch (error) {
      console.error('Error adding ICE candidate:', error);
    }
  }

  removePeer(peerId: string) {
    const pc = this.peerConnections.get(peerId);
    if (pc) {
      pc.close();
      this.peerConnections.delete(peerId);
      this.pendingNegotiations.delete(peerId);
    }
  }

  async replaceVideoTrack(newTrack: MediaStreamTrack) {
    const promises = Array.from(this.peerConnections.values()).map(async (pc) => {
      const transceiver = pc.getTransceivers().find(t => 
        t.sender.track && t.sender.track.kind === 'video'
      );
      
      if (transceiver && transceiver.sender) {
        try {
          await transceiver.sender.replaceTrack(newTrack);
          
          // Simulcast settings are preserved with transceiver approach
          console.log('Video track replaced with simulcast preserved');
        } catch (error) {
          console.error('Error replacing video track:', error);
        }
      }
    });

    await Promise.all(promises);
  }

  async startScreenShare(): Promise<MediaStream | null> {
    try {
      // Get screen stream
      const screenStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          width: { ideal: 1920, max: 3840 },
          height: { ideal: 1080, max: 2160 },
          frameRate: { ideal: 30, max: 60 }
        },
        audio: true // Include system audio if available
      });

      this.screenStream = screenStream;
      this.isScreenSharing = true;

      // Set up end handler for when user stops sharing
      const videoTrack = screenStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.onended = () => {
          console.log('Screen sharing ended by user');
          this.stopScreenShare();
          if (this.onScreenShareEnded) {
            this.onScreenShareEnded();
          }
        };
      }

      // Replace video track in all peer connections
      const screenVideoTrack = screenStream.getVideoTracks()[0];
      if (screenVideoTrack) {
        await this.replaceVideoTrack(screenVideoTrack);
        
        // Update local stream to screen stream
        this.localStream = screenStream;
      }

      console.log('Screen sharing started');
      return screenStream;
    } catch (error) {
      console.error('Failed to start screen sharing:', error);
      this.isScreenSharing = false;
      return null;
    }
  }

  async stopScreenShare(): Promise<void> {
    if (!this.isScreenSharing || !this.cameraStream) {
      return;
    }

    try {
      // Stop screen sharing tracks
      if (this.screenStream) {
        this.screenStream.getTracks().forEach(track => track.stop());
        this.screenStream = null;
      }

      // Switch back to camera
      const cameraVideoTrack = this.cameraStream.getVideoTracks()[0];
      if (cameraVideoTrack && cameraVideoTrack.readyState === 'live') {
        await this.replaceVideoTrack(cameraVideoTrack);
        this.localStream = this.cameraStream;
      }

      this.isScreenSharing = false;
      console.log('Screen sharing stopped, switched back to camera');
    } catch (error) {
      console.error('Error stopping screen share:', error);
    }
  }

  cleanup() {
    this.peerConnections.forEach(pc => pc.close());
    this.peerConnections.clear();
    this.pendingNegotiations.clear();
    
    // Stop all streams
    if (this.localStream) {
      this.localStream.getTracks().forEach(track => track.stop());
      this.localStream = null;
    }
    
    if (this.screenStream) {
      this.screenStream.getTracks().forEach(track => track.stop());
      this.screenStream = null;
    }
    
    if (this.cameraStream) {
      this.cameraStream.getTracks().forEach(track => track.stop());
      this.cameraStream = null;
    }
    
    this.isScreenSharing = false;
  }

  // Get the first active peer connection for statistics
  getActivePeerConnection(): RTCPeerConnection | null {
    const connections = Array.from(this.peerConnections.values());
    return connections.find(pc => pc.connectionState === 'connected') || connections[0] || null;
  }
}
