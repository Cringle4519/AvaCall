export class AvatarOverlay {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private avatarImage: HTMLImageElement | null = null;

  constructor(width: number = 640, height: number = 480) {
    this.canvas = document.createElement('canvas');
    this.canvas.width = width;
    this.canvas.height = height;
    this.ctx = this.canvas.getContext('2d')!;
  }

  setAvatarImage(imageUrl: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        this.avatarImage = img;
        resolve();
      };
      img.onerror = reject;
      img.src = imageUrl;
    });
  }

  renderFrame(
    videoFrame: VideoFrame | HTMLVideoElement,
    avatarSize: number = 80,
    position: string = 'bottom-right'
  ): HTMLCanvasElement {
    // Clear canvas
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    // Draw video frame
    if (videoFrame instanceof HTMLVideoElement) {
      this.ctx.drawImage(videoFrame, 0, 0, this.canvas.width, this.canvas.height);
    }

    // Draw avatar overlay
    if (this.avatarImage) {
      const { x, y } = this.getAvatarPosition(position, avatarSize);
      
      // Create circular clipping path
      this.ctx.save();
      this.ctx.beginPath();
      this.ctx.arc(x + avatarSize / 2, y + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2);
      this.ctx.clip();
      
      // Draw avatar image
      this.ctx.drawImage(this.avatarImage, x, y, avatarSize, avatarSize);
      
      this.ctx.restore();
      
      // Draw border
      this.ctx.strokeStyle = '#6366f1'; // Primary color
      this.ctx.lineWidth = 3;
      this.ctx.beginPath();
      this.ctx.arc(x + avatarSize / 2, y + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2);
      this.ctx.stroke();
    }

    return this.canvas;
  }

  private getAvatarPosition(position: string, size: number): { x: number; y: number } {
    const padding = 16;
    
    switch (position) {
      case 'top-left':
        return { x: padding, y: padding };
      case 'top-right':
        return { x: this.canvas.width - size - padding, y: padding };
      case 'bottom-left':
        return { x: padding, y: this.canvas.height - size - padding };
      default: // 'bottom-right'
        return { x: this.canvas.width - size - padding, y: this.canvas.height - size - padding };
    }
  }

  getCanvas(): HTMLCanvasElement {
    return this.canvas;
  }

  destroy() {
    this.avatarImage = null;
  }
}
