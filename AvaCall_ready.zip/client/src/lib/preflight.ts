interface PreflightReport {
  devices: Array<{ kind: string; label: string }>;
  camOk: boolean;
  micOk: boolean;
  iceOk: boolean;
  bitrateKbps: number;
  errors: string[];
}

export async function runPreflight(iceServers: RTCIceServer[]): Promise<PreflightReport> {
  const report: PreflightReport = { 
    devices: [], 
    camOk: false, 
    micOk: false, 
    iceOk: false, 
    bitrateKbps: 0,
    errors: []
  };

  try {
    // Check available devices
    const devices = await navigator.mediaDevices.enumerateDevices();
    report.devices = devices.map(d => ({ 
      kind: d.kind, 
      label: d.label || `${d.kind} (permission needed)` 
    }));

    // Test media access
    let testStream: MediaStream | null = null;
    try {
      testStream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480 }, 
        audio: true 
      });
      
      report.camOk = testStream.getVideoTracks().length > 0;
      report.micOk = testStream.getAudioTracks().length > 0;
      
      if (!report.camOk) report.errors.push('Camera access failed');
      if (!report.micOk) report.errors.push('Microphone access failed');

    } catch (mediaError) {
      report.errors.push(`Media access error: ${mediaError instanceof Error ? mediaError.message : 'Unknown error'}`);
    }

    // Test network connectivity with loopback connection
    if (testStream) {
      try {
        // Create two peer connections for realistic testing
        const pc1 = new RTCPeerConnection({ iceServers });
        const pc2 = new RTCPeerConnection({ iceServers });
        
        const videoTrack = testStream.getVideoTracks()[0];
        
        if (videoTrack) {
          // Set up a data channel for connectivity testing
          const dataChannel = pc1.createDataChannel('test');
          
          let isConnected = false;
          
          // Add video track to pc1
          const sender = pc1.addTrack(videoTrack, new MediaStream([videoTrack]));
          
          // Handle ice candidates
          pc1.onicecandidate = (event) => {
            if (event.candidate) {
              pc2.addIceCandidate(event.candidate);
            }
          };
          
          pc2.onicecandidate = (event) => {
            if (event.candidate) {
              pc1.addIceCandidate(event.candidate);
            }
          };
          
          // Test ICE connectivity with real peer connection
          report.iceOk = await new Promise<boolean>((resolve) => {
            const timeout = setTimeout(() => resolve(false), 8000); // 8s timeout
            
            dataChannel.onopen = () => {
              isConnected = true;
              clearTimeout(timeout);
              resolve(true);
            };
            
            pc2.ondatachannel = (event) => {
              event.channel.onopen = () => {
                isConnected = true;
                clearTimeout(timeout);
                resolve(true);
              };
            };
            
            // Create offer/answer flow
            pc1.createOffer().then(offer => {
              pc1.setLocalDescription(offer);
              return pc2.setRemoteDescription(offer);
            }).then(() => {
              return pc2.createAnswer();
            }).then(answer => {
              pc2.setLocalDescription(answer);
              return pc1.setRemoteDescription(answer);
            }).catch(error => {
              console.warn('Offer/answer failed:', error);
              clearTimeout(timeout);
              resolve(false);
            });
          });

          if (!report.iceOk) {
            report.errors.push('Network connectivity test failed - may have trouble connecting through firewalls');
          }

          // Simple bitrate estimation based on successful connection
          if (isConnected) {
            report.bitrateKbps = 500; // Estimate based on successful connection
          } else {
            report.bitrateKbps = 0;
          }

          pc1.close();
          pc2.close();
        }
      } catch (networkError) {
        report.errors.push(`Network test error: ${networkError instanceof Error ? networkError.message : 'Unknown error'}`);
      }
    }

    // Cleanup
    if (testStream) {
      testStream.getTracks().forEach(track => track.stop());
    }

  } catch (error) {
    report.errors.push(`Preflight check failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }

  return report;
}

export function getPreflightScore(report: PreflightReport): number {
  let score = 0;
  if (report.camOk) score += 25;
  if (report.micOk) score += 25; 
  if (report.iceOk) score += 30;
  if (report.bitrateKbps > 100) score += 20; // At least 100kbps
  return score;
}

export function getPreflightMessage(report: PreflightReport): string {
  const score = getPreflightScore(report);
  
  if (score >= 80) return "Excellent! Your setup is ready for high-quality video calls.";
  if (score >= 60) return "Good! You should have a solid video calling experience.";
  if (score >= 40) return "Okay. You may experience some connectivity or quality issues.";
  return "Poor connection detected. Consider checking your network or trying mobile data.";
}