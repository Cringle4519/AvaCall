import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/home";
import Lobby from "@/pages/lobby";
import VideoCall from "@/pages/video-call";
import AvatarManager from "@/pages/avatar-manager";
import AvatarCreate from "@/pages/avatar-create";
import Privacy from "@/pages/privacy";
import Terms from "@/pages/terms";
import NotFound from "@/pages/not-found";
import FooterLegal from "@/components/FooterLegal";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/avatar" component={AvatarManager} />
      <Route path="/avatar/create" component={AvatarCreate} />
      <Route path="/room/:roomId/lobby" component={Lobby} />
      <Route path="/room/:roomId/call" component={VideoCall} />
      <Route path="/room/:roomId" component={Lobby} /> {/* Default to lobby */}
      <Route path="/legal/privacy" component={Privacy} />
      <Route path="/legal/terms" component={Terms} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen flex flex-col">
          <main className="flex-1">
            <Router />
          </main>
          <FooterLegal />
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
