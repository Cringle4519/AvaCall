export type RevealLevel = 0 | 25 | 50 | 75 | 100;
export const ORDER: RevealLevel[] = [0, 25, 50, 75, 100];
export const FRACTION: Record<RevealLevel, number> = { 0:0, 25:0.25, 50:0.5, 75:0.75, 100:1 };
export const nextLevel = (l: RevealLevel) => ORDER[Math.min(ORDER.indexOf(l)+1, ORDER.length-1)];
export const prevLevel = (l: RevealLevel) => ORDER[Math.max(ORDER.indexOf(l)-1, 0)];