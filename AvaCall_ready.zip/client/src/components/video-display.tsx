import { RefObject } from "react";
import { Mic, MicOff, Video, VideoOff, PhoneOff, Monitor, MoreHorizontal, Link, BarChart3, Shield } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import RevealMask from "./reveal-mask";
import RevealStack from "@/components/RevealStack";
import AvatarDisplay from "@/components/AvatarDisplay";
import type { RevealLevel } from "@/reveal/levels";
import { useAudioLevel } from '@/hooks/useAudioLevel';
import AvatarMouth from '@/components/AvatarMouth';
import NetworkQualityBadge from '@/components/NetworkQualityBadge';
import VoiceEnhanceToggle from '@/components/VoiceEnhanceToggle';

interface VideoDisplayProps {
  localVideoRef: RefObject<HTMLVideoElement>;
  remoteVideoRef: RefObject<HTMLVideoElement>;
  selectedAvatar: number | string;
  selectedAvatarUrl?: string;
  selectedBackground: string;
  selectedBackgroundUrl?: string;
  avatarSize: number;
  avatarPosition: string;
  isConnected: boolean;
  isMuted: boolean;
  isCameraOn: boolean;
  participants: number;
  onToggleMicrophone: () => void;
  onToggleCamera: () => void;
  onEndCall: () => void;
  onShareScreen: () => void;
  // PIRP reveal masking
  remoteRevealLevel?: number;
  localRevealLevel?: number;
  // User IDs for avatar display
  localUserId?: string;
  remoteUserId?: string;
  // Menu actions
  onCopyInviteLink?: () => void;
  onToggleCallStats?: () => void;
  // Lip-sync integration
  localStream?: MediaStream | null;
  // Network quality and voice enhancement
  peerConnection?: RTCPeerConnection | null;
  onStreamReplace?: (newStream: MediaStream) => void;
}

const avatarImages = [
  "",
  "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
  "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150"
];

export default function VideoDisplay({
  localVideoRef,
  remoteVideoRef,
  selectedAvatar,
  selectedAvatarUrl,
  selectedBackground,
  selectedBackgroundUrl,
  avatarSize,
  avatarPosition,
  isConnected,
  isMuted,
  isCameraOn,
  participants,
  onToggleMicrophone,
  onToggleCamera,
  onEndCall,
  onShareScreen,
  remoteRevealLevel = 0,
  localRevealLevel = 0,
  localUserId,
  remoteUserId,
  onCopyInviteLink,
  onToggleCallStats,
  localStream,
  peerConnection,
  onStreamReplace
}: VideoDisplayProps) {
  const level = useAudioLevel(localStream || null);

  const getAvatarPositionClass = () => {
    switch (avatarPosition) {
      case "top-left":
        return "top-4 left-4";
      case "top-right":
        return "top-4 right-4";
      case "bottom-left":
        return "bottom-4 left-4";
      default:
        return "bottom-4 right-4";
    }
  };

  return (
    <div className="flex-1 p-6">
      <div className="video-container w-full h-full relative min-h-96">
        {/* Remote Video Stream (Main) */}
        <div className="relative w-full h-full">
          <video
            ref={remoteVideoRef}
            className="w-full h-full object-cover"
            autoPlay
            playsInline
            data-testid="video-remote"
          />
          
          {/* PIRP Avatar Integration for Remote User */}
          {remoteUserId && remoteRevealLevel <= 75 && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/50">
              <AvatarDisplay 
                userId={remoteUserId}
                revealLevel={remoteRevealLevel}
                size="lg"
                className="z-20"
                data-testid="remote-avatar-display"
              />
            </div>
          )}
          
          {/* PIRP Reveal Stack for Remote Video - 14x14 deterministic tile system */}
          <RevealStack 
            level={remoteRevealLevel as RevealLevel} 
            seed={`remote-user`}
            rounded={false}
            className="rounded-none"
          />
        </div>

        {/* Local Video Stream (Picture-in-Picture) */}
        <div className="absolute top-4 left-4 w-48 h-36 bg-black/50 rounded-lg overflow-hidden border-2 border-primary/50">
          <div className="relative w-full h-full">
            <video
              ref={localVideoRef}
              className="w-full h-full object-cover"
              autoPlay
              muted
              playsInline
              data-testid="video-local"
            />
            
            {/* PIRP Avatar Integration for Local User */}
            {localUserId && localRevealLevel <= 25 && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-lg">
                <AvatarDisplay 
                  userId={localUserId}
                  revealLevel={localRevealLevel}
                  size="sm"
                  isLocal={true}
                  className="z-10"
                  data-testid="local-avatar-display"
                />
              </div>
            )}
            
            {/* PIRP Reveal Stack for Local Video - 14x14 deterministic tile system */}
            <RevealStack 
              level={localRevealLevel as RevealLevel} 
              seed={`local-user`}
              rounded={true}
              className="rounded-lg"
            />
          </div>
        </div>

        {/* Connection Status */}
        <div className="absolute top-4 right-4 floating-panel p-3">
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
            <span className="text-sm text-foreground" data-testid="text-connection-status">
              {isConnected ? 'Live' : 'Connecting...'}
            </span>
          </div>
        </div>

        {/* Participant Count */}
        <div className="absolute top-16 right-4 floating-panel p-3">
          <span className="text-sm text-muted-foreground" data-testid="text-participant-count">
            {participants} participant{participants !== 1 ? 's' : ''}
          </span>
        </div>

        {/* Network Quality Badge */}
        <div className="absolute top-28 right-4 floating-panel p-3">
          <NetworkQualityBadge 
            peerConnection={peerConnection || null}
            className="text-sm"
          />
        </div>

        {/* Avatar Overlay */}
        {selectedAvatar && (
          <div 
            className={`absolute ${getAvatarPositionClass()} z-10`}
            style={{
              width: `${avatarSize}px`,
              height: `${avatarSize}px`,
            }}
            data-testid="avatar-overlay"
          >
            <img 
              src={selectedAvatarUrl || (typeof selectedAvatar === 'number' ? avatarImages[selectedAvatar] : '') || ''}
              alt="Selected avatar overlay"
              className="w-full h-full object-cover rounded-full border-3 border-primary"
              style={{
                width: `${avatarSize}px`,
                height: `${avatarSize}px`,
              }}
            />
            <AvatarMouth level={level} />
          </div>
        )}

        {/* Call Controls */}
        <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2">
          <div className="floating-panel p-4">
            <div className="flex items-center space-x-4">
              {/* Microphone Control */}
              <button
                onClick={onToggleMicrophone}
                className={`control-button ${
                  isMuted 
                    ? 'bg-destructive text-destructive-foreground' 
                    : 'bg-muted text-muted-foreground hover:bg-accent'
                }`}
                data-testid="button-toggle-microphone"
              >
                {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>
              
              {/* Camera Control */}
              <button
                onClick={onToggleCamera}
                className={`control-button ${
                  !isCameraOn 
                    ? 'bg-destructive text-destructive-foreground' 
                    : 'bg-muted text-muted-foreground hover:bg-accent'
                }`}
                data-testid="button-toggle-camera"
              >
                {isCameraOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
              </button>
              
              {/* End Call */}
              <button
                onClick={onEndCall}
                className="control-button bg-destructive text-destructive-foreground hover:bg-red-600"
                data-testid="button-end-call"
              >
                <PhoneOff className="w-5 h-5" />
              </button>
              
              {/* Screen Share */}
              <button
                onClick={onShareScreen}
                className="control-button bg-muted text-muted-foreground hover:bg-accent"
                data-testid="button-share-screen"
              >
                <Monitor className="w-5 h-5" />
              </button>
              
              {/* Voice Enhancement Toggle */}
              <VoiceEnhanceToggle
                localStream={localStream || null}
                peerConnection={peerConnection || null}
                onStreamReplace={onStreamReplace}
                className="control-button-container"
              />
              
              {/* More Options */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    className="control-button bg-muted text-muted-foreground hover:bg-accent"
                    data-testid="button-more-options"
                  >
                    <MoreHorizontal className="w-5 h-5" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="center" side="top" className="w-48">
                  <DropdownMenuItem 
                    onClick={onCopyInviteLink}
                    data-testid="menu-copy-invite"
                  >
                    <Link className="w-4 h-4 mr-2" />
                    Copy Invite Link
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={onToggleCallStats}
                    data-testid="menu-call-stats"
                  >
                    <BarChart3 className="w-4 h-4 mr-2" />
                    View Call Stats
                  </DropdownMenuItem>
                  <DropdownMenuItem data-testid="menu-privacy-help">
                    <Shield className="w-4 h-4 mr-2" />
                    Privacy Help
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
