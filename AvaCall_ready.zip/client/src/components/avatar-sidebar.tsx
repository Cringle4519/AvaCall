import { useState } from "react";
import { UserCircle, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface AvatarSidebarProps {
  selectedAvatar: number | string;
  onAvatarSelect: (avatarId: number | string, avatarUrl?: string) => void;
  avatarSize: number;
  onAvatarSizeChange: (size: number) => void;
  avatarPosition: string;
  onAvatarPositionChange: (position: string) => void;
}

const avatarOptions = [
  {
    id: 1,
    src: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    alt: "Professional woman avatar"
  },
  {
    id: 2,
    src: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    alt: "Professional man avatar"
  },
  {
    id: 3,
    src: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    alt: "Casual person with glasses avatar"
  },
  {
    id: 4,
    src: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    alt: "Young professional avatar"
  },
  {
    id: 5,
    src: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    alt: "Mature businessman avatar"
  },
  {
    id: 6,
    src: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    alt: "Creative person avatar"
  }
];

export default function AvatarSidebar({
  selectedAvatar,
  onAvatarSelect,
  avatarSize,
  onAvatarSizeChange,
  avatarPosition,
  onAvatarPositionChange
}: AvatarSidebarProps) {
  const [customAvatars, setCustomAvatars] = useState<{id: string, url: string, name: string}[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const handleAvatarUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    const formData = new FormData();
    formData.append('avatar', file);

    try {
      const response = await fetch('/api/upload/avatar', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const result = await response.json();
      const newCustomAvatar = {
        id: `custom-${Date.now()}`,
        url: result.url,
        name: file.name
      };

      setCustomAvatars(prev => [...prev, newCustomAvatar]);
      onAvatarSelect(newCustomAvatar.id, newCustomAvatar.url);
      
      toast({
        title: "Avatar uploaded",
        description: "Your custom avatar has been uploaded successfully",
      });
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Failed to upload avatar. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      // Clear the input
      event.target.value = '';
    }
  };

  const removeCustomAvatar = (avatarId: string) => {
    setCustomAvatars(prev => prev.filter(avatar => avatar.id !== avatarId));
    if (selectedAvatar === avatarId) {
      onAvatarSelect(1); // Fallback to first preset avatar
    }
  };

  const getSelectedAvatarUrl = () => {
    if (typeof selectedAvatar === 'string') {
      const customAvatar = customAvatars.find(avatar => avatar.id === selectedAvatar);
      return customAvatar?.url;
    } else {
      const presetAvatar = avatarOptions.find(avatar => avatar.id === selectedAvatar);
      return presetAvatar?.src;
    }
  };

  // Export the custom avatars and selected avatar URL for use by parent components

  return (
    <div className="w-80 p-6 border-r border-border">
      <div className="sidebar-panel p-6">
        <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center">
          <UserCircle className="mr-2 text-primary w-5 h-5" />
          Choose Avatar
        </h2>
        
        {/* Avatar Options Grid */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          {avatarOptions.map((avatar) => (
            <div
              key={avatar.id}
              className={`avatar-option ${selectedAvatar === avatar.id ? 'selected' : ''}`}
              onClick={() => onAvatarSelect(avatar.id)}
              data-testid={`avatar-option-${avatar.id}`}
            >
              <img 
                src={avatar.src}
                alt={avatar.alt}
                className="w-full h-20 object-cover rounded-lg"
              />
            </div>
          ))}
        </div>

        {/* Custom Avatars */}
        {customAvatars.length > 0 && (
          <div className="mb-4">
            <h3 className="text-sm font-medium text-muted-foreground mb-2">Custom Avatars</h3>
            <div className="grid grid-cols-3 gap-3">
              {customAvatars.map((avatar) => (
                <div
                  key={avatar.id}
                  className={`avatar-option relative ${selectedAvatar === avatar.id ? 'selected' : ''}`}
                  onClick={() => onAvatarSelect(avatar.id)}
                  data-testid={`avatar-option-${avatar.id}`}
                >
                  <img 
                    src={avatar.url}
                    alt={avatar.name}
                    className="w-full h-20 object-cover rounded-lg"
                  />
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      removeCustomAvatar(avatar.id);
                    }}
                    className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center text-xs hover:bg-red-600"
                    data-testid={`remove-avatar-${avatar.id}`}
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Upload Button */}
        <div className="mb-6">
          <input
            type="file"
            accept="image/*"
            onChange={handleAvatarUpload}
            className="hidden"
            id="avatar-upload"
            disabled={isUploading}
          />
          <label 
            htmlFor="avatar-upload"
            className={`w-full p-3 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-colors cursor-pointer flex items-center justify-center ${isUploading ? 'opacity-50 cursor-not-allowed' : ''}`}
            data-testid="button-upload-avatar"
          >
            <Upload className="w-4 h-4 mr-2" />
            {isUploading ? 'Uploading...' : 'Upload Custom Avatar'}
          </label>
        </div>

        {/* Avatar Customization */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Avatar Size
            </label>
            <input 
              type="range" 
              min="60" 
              max="120" 
              value={avatarSize}
              onChange={(e) => {
                const newSize = parseInt(e.target.value);
                console.log('Avatar size slider changed to:', newSize);
                onAvatarSizeChange(newSize);
              }}
              className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
              data-testid="slider-avatar-size"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Position
            </label>
            <select 
              value={avatarPosition}
              onChange={(e) => onAvatarPositionChange(e.target.value)}
              className="w-full p-2 bg-input border border-border rounded-lg text-foreground"
              data-testid="select-avatar-position"
            >
              <option value="bottom-right">Bottom Right</option>
              <option value="bottom-left">Bottom Left</option>
              <option value="top-right">Top Right</option>
              <option value="top-left">Top Left</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}
