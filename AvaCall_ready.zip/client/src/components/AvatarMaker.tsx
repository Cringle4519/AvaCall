import { useEffect, useRef, useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { stylizeProLikeness } from '@/lib/avatar/stylizePro';
import { mount3DLikeness, capture3DAvatar } from '@/lib/avatar/threeLikeness';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Upload, Eye, Download, Wand2, Loader2 } from 'lucide-react';
import type { UserAvatar } from '@shared/schema';

type AvatarChoice = '3d' | 'stylized';

interface AvatarMakerProps {
  userId: string;
  onDone?: (avatar: UserAvatar) => void;
  onClose?: () => void;
}

export default function AvatarMaker({ userId, onDone, onClose }: AvatarMakerProps) {
  const { toast } = useToast();
  const [srcUrl, setSrcUrl] = useState<string | null>(null);
  const [choice, setChoice] = useState<AvatarChoice>('3d');
  const [busy, setBusy] = useState(false);
  const [outUrl, setOutUrl] = useState<string | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  
  const headRef = useRef<HTMLDivElement>(null);
  const stopRef = useRef<(() => void) | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Clean up 3D scene on unmount
  useEffect(() => {
    return () => {
      stopRef.current?.();
    };
  }, []);

  // Render live 3D preview when chosen and source URL is available
  useEffect(() => {
    if (choice !== '3d' || !srcUrl || !headRef.current) {
      stopRef.current?.();
      stopRef.current = null;
      return;
    }

    try {
      stopRef.current?.(); // Clean up previous scene
      stopRef.current = mount3DLikeness(headRef.current, srcUrl, {
        headModelUrl: import.meta.env.VITE_HEAD_MODEL_URL
      });
    } catch (error) {
      console.warn('WebGL/3D rendering not available, falling back to 2D preview:', error);
      // Graceful fallback - no 3D preview, but avatar generation will still work
      toast({
        title: 'Note: 3D preview unavailable',
        description: 'You can still generate your avatar without the live preview.',
        variant: 'default',
      });
    }

    return () => {
      stopRef.current?.();
    };
  }, [choice, srcUrl]);

  // Upload photo mutation
  const uploadMutation = useMutation({
    mutationFn: async (file: File): Promise<{ url: string }> => {
      const formData = new FormData();
      formData.append('file', file);
      const response = await fetch('/api/avatar/process', {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) throw new Error('Upload failed');
      return response.json();
    },
    onSuccess: (data) => {
      setSrcUrl(data.url);
      setOutUrl(null);
      toast({
        title: 'Photo uploaded successfully!',
        description: 'You can now generate your avatar.',
      });
    },
    onError: () => {
      toast({
        title: 'Upload failed',
        description: 'Please try again with a different image.',
        variant: 'destructive',
      });
    },
  });

  // Create avatar record mutation
  const createAvatarMutation = useMutation({
    mutationFn: async (avatarData: { originalPhotoUrl: string; avatarType: string; avatarUrl: string }) => {
      const response = await apiRequest('POST', '/api/avatar/create', {
        userId,
        originalPhotoUrl: avatarData.originalPhotoUrl,
        avatarType: avatarData.avatarType,
        avatarUrl: avatarData.avatarUrl,
        isActive: true,
      });
      return response.json();
    },
    onSuccess: (avatar: UserAvatar) => {
      toast({
        title: 'Avatar saved!',
        description: 'Your avatar is ready to use in video calls.',
      });
      onDone?.(avatar);
    },
    onError: () => {
      toast({
        title: 'Save failed',
        description: 'Please try saving your avatar again.',
        variant: 'destructive',
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.match(/image\/(jpeg|png|webp)/)) {
      toast({
        title: 'Invalid file type',
        description: 'Please select a JPEG, PNG, or WebP image.',
        variant: 'destructive',
      });
      return;
    }

    // Validate file size (8MB)
    if (file.size > 8 * 1024 * 1024) {
      toast({
        title: 'File too large',
        description: 'Please select an image smaller than 8MB.',
        variant: 'destructive',
      });
      return;
    }

    setUploadedFile(file);
    uploadMutation.mutate(file);
  };

  const handleGenerate = async () => {
    if (!srcUrl) return;
    
    setBusy(true);
    setOutUrl(null);
    
    try {
      if (choice === 'stylized') {
        const processedUrl = await stylizeProLikeness(srcUrl, 512);
        setOutUrl(processedUrl);
      } else if (choice === '3d') {
        const capturedUrl = capture3DAvatar(headRef.current!);
        setOutUrl(capturedUrl);
      }
      
      toast({
        title: 'Avatar generated!',
        description: 'Your avatar is ready. You can download it or use it in calls.',
      });
    } catch (error) {
      console.error('Avatar generation error:', error);
      toast({
        title: 'Generation failed',
        description: 'Please try again or choose a different style.',
        variant: 'destructive',
      });
    } finally {
      setBusy(false);
    }
  };

  const handleSave = () => {
    if (!srcUrl || !outUrl) return;
    
    createAvatarMutation.mutate({
      originalPhotoUrl: srcUrl,
      avatarType: choice,
      avatarUrl: outUrl,
    });
  };

  const handleDownload = () => {
    if (!outUrl) return;
    
    const link = document.createElement('a');
    link.href = outUrl;
    link.download = `avatar-${choice}-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Card className="bg-card/80 backdrop-blur-sm border-border max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-foreground flex items-center gap-2">
              <Wand2 className="h-5 w-5 text-primary" />
              Avatar Generator
            </CardTitle>
            <CardDescription>
              Create your privacy-first avatar for video calls with staged reveal
            </CardDescription>
          </div>
          {onClose && (
            <Button variant="ghost" size="sm" onClick={onClose} data-testid="button-close-avatar-maker">
              ×
            </Button>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Step 1: Upload Photo */}
        <div className="space-y-3">
          <Label className="text-sm font-medium text-foreground">1. Upload Your Photo</Label>
          <div className="flex items-center gap-3">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              onChange={handleFileSelect}
              className="hidden"
              data-testid="input-avatar-photo"
            />
            <Button
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploadMutation.isPending}
              data-testid="button-upload-photo"
              className="border-border hover:bg-muted"
            >
              {uploadMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Upload className="h-4 w-4 mr-2" />
              )}
              {uploadMutation.isPending ? 'Uploading...' : 'Choose Photo'}
            </Button>
            {uploadedFile && (
              <Badge variant="secondary" className="text-xs">
                {uploadedFile.name}
              </Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            JPEG, PNG, or WebP up to 8MB. Your photo stays private and is only used for avatar generation.
          </p>
        </div>

        {/* Step 2: Choose Avatar Style */}
        {srcUrl && (
          <div className="space-y-3">
            <Label className="text-sm font-medium text-foreground">2. Choose Avatar Style</Label>
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant={choice === '3d' ? 'default' : 'outline'}
                onClick={() => setChoice('3d')}
                disabled={busy}
                data-testid="button-choose-3d"
                className={choice === '3d' ? 'bg-primary text-primary-foreground' : 'border-border hover:bg-muted'}
              >
                🎭 3D Avatar Likeness
              </Button>
              <Button
                variant={choice === 'stylized' ? 'default' : 'outline'}
                onClick={() => setChoice('stylized')}
                disabled={busy}
                data-testid="button-choose-stylized"
                className={choice === 'stylized' ? 'bg-primary text-primary-foreground' : 'border-border hover:bg-muted'}
              >
                ✨ Stylized Avatar Likeness
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Both styles keep your resemblance while protecting your privacy
            </p>
          </div>
        )}

        {/* Step 3: Preview & Generate */}
        {srcUrl && (
          <div className="space-y-3">
            <Label className="text-sm font-medium text-foreground">3. Preview & Generate</Label>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Preview Area */}
              <div className="space-y-2">
                <Label className="text-xs font-medium text-muted-foreground">Preview</Label>
                <div className="aspect-square bg-muted/50 rounded-lg border border-border overflow-hidden">
                  {choice === '3d' ? (
                    <div className="w-full h-full relative">
                      <div 
                        ref={headRef} 
                        className="w-full h-full bg-black"
                        data-testid="preview-3d-avatar"
                      />
                      {/* Always show fallback for testing */}
                      <div className="absolute inset-0 flex items-center justify-center bg-blue-500/50">
                        <img 
                          src={srcUrl} 
                          alt="Original photo" 
                          className="w-24 h-24 object-contain rounded opacity-75"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <img 
                        src={srcUrl} 
                        alt="Original photo" 
                        className="max-w-full max-h-full object-contain rounded"
                        data-testid="preview-stylized-avatar"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Generated Result */}
              <div className="space-y-2">
                <Label className="text-xs font-medium text-muted-foreground">Generated Avatar</Label>
                <div className="aspect-square bg-muted/50 rounded-lg border border-border overflow-hidden flex items-center justify-center">
                  {outUrl ? (
                    <img 
                      src={outUrl} 
                      alt="Generated avatar" 
                      className="max-w-full max-h-full object-contain rounded"
                      data-testid="generated-avatar-result"
                    />
                  ) : (
                    <div className="text-center text-muted-foreground">
                      <Eye className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">Generate to see result</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Generate Button */}
            <Button
              onClick={handleGenerate}
              disabled={busy}
              className="w-full bg-primary hover:bg-primary/90"
              data-testid="button-generate-avatar"
            >
              {busy ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Generating {choice === '3d' ? '3D' : 'Stylized'} Avatar...
                </>
              ) : (
                <>
                  <Wand2 className="h-4 w-4 mr-2" />
                  Generate {choice === '3d' ? '3D' : 'Stylized'} Avatar
                </>
              )}
            </Button>
          </div>
        )}

        {/* Step 4: Save or Download */}
        {outUrl && (
          <div className="space-y-3">
            <Label className="text-sm font-medium text-foreground">4. Save Avatar</Label>
            <div className="flex flex-wrap gap-2">
              <Button
                onClick={handleDownload}
                variant="outline"
                data-testid="button-download-avatar"
                className="border-border hover:bg-muted"
              >
                <Download className="h-4 w-4 mr-2" />
                Download PNG
              </Button>
              {onDone && (
                <Button
                  onClick={handleSave}
                  disabled={createAvatarMutation.isPending}
                  data-testid="button-save-avatar"
                  className="bg-primary hover:bg-primary/90"
                >
                  {createAvatarMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    'Use This Avatar'
                  )}
                </Button>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              Your avatar will be used for PIRP staged reveal (25% → 50% → 75% → 100%) during video calls
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}