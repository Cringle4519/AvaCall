import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Mic, MicOff } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

interface VoiceEnhanceToggleProps {
  localStream: MediaStream | null;
  peerConnection: RTCPeerConnection | null;
  onStreamReplace?: (newStream: MediaStream) => void;
  className?: string;
}

export default function VoiceEnhanceToggle({
  localStream,
  peerConnection,
  onStreamReplace,
  className = ""
}: VoiceEnhanceToggleProps) {
  const [isEnhanced, setIsEnhanced] = useState(true); // Default to enhanced (matches current behavior)
  const [isUpdating, setIsUpdating] = useState(false);

  const toggleVoiceEnhancement = useCallback(async () => {
    if (!localStream || !peerConnection || isUpdating) return;

    setIsUpdating(true);
    try {
      const currentAudioTrack = localStream.getAudioTracks()[0];
      if (!currentAudioTrack) return;

      // Get current device ID to maintain device selection
      const currentDeviceId = currentAudioTrack.getSettings().deviceId;
      
      // Toggle enhancement settings
      const newEnhanced = !isEnhanced;
      const audioConstraints = {
        deviceId: currentDeviceId ? { exact: currentDeviceId } : undefined,
        echoCancellation: newEnhanced,
        noiseSuppression: newEnhanced,
        autoGainControl: newEnhanced
      };

      // Get new audio stream with updated constraints
      const newStream = await navigator.mediaDevices.getUserMedia({
        audio: audioConstraints
      });

      const newAudioTrack = newStream.getAudioTracks()[0];

      // Replace the audio track in the peer connection
      const audioSender = peerConnection.getSenders().find(
        sender => sender.track?.kind === 'audio'
      );

      if (audioSender) {
        await audioSender.replaceTrack(newAudioTrack);
      }

      // Stop the old audio track
      currentAudioTrack.stop();

      // Create updated stream with new audio track and existing video tracks
      const videoTracks = localStream.getVideoTracks();
      const updatedStream = new MediaStream([newAudioTrack, ...videoTracks]);

      // Notify parent component about the stream update
      onStreamReplace?.(updatedStream);

      setIsEnhanced(newEnhanced);
    } catch (error) {
      console.error('Failed to toggle voice enhancement:', error);
    } finally {
      setIsUpdating(false);
    }
  }, [localStream, peerConnection, isEnhanced, isUpdating, onStreamReplace]);

  const getTooltipText = () => {
    if (isEnhanced) {
      return "Voice enhancement ON\nEcho cancellation, noise suppression, and auto gain control active";
    } else {
      return "Voice enhancement OFF\nRaw audio without processing";
    }
  };

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          variant={isEnhanced ? "default" : "outline"}
          size="sm"
          onClick={toggleVoiceEnhancement}
          disabled={isUpdating || !localStream}
          className={`${className} ${isEnhanced ? 'bg-blue-600 hover:bg-blue-700' : ''}`}
          data-testid="voice-enhance-toggle"
        >
          {isEnhanced ? (
            <Mic className="w-4 h-4" />
          ) : (
            <MicOff className="w-4 h-4" />
          )}
          <span className="ml-2 text-xs">
            {isUpdating ? "..." : isEnhanced ? "Enhanced" : "Raw"}
          </span>
        </Button>
      </TooltipTrigger>
      <TooltipContent>
        <p className="whitespace-pre-line text-xs">{getTooltipText()}</p>
      </TooltipContent>
    </Tooltip>
  );
}