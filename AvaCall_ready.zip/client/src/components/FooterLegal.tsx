import { Link } from "wouter";

export default function FooterLegal() {
  return (
    <footer className="mt-6 text-xs opacity-70 text-center">
      <Link href="/legal/privacy">
        <a className="underline text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300" data-testid="link-privacy">Privacy</a>
      </Link> ·{' '}
      <Link href="/legal/terms">
        <a className="underline text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300" data-testid="link-terms">Terms</a>
      </Link> ·{' '}
      <span>By joining, you agree to staged reveal rules; no recording without consent.</span>
    </footer>
  );
}