import { useState, useEffect } from "react";
import { Wifi, AlertTriangle } from "lucide-react";

interface NetworkQualityBadgeProps {
  peerConnection: RTCPeerConnection | null;
  className?: string;
}

type QualityLevel = 'excellent' | 'good' | 'poor' | 'failed' | 'connecting';

interface QualityMetrics {
  packetLoss: number;
  jitter: number;
  connectionState: RTCPeerConnectionState;
}

export default function NetworkQualityBadge({ peerConnection, className = "" }: NetworkQualityBadgeProps) {
  const [quality, setQuality] = useState<QualityLevel>('excellent');
  const [metrics, setMetrics] = useState<QualityMetrics>({
    packetLoss: 0,
    jitter: 0,
    connectionState: 'new'
  });

  useEffect(() => {
    if (!peerConnection) {
      setQuality('connecting');
      return;
    }

    const interval = setInterval(async () => {
      try {
        const stats = await peerConnection.getStats();
        let packetLoss = 0;
        let jitter = 0;
        let packetsReceived = 0;
        let packetsLost = 0;

        stats.forEach(report => {
          if (report.type === 'inbound-rtp' && (report.kind === 'video' || report.mediaType === 'video')) {
            packetsReceived = report.packetsReceived || 0;
            packetsLost = report.packetsLost || 0;
            jitter = (report.jitter || 0) * 1000; // Convert to ms
          }
        });

        // Calculate packet loss percentage
        const totalPackets = packetsReceived + packetsLost;
        packetLoss = totalPackets > 0 ? (packetsLost / totalPackets) * 100 : 0;

        const currentMetrics = {
          packetLoss,
          jitter,
          connectionState: peerConnection.connectionState
        };

        setMetrics(currentMetrics);

        // Determine quality level based on metrics
        if (currentMetrics.connectionState === 'failed' || currentMetrics.connectionState === 'disconnected') {
          setQuality('failed');
        } else if (currentMetrics.packetLoss > 5 || currentMetrics.jitter > 150) {
          setQuality('poor');
        } else if (currentMetrics.packetLoss > 2 || currentMetrics.jitter > 75) {
          setQuality('good');
        } else {
          setQuality('excellent');
        }
      } catch (error) {
        console.error('Failed to get connection stats:', error);
        setQuality('failed');
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [peerConnection]);

  const getQualityIcon = () => {
    switch (quality) {
      case 'excellent':
        return <span className="text-green-500" data-testid="quality-excellent">✅</span>;
      case 'good':
        return <Wifi className="w-4 h-4 text-yellow-500" data-testid="quality-good" />;
      case 'poor':
        return <AlertTriangle className="w-4 h-4 text-orange-500" data-testid="quality-poor" />;
      case 'connecting':
        return <span className="text-blue-500 animate-pulse" data-testid="quality-connecting">🔗</span>;
      case 'failed':
        return <span className="text-red-500" data-testid="quality-failed">❌</span>;
    }
  };

  const getQualityText = () => {
    switch (quality) {
      case 'excellent':
        return 'Excellent';
      case 'good':
        return 'Good';
      case 'poor':
        return 'Poor - Check Wi-Fi';
      case 'connecting':
        return 'Connecting...';
      case 'failed':
        return 'Connection Failed';
    }
  };

  const getTooltipText = () => {
    const { packetLoss, jitter, connectionState } = metrics;
    return `Loss: ${packetLoss.toFixed(1)}% | Jitter: ${jitter.toFixed(0)}ms | State: ${connectionState}`;
  };

  return (
    <div 
      className={`flex items-center gap-2 text-sm ${className}`}
      title={getTooltipText()}
      data-testid="network-quality-badge"
    >
      {getQualityIcon()}
      <span className="text-xs font-medium">
        {getQualityText()}
      </span>
    </div>
  );
}