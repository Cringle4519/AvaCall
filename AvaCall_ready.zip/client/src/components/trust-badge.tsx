import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import type { Participant, TrustEvent } from "@shared/schema";

import { 
  Shield, ShieldCheck, Star, TrendingUp, TrendingDown, 
  Award, ChevronDown, ChevronUp, Info, Trophy 
} from "lucide-react";

interface TrustBadgeProps {
  participant: Participant;
  roomId: string;
  className?: string;
  compact?: boolean;
}

interface MilestoneInfo {
  level: number;
  name: string;
  icon: React.ReactNode;
  color: string;
  description: string;
}

const MILESTONES: MilestoneInfo[] = [
  {
    level: 25,
    name: "Newcomer",
    icon: <Shield className="h-4 w-4" />,
    color: "text-blue-600",
    description: "Started building trust in the community"
  },
  {
    level: 50,
    name: "Trusted",
    icon: <ShieldCheck className="h-4 w-4" />,
    color: "text-green-600",
    description: "Demonstrated consistent positive behavior"
  },
  {
    level: 75,
    name: "Respected",
    icon: <Award className="h-4 w-4" />,
    color: "text-purple-600",
    description: "Earned respect through valuable contributions"
  },
  {
    level: 100,
    name: "Champion",
    icon: <Trophy className="h-4 w-4" />,
    color: "text-gold-600",
    description: "Exemplary member of the community"
  }
];

export default function TrustBadge({ participant, roomId, className = "", compact = false }: TrustBadgeProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  // Fetch PIRP status which includes trust events
  const { data: pirpStatus } = useQuery<{
    trustScore: number;
    currentLevel: number;
    recentTrustEvents: TrustEvent[];
  }>({
    queryKey: ["/api/pirp/status"],
    enabled: !!participant.userId && !!roomId,
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const trustEvents: TrustEvent[] = pirpStatus?.recentTrustEvents || [];

  // Use real-time scores from pirpStatus for live updates, fall back to participant data
  const currentScore = (pirpStatus?.trustScore ?? participant.trustScore) || 0;
  const currentLevel = (pirpStatus?.currentLevel ?? participant.currentLevel) || 0;
  
  // Calculate progress to next milestone
  const nextMilestone = MILESTONES.find(m => m.level > currentScore);
  const prevMilestone = MILESTONES.filter(m => m.level <= currentScore).pop();
  
  const progressStart = prevMilestone?.level || 0;
  const progressEnd = nextMilestone?.level || 100;
  const progressValue = Math.min(100, ((currentScore - progressStart) / (progressEnd - progressStart)) * 100);

  // Get achieved milestones
  const achievedMilestones = MILESTONES.filter(m => currentScore >= m.level);
  const currentMilestone = achievedMilestones[achievedMilestones.length - 1];

  // Recent trust events (last 5)
  const recentEvents = trustEvents
    .sort((a, b) => {
      const aTime = a.timestamp ? new Date(a.timestamp).getTime() : 0;
      const bTime = b.timestamp ? new Date(b.timestamp).getTime() : 0;
      return bTime - aTime;
    })
    .slice(0, 5);

  // Get score trend based on recent events
  const getScoreTrend = () => {
    if (recentEvents.length === 0) return null;
    const recentDeltas = recentEvents.slice(0, 3).map(e => e.delta);
    const avgDelta = recentDeltas.reduce((sum, delta) => sum + delta, 0) / recentDeltas.length;
    return avgDelta > 0 ? "up" : avgDelta < 0 ? "down" : "stable";
  };

  const scoreTrend = getScoreTrend();

  if (compact) {
    return (
      <div className={`flex items-center gap-2 ${className}`} data-testid="trust-badge-compact">
        {currentMilestone && (
          <Tooltip>
            <TooltipTrigger>
              <Badge variant="outline" className={`${currentMilestone.color} bg-white/80 dark:bg-slate-800/80`}>
                {currentMilestone.icon}
                <span className="ml-1">{currentMilestone.name}</span>
              </Badge>
            </TooltipTrigger>
            <TooltipContent>
              <p>{currentMilestone.description}</p>
              <p className="text-xs mt-1">Trust Score: {currentScore}</p>
            </TooltipContent>
          </Tooltip>
        )}
        
        <div className="flex items-center gap-1 text-sm text-slate-600 dark:text-slate-400">
          <Star className="h-3 w-3" />
          <span data-testid="trust-score">{currentScore}</span>
          {scoreTrend === "up" && <TrendingUp className="h-3 w-3 text-green-500" />}
          {scoreTrend === "down" && <TrendingDown className="h-3 w-3 text-red-500" />}
        </div>
      </div>
    );
  }

  return (
    <Card className={`bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm border-slate-200 dark:border-slate-700 ${className}`}>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-base">
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-blue-600" />
            <span>Trust Score</span>
            <Tooltip>
              <TooltipTrigger>
                <Info className="h-3 w-3 text-slate-400" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p className="text-sm">
                  Trust scores reflect your positive interactions and contributions. 
                  Higher scores unlock more reveal privileges in PIRP.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-blue-600" data-testid="trust-score-main">
              {currentScore}
            </span>
            {scoreTrend === "up" && <TrendingUp className="h-4 w-4 text-green-500" />}
            {scoreTrend === "down" && <TrendingDown className="h-4 w-4 text-red-500" />}
          </div>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Current Milestone */}
        {currentMilestone && (
          <div className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-700 rounded-lg">
            <div className={`p-2 rounded-full bg-white dark:bg-slate-600 ${currentMilestone.color}`}>
              {currentMilestone.icon}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="font-medium">{currentMilestone.name}</span>
                <Badge variant="secondary" className="text-xs">Current</Badge>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                {currentMilestone.description}
              </p>
            </div>
          </div>
        )}

        {/* Progress to Next Milestone */}
        {nextMilestone && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-600 dark:text-slate-400">
                Progress to {nextMilestone.name}
              </span>
              <span className="text-slate-600 dark:text-slate-400">
                {currentScore}/{nextMilestone.level}
              </span>
            </div>
            <Progress 
              value={progressValue} 
              className="h-2"
              data-testid="trust-progress"
            />
            <p className="text-xs text-slate-500 dark:text-slate-500">
              {nextMilestone.level - currentScore} points until {nextMilestone.name}
            </p>
          </div>
        )}

        {/* All Milestones Overview */}
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-slate-900 dark:text-white">Milestones</h4>
          <div className="grid grid-cols-2 gap-2">
            {MILESTONES.map((milestone) => {
              const isAchieved = currentScore >= milestone.level;
              return (
                <div
                  key={milestone.level}
                  className={`flex items-center gap-2 p-2 rounded-lg border text-xs ${
                    isAchieved
                      ? `bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 ${milestone.color}`
                      : "bg-slate-50 dark:bg-slate-700 border-slate-200 dark:border-slate-600 text-slate-400"
                  }`}
                  data-testid={`milestone-${milestone.level}`}
                >
                  <div className={`p-1 rounded ${isAchieved ? 'bg-white dark:bg-slate-600' : ''}`}>
                    {milestone.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{milestone.name}</div>
                    <div className="text-xs opacity-75">{milestone.level} pts</div>
                  </div>
                  {isAchieved && <Star className="h-3 w-3 text-gold-500" />}
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Activity */}
        {recentEvents.length > 0 && (
          <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
            <CollapsibleTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-between h-8 text-xs"
                data-testid="button-expand-events"
              >
                <span>Recent Activity ({recentEvents.length})</span>
                {isExpanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-2 mt-2">
              {recentEvents.map((event) => (
                <div
                  key={event.id}
                  className="flex items-center justify-between p-2 bg-slate-50 dark:bg-slate-700 rounded text-xs"
                  data-testid={`trust-event-${event.id}`}
                >
                  <div className="flex-1 min-w-0">
                    <p className="truncate font-medium">{event.reason}</p>
                    <p className="text-slate-500 dark:text-slate-400">
                      {event.timestamp ? new Date(event.timestamp).toLocaleString() : 'Recently'}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 ml-2">
                    <span
                      className={`font-medium ${
                        event.delta > 0 ? "text-green-600" : event.delta < 0 ? "text-red-600" : "text-slate-600"
                      }`}
                    >
                      {event.delta > 0 ? "+" : ""}{event.delta}
                    </span>
                    <span className="text-slate-400">→</span>
                    <span className="font-medium">{event.newScore}</span>
                  </div>
                </div>
              ))}
            </CollapsibleContent>
          </Collapsible>
        )}
      </CardContent>
    </Card>
  );
}