import { useState } from 'react';
import { runPreflight } from '@/utils/runPreflight';
import { ICE_SERVERS } from '@/webrtc/ice';
import { toast } from '@/utils/toast';

export default function PreCallCheck() {
  const [res, setRes] = useState<{ cam?: boolean; mic?: boolean; ice?: boolean } | null>(null);
  const [busy, setBusy] = useState(false);

  async function handle() {
    setBusy(true);
    const r = await runPreflight(ICE_SERVERS);
    setBusy(false);
    setRes(r);
    if (!r.cam) toast('No camera detected. Plug in or enable a camera.');
    if (!r.mic) toast('No mic detected. Connect or enable a microphone.');
    if (!r.ice) toast('Network cannot reach media servers (try mobile data or another Wi-Fi).');
    if (r.cam && r.mic && r.ice) toast('Pre-call check passed ✅');
  }

  return (
    <div className="flex items-center gap-2">
      <button 
        className="border rounded px-3 py-1 bg-white dark:bg-gray-800 text-black dark:text-white border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50" 
        disabled={busy} 
        onClick={handle}
        data-testid="button-precheck"
      >
        {busy ? 'Checking…' : 'Pre-call Check'}
      </button>
      {res && (
        <div className="text-xs opacity-80" data-testid="text-precheck-results">
          Cam: {res.cam ? '✓' : '✗'} · Mic: {res.mic ? '✓' : '✗'} · Network: {res.ice ? '✓' : '✗'}
        </div>
      )}
    </div>
  );
}