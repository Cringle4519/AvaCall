import { useState, useEffect } from "react";
import { Check, X, Clock, Shield, AlertTriangle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface ConsentRequest {
  requestId: string;
  requesterId: string;
  requesterName: string;
  currentLevel: number;
  requestedLevel: number;
  timestamp: string;
  expiresAt: string;
}

interface ConsentModalProps {
  isOpen: boolean;
  onClose: () => void;
  request: ConsentRequest | null;
  onDecision: (requestId: string, approved: boolean) => void;
  isProcessing?: boolean;
}

export default function ConsentModal({
  isOpen,
  onClose,
  request,
  onDecision,
  isProcessing = false
}: ConsentModalProps) {
  const [selectedDecision, setSelectedDecision] = useState<'approve' | 'deny' | null>(null);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const { toast } = useToast();

  // Real-time countdown
  useEffect(() => {
    if (!request) return;

    const updateTimer = () => {
      const remaining = new Date(request.expiresAt).getTime() - Date.now();
      setTimeRemaining(Math.max(0, remaining));
    };

    updateTimer(); // Initial update
    const interval = setInterval(updateTimer, 1000);

    return () => clearInterval(interval);
  }, [request]);

  if (!request) return null;

  const handleApprove = () => {
    setSelectedDecision('approve');
    onDecision(request.requestId, true);
  };

  const handleDeny = () => {
    setSelectedDecision('deny');
    onDecision(request.requestId, false);
  };

  const getPrivacyImpact = () => {
    const increase = request.requestedLevel - request.currentLevel;
    if (increase <= 0) return "No privacy impact";
    
    const percentage = increase;
    if (percentage <= 25) return "Low privacy impact";
    if (percentage <= 50) return "Moderate privacy impact";
    if (percentage <= 75) return "High privacy impact";
    return "Maximum privacy impact";
  };

  const getPrivacyImpactColor = () => {
    const increase = request.requestedLevel - request.currentLevel;
    if (increase <= 0) return "text-green-400";
    if (increase <= 25) return "text-yellow-400";
    if (increase <= 50) return "text-orange-400";
    return "text-red-400";
  };

  const minutesRemaining = Math.max(0, Math.ceil(timeRemaining / 60000));

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md" data-testid="consent-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Shield className="w-5 h-5 text-primary" />
            <span>Privacy Consent Request</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Request Details */}
          <div className="bg-gray-800/30 rounded-lg p-4 border border-gray-700">
            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-400 mb-1">Requesting User</p>
                <p className="font-medium text-gray-200" data-testid="requester-name">
                  {request.requesterName}
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-400 mb-1">Current Level</p>
                  <p className="text-lg font-bold text-gray-200" data-testid="current-level">
                    {request.currentLevel}%
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400 mb-1">Requested Level</p>
                  <p className="text-lg font-bold text-primary" data-testid="requested-level">
                    {request.requestedLevel}%
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Privacy Impact Assessment */}
          <div className="bg-gray-800/20 rounded-lg p-4 border border-gray-600">
            <div className="flex items-center space-x-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-yellow-400" />
              <span className="text-sm font-medium text-gray-300">Privacy Impact</span>
            </div>
            <p className={`text-sm font-medium ${getPrivacyImpactColor()}`}>
              {getPrivacyImpact()}
            </p>
            <p className="text-xs text-gray-400 mt-1">
              {request.requestedLevel > request.currentLevel 
                ? `This will reveal ${request.requestedLevel - request.currentLevel}% more of your video stream.`
                : "This request does not increase visibility."
              }
            </p>
          </div>

          {/* Time Remaining */}
          <div className="flex items-center justify-center space-x-2 text-sm text-gray-400">
            <Clock className="w-4 h-4" />
            <span data-testid="time-remaining">
              {minutesRemaining > 0 
                ? `${minutesRemaining} minute${minutesRemaining === 1 ? '' : 's'} remaining` 
                : "Request expired"
              }
            </span>
          </div>

          {/* Decision Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="outline"
              onClick={handleDeny}
              disabled={isProcessing || minutesRemaining === 0}
              className={`flex items-center justify-center space-x-2 ${
                selectedDecision === 'deny' ? 'bg-red-900/30 border-red-500' : ''
              }`}
              data-testid="button-deny"
            >
              <X className="w-4 h-4" />
              <span>Deny</span>
            </Button>
            
            <Button
              onClick={handleApprove}
              disabled={isProcessing || minutesRemaining === 0}
              className={`flex items-center justify-center space-x-2 ${
                selectedDecision === 'approve' ? 'bg-green-900/30 border-green-500' : ''
              }`}
              data-testid="button-approve"
            >
              <Check className="w-4 h-4" />
              <span>Approve</span>
            </Button>
          </div>

          {/* Processing State */}
          {isProcessing && (
            <div className="flex items-center justify-center space-x-2 text-sm text-gray-400">
              <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              <span>Processing decision...</span>
            </div>
          )}

          {/* Expired State */}
          {minutesRemaining === 0 && (
            <div className="text-center p-3 bg-red-900/20 border border-red-800 rounded-lg">
              <p className="text-sm text-red-400 font-medium">
                This consent request has expired
              </p>
              <p className="text-xs text-red-300 mt-1">
                The requesting user will need to send a new request
              </p>
            </div>
          )}

          {/* Privacy Notice */}
          <div className="text-center text-xs text-gray-500 bg-gray-800/20 p-3 rounded-lg">
            <p>
              Your privacy is protected by the PIRP system. You can revoke consent 
              at any time by adjusting your privacy level.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}