import { useMemo } from "react";

interface RevealMaskProps {
  level: number; // 0, 25, 50, 75, 100
  className?: string;
}

function fractionFor(level: number): number {
  // CRITICAL SECURITY: Default to maximum privacy (0%) for invalid inputs
  if (!Number.isFinite(level) || level < 0) return 0;
  
  // Exact level matching for PIRP system
  switch (level) {
    case 0: return 0;
    case 25: return 0.25;
    case 50: return 0.50;
    case 75: return 0.75;
    case 100: return 1;
    default:
      // PRIVACY-FIRST: Unknown levels default to 0% reveal (maximum privacy)
      console.warn(`Invalid reveal level: ${level}. Defaulting to 0% for privacy.`);
      return 0;
  }
}

export default function RevealMask({ level, className = "" }: RevealMaskProps) {
  const fraction = fractionFor(level);
  
  // Create a grid of tiles - 8x6 = 48 tiles for good granularity
  const gridCols = 8;
  const gridRows = 6;
  const totalTiles = gridCols * gridRows;
  
  // Calculate how many tiles should be revealed
  const tilesToReveal = Math.floor(totalTiles * fraction);
  
  // Generate tile positions in a spiral pattern from center outward for natural reveal effect
  const tilePositions = useMemo(() => {
    const positions: Array<{ row: number; col: number; index: number }> = [];
    
    // Create all tile positions
    for (let row = 0; row < gridRows; row++) {
      for (let col = 0; col < gridCols; col++) {
        positions.push({ row, col, index: row * gridCols + col });
      }
    }
    
    // Sort by distance from center for natural spiral reveal
    const centerRow = (gridRows - 1) / 2;
    const centerCol = (gridCols - 1) / 2;
    
    positions.sort((a, b) => {
      const distA = Math.sqrt(Math.pow(a.row - centerRow, 2) + Math.pow(a.col - centerCol, 2));
      const distB = Math.sqrt(Math.pow(b.row - centerRow, 2) + Math.pow(b.col - centerCol, 2));
      return distA - distB;
    });
    
    return positions;
  }, [gridRows, gridCols]);
  
  if (fraction >= 1) {
    // Fully revealed - no mask
    return null;
  }
  
  return (
    <div 
      className={`absolute inset-0 pointer-events-none z-20 ${className}`}
      style={{
        display: 'grid',
        gridTemplateColumns: `repeat(${gridCols}, 1fr)`,
        gridTemplateRows: `repeat(${gridRows}, 1fr)`,
      }}
      data-testid="reveal-mask"
    >
      {tilePositions.map((position, index) => {
        const isHidden = index >= tilesToReveal;
        
        return (
          <div
            key={`tile-${position.row}-${position.col}`}
            className={`transition-all duration-500 ease-in-out ${
              isHidden 
                ? 'bg-black/90 backdrop-blur-sm border border-white/10' 
                : 'bg-transparent'
            }`}
            style={{
              gridRow: position.row + 1,
              gridColumn: position.col + 1,
            }}
            data-testid={`mask-tile-${position.index}`}
          />
        );
      })}
      
      {/* Reveal Level Indicator */}
      {level > 0 && (
        <div className="absolute top-2 left-2 bg-black/80 text-white px-2 py-1 rounded text-xs font-medium">
          {level}% Revealed
        </div>
      )}
    </div>
  );
}