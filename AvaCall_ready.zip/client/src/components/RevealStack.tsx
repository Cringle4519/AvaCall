import React, { useMemo } from 'react';
import { FRACTION, type RevealLevel } from '@/reveal/levels';
import { seededShuffle } from '@/reveal/seededShuffle';

type Props = {
  avatarUrl?: string;    // stylized / 3D likeness (base) - optional for overlay mode
  realSrc?: { kind: 'img' | 'video'; src: string | MediaStream }; // real face layer - optional for overlay mode
  level: RevealLevel;   // 0 | 25 | 50 | 75 | 100
  seed: string;         // e.g. `${roomId}:${userId}`
  width?: number; height?: number; rounded?: boolean;
  className?: string; // Additional CSS classes for styling
};

const COLS = 14, ROWS = 14; // 196 tiles (fast on phones)

export default function RevealStack({
  avatarUrl, realSrc, level, seed, width = 320, height = 320, rounded = true, className = ""
}: Props) {
  const total = ROWS * COLS;
  const order = useMemo(() => seededShuffle(Array.from({ length: total }, (_, i) => i), seed), [seed]);
  const revealCount = Math.round(total * FRACTION[level]);

  return (
    <div className={`absolute inset-0 overflow-hidden ${className}`}
         style={{ borderRadius: rounded ? '9999px' : 16 }}
         data-testid="reveal-stack">
      {/* Base: avatar likeness (always visible) - only if provided */}
      {avatarUrl && (
        <img src={avatarUrl} alt="" className="absolute inset-0 w-full h-full object-cover" />
      )}

      {/* Middle: real face (full) - only if provided */}
      {realSrc && (
        realSrc.kind === 'img' ? (
          <img src={realSrc.src as string} alt="" className="absolute inset-0 w-full h-full object-cover" />
        ) : (
          <video
            className="absolute inset-0 w-full h-full object-cover"
            autoPlay playsInline muted
            ref={(el) => { if (el && realSrc.kind==='video') el.srcObject = realSrc.src as MediaStream; }}
          />
        )
      )}

      {/* Top: cover grid; we punch holes (transparent tiles) to REVEAL the real layer */}
      <div className="absolute inset-0"
           style={{ display:'grid', gridTemplateColumns:`repeat(${COLS},1fr)`, gridTemplateRows:`repeat(${ROWS},1fr)` }}>
        {Array.from({ length: total }).map((_, i) => {
          const tileIndex = order[i];
          const thisRevealed = i < revealCount; // first N tiles become transparent
          return (
            <div key={tileIndex}
                 style={{ background: thisRevealed ? 'transparent' : 'rgba(0,0,0,0.92)' }} />
          );
        })}
      </div>
    </div>
  );
}