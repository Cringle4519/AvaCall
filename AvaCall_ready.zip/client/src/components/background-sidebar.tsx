import { useState } from "react";
import { Image as ImageIcon, Upload, SearchSlash, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { BG_PRESETS } from "@/webrtc/backgrounds";
import { SCENES } from "@/scenes/scenes";

interface BackgroundSidebarProps {
  selectedBackground: string;
  onBackgroundSelect: (backgroundId: string, backgroundUrl?: string) => void;
  onSceneSelect?: (sceneId: string) => void; // New prop for scene selection
  blurIntensity: number;
  onBlurIntensityChange: (intensity: number) => void;
}

// Create background options from presets
type BackgroundOption = {
  id: string;
  name: string;
  type?: string;
  icon?: any;
  src?: string;
  alt?: string;
};

const backgroundOptions: BackgroundOption[] = [
  {
    id: "blur",
    type: "blur",
    name: "Blur",
    icon: SearchSlash
  },
  ...BG_PRESETS.map(preset => ({
    id: preset.id,
    src: preset.image.replace('w=1920&h=1080', 'w=160&h=100'), // Use smaller thumbnail
    name: preset.label,
    alt: `${preset.label} background`
  }))
];

export default function BackgroundSidebar({
  selectedBackground,
  onBackgroundSelect,
  onSceneSelect,
  blurIntensity,
  onBlurIntensityChange
}: BackgroundSidebarProps) {
  const [customBackgrounds, setCustomBackgrounds] = useState<Array<{ id: string; url: string; filename: string }>>([]);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const handleCustomBackgroundUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 10MB",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);

    try {
      const formData = new FormData();
      formData.append('background', file);

      const response = await fetch('/api/upload/background', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const result = await response.json();
      const newBackground = {
        id: `custom-${Date.now()}`,
        url: result.url,
        filename: result.filename
      };

      setCustomBackgrounds(prev => [...prev, newBackground]);
      onBackgroundSelect(newBackground.id, result.url);

      toast({
        title: "Background uploaded successfully",
        description: "Your custom background is ready to use",
      });

      // Clear the input
      event.target.value = '';
    } catch (error) {
      console.error('Background upload error:', error);
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload background",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const removeCustomBackground = (backgroundId: string) => {
    setCustomBackgrounds(prev => prev.filter(bg => bg.id !== backgroundId));
    
    // If the removed background was selected, fall back to blur
    if (selectedBackground === backgroundId) {
      onBackgroundSelect("blur", "");
    }
  };

  return (
    <div className="w-80 p-6 border-l border-border">
      <div className="sidebar-panel p-6">
        <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center">
          <ImageIcon className="mr-2 text-secondary w-5 h-5" />
          Virtual Backgrounds
        </h2>
        
        {/* Background Options Grid */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {backgroundOptions.map((background) => (
            <div
              key={background.id}
              className={`background-option ${selectedBackground === background.id ? 'selected' : ''}`}
              onClick={() => {
                const preset = BG_PRESETS.find(p => p.id === background.id);
                onBackgroundSelect(background.id, preset?.image || background.src || "");
                
                // Auto-select matching scene when background is chosen
                const matchingScene = SCENES.find(scene => scene.bgId === background.id);
                if (matchingScene && onSceneSelect) {
                  onSceneSelect(matchingScene.id);
                }
              }}
              data-testid={`background-option-${background.id}`}
            >
              {background.type === "blur" ? (
                <div className="w-full h-20 bg-gradient-to-br from-muted to-accent rounded-lg flex items-center justify-center">
                  <SearchSlash className="text-muted-foreground w-6 h-6" />
                </div>
              ) : (
                <img 
                  src={background.src}
                  alt={background.alt}
                  className="w-full h-20 object-cover rounded-lg"
                />
              )}
              <span className="text-xs text-muted-foreground mt-1 block text-center">
                {background.name}
              </span>
            </div>
          ))}

          {/* Custom Background Options */}
          {customBackgrounds.map((background) => (
            <div
              key={background.id}
              className={`background-option ${selectedBackground === background.id ? 'selected' : ''} relative group`}
              onClick={() => onBackgroundSelect(background.id, background.url)}
              data-testid={`background-option-${background.id}`}
            >
              <img 
                src={background.url}
                alt="Custom background"
                className="w-full h-20 object-cover rounded-lg"
              />
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  removeCustomBackground(background.id);
                }}
                className="absolute top-1 right-1 w-5 h-5 bg-destructive text-destructive-foreground rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-xs"
                data-testid={`button-remove-background-${background.id}`}
              >
                <X className="w-3 h-3" />
              </button>
              <span className="text-xs text-muted-foreground mt-1 block text-center">
                Custom
              </span>
            </div>
          ))}
        </div>

        {/* Background Controls */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Background Blur
            </label>
            <input 
              type="range" 
              min="0" 
              max="100" 
              value={blurIntensity}
              onChange={(e) => onBlurIntensityChange(parseInt(e.target.value))}
              className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
              data-testid="slider-blur-intensity"
            />
          </div>
          
          <div>
            <input
              type="file"
              accept="image/*"
              onChange={handleCustomBackgroundUpload}
              className="hidden"
              id="custom-background-upload"
            />
            <label 
              htmlFor="custom-background-upload"
              className={`w-full p-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors cursor-pointer flex items-center justify-center ${isUploading ? 'opacity-50 cursor-not-allowed' : ''}`}
              data-testid="button-upload-background"
            >
              <Upload className="w-4 h-4 mr-2" />
              {isUploading ? 'Uploading...' : 'Upload Custom Background'}
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}
