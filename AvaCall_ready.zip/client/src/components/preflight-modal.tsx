import { useState, useEffect } from "react";
import { Camera, Mic, Wifi, Gauge, CheckCircle, XCircle, AlertCircle, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { runPreflight, getPreflightScore, getPreflightMessage } from "@/lib/preflight";

interface PreflightModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  iceServers: RTCIceServer[];
}

export default function PreflightModal({ isOpen, onClose, onSuccess, iceServers }: PreflightModalProps) {
  const [isRunning, setIsRunning] = useState(false);
  const [report, setReport] = useState<any>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (isOpen && !report) {
      runPreflightCheck();
    }
  }, [isOpen]);

  const runPreflightCheck = async () => {
    setIsRunning(true);
    setProgress(0);
    
    try {
      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setProgress(prev => Math.min(prev + 10, 90));
      }, 300);

      const result = await runPreflight(iceServers);
      
      clearInterval(progressInterval);
      setProgress(100);
      setReport(result);
    } catch (error) {
      console.error('Preflight check failed:', error);
      setReport({
        devices: [],
        camOk: false,
        micOk: false,
        iceOk: false,
        bitrateKbps: 0,
        errors: ['Preflight check failed to run']
      });
    } finally {
      setIsRunning(false);
    }
  };

  const getStatusIcon = (status: boolean) => {
    if (status) return <CheckCircle className="w-5 h-5 text-green-500" data-testid="icon-success" />;
    return <XCircle className="w-5 h-5 text-red-500" data-testid="icon-error" />;
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-500";
    if (score >= 60) return "text-yellow-500";
    return "text-red-500";
  };

  const score = report ? getPreflightScore(report) : 0;
  const canProceed = score >= 40; // Minimum threshold to allow call

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]" data-testid="modal-preflight">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            System Check
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {isRunning && (
            <div className="space-y-4">
              <div className="text-center">
                <p className="text-muted-foreground">Testing your camera, microphone, and network...</p>
              </div>
              <Progress value={progress} className="w-full" data-testid="progress-check" />
            </div>
          )}

          {report && !isRunning && (
            <div className="space-y-4">
              {/* Overall Score */}
              <div className="text-center p-4 border rounded-lg">
                <div className={`text-2xl font-bold ${getScoreColor(score)}`} data-testid="text-score">
                  {score}/100
                </div>
                <p className="text-sm text-muted-foreground mt-1" data-testid="text-score-message">
                  {getPreflightMessage(report)}
                </p>
              </div>

              {/* Individual Tests */}
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 border rounded-lg" data-testid="check-camera">
                  <div className="flex items-center gap-3">
                    <Camera className="w-5 h-5" />
                    <span>Camera</span>
                  </div>
                  {getStatusIcon(report.camOk)}
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg" data-testid="check-microphone">
                  <div className="flex items-center gap-3">
                    <Mic className="w-5 h-5" />
                    <span>Microphone</span>
                  </div>
                  {getStatusIcon(report.micOk)}
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg" data-testid="check-network">
                  <div className="flex items-center gap-3">
                    <Wifi className="w-5 h-5" />
                    <span>Network Connectivity</span>
                  </div>
                  {getStatusIcon(report.iceOk)}
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg" data-testid="check-bitrate">
                  <div className="flex items-center gap-3">
                    <Gauge className="w-5 h-5" />
                    <span>Connection Speed</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground" data-testid="text-bitrate">
                      {report.bitrateKbps > 0 ? `${report.bitrateKbps} kbps` : 'Unknown'}
                    </span>
                    {getStatusIcon(report.bitrateKbps > 100)}
                  </div>
                </div>
              </div>

              {/* Errors */}
              {report.errors.length > 0 && (
                <div className="p-3 border border-yellow-200 rounded-lg bg-yellow-50" data-testid="section-errors">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="w-4 h-4 text-yellow-600" />
                    <span className="font-medium text-yellow-800">Issues Detected</span>
                  </div>
                  <ul className="text-sm text-yellow-700 space-y-1">
                    {report.errors.map((error: string, index: number) => (
                      <li key={index} data-testid={`error-${index}`}>• {error}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3 pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => runPreflightCheck()}
                  className="flex-1"
                  data-testid="button-retest"
                >
                  Run Test Again
                </Button>
                
                {canProceed ? (
                  <Button 
                    onClick={onSuccess}
                    className="flex-1"
                    data-testid="button-proceed"
                  >
                    Continue to Call
                  </Button>
                ) : (
                  <Button 
                    onClick={onClose}
                    variant="destructive"
                    className="flex-1"
                    data-testid="button-cancel"
                  >
                    Cancel
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}