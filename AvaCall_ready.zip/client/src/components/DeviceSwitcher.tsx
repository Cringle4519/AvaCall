import { useEffect, useState } from 'react';

type Props = {
  pc: RTCPeerConnection | null;
  localStream: MediaStream | null;
  onStreamReplace?: (stream: MediaStream) => void;
};

export default function DeviceSwitcher({ pc, localStream, onStreamReplace }: Props) {
  const [cams, setCams] = useState<MediaDeviceInfo[]>([]);
  const [mics, setMics] = useState<MediaDeviceInfo[]>([]);
  const [camId, setCamId] = useState<string>('');
  const [micId, setMicId] = useState<string>('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      const devs = await navigator.mediaDevices.enumerateDevices();
      setCams(devs.filter(d => d.kind === 'videoinput'));
      setMics(devs.filter(d => d.kind === 'audioinput'));
      const curCam = localStream?.getVideoTracks()[0]?.getSettings().deviceId || '';
      const curMic = localStream?.getAudioTracks()[0]?.getSettings().deviceId || '';
      setCamId(curCam); 
      setMicId(curMic);
    })();
  }, [localStream]);

  async function apply(kind: 'video'|'audio', deviceId: string) {
    if (!pc) return;
    setBusy(true);
    try {
      const constraints = kind === 'video' 
        ? { video: { deviceId: { exact: deviceId } } } 
        : { audio: { deviceId: { exact: deviceId } } };
      const newStream = await navigator.mediaDevices.getUserMedia(constraints as any);
      const newTrack = kind === 'video' ? newStream.getVideoTracks()[0] : newStream.getAudioTracks()[0];

      // Replace sender track
      const sender = pc.getSenders().find(s => s.track?.kind === newTrack.kind);
      if (sender) await sender.replaceTrack(newTrack);

      // Stop old track of same kind
      localStream?.getTracks().forEach(t => { if (t.kind === newTrack.kind) t.stop(); });

      // Merge into existing localStream (if provided)
      if (localStream) {
        const others = localStream.getTracks().filter(t => t.kind !== newTrack.kind);
        const merged = new MediaStream([...others, newTrack]);
        onStreamReplace?.(merged);
      }
    } catch (error) {
      console.error('Device switch error:', error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex gap-2 items-center text-sm">
      <select 
        className="border rounded px-2 py-1 bg-white dark:bg-gray-800 text-black dark:text-white border-gray-300 dark:border-gray-600" 
        value={camId} 
        onChange={e => { setCamId(e.target.value); apply('video', e.target.value); }} 
        disabled={busy}
        data-testid="select-camera"
      >
        <option value="">Camera…</option>
        {cams.map(d => <option key={d.deviceId} value={d.deviceId}>{d.label || 'Camera'}</option>)}
      </select>
      <select 
        className="border rounded px-2 py-1 bg-white dark:bg-gray-800 text-black dark:text-white border-gray-300 dark:border-gray-600" 
        value={micId} 
        onChange={e => { setMicId(e.target.value); apply('audio', e.target.value); }} 
        disabled={busy}
        data-testid="select-microphone"
      >
        <option value="">Microphone…</option>
        {mics.map(d => <option key={d.deviceId} value={d.deviceId}>{d.label || 'Microphone'}</option>)}
      </select>
    </div>
  );
}