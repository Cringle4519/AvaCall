import React from 'react';

export default function InviteModal({ invite, onClose }:{invite:string; onClose:()=>void}) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center">
      <div className="bg-white text-black rounded-lg p-4 w-[90%] max-w-md">
        <h2 className="text-lg font-bold mb-2">Invite</h2>
        <input className="w-full border p-2 rounded" value={invite} readOnly />
        <div className="mt-3 flex gap-2">
          <button className="bg-blue-600 text-white px-3 py-1 rounded"
                  onClick={() => navigator.clipboard.writeText(invite)}>Copy Link</button>
          <button className="border px-3 py-1 rounded" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}