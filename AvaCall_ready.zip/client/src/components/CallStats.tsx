import React, { useEffect, useRef, useState } from 'react';

type Props = { pc: RTCPeerConnection | null };

export default function CallStats({ pc }: Props) {
  const [bitrateKbps, setBitrateKbps] = useState(0);
  const [jitter, setJitter] = useState<number | null>(null);
  const [packetsLost, setPacketsLost] = useState<number | null>(null);
  const prevBytes = useRef<number>(0);
  const prevTime = useRef<number>(0);

  useEffect(() => {
    const id = setInterval(async () => {
      if (!pc) return;
      const stats = await pc.getStats();
      let bytesSent = 0;
      let ts = 0;
      stats.forEach((s: any) => {
        if (s.type === 'outbound-rtp' && s.kind === 'video' && !s.isRemote) {
          bytesSent = s.bytesSent ?? bytesSent;
          ts = s.timestamp ?? ts;
        }
        if (s.type === 'remote-inbound-rtp' && s.kind === 'video') {
          if (typeof s.jitter === 'number') setJitter(s.jitter);
          if (typeof s.packetsLost === 'number') setPacketsLost(s.packetsLost);
        }
      });
      if (prevTime.current && prevBytes.current && ts && bytesSent) {
        const deltaBytes = bytesSent - prevBytes.current;
        const deltaTimeSec = (ts - prevTime.current) / 1000;
        const kbps = Math.round((deltaBytes * 8) / 1000 / (deltaTimeSec || 1));
        setBitrateKbps(kbps);
      }
      prevBytes.current = bytesSent;
      prevTime.current = ts;
    }, 2000);
    return () => clearInterval(id);
  }, [pc]);

  return (
    <div className="fixed right-3 bottom-3 text-xs rounded-md bg-black/70 text-white px-3 py-2 shadow">
      <div>Bitrate: {bitrateKbps} kbps</div>
      <div>Jitter: {jitter ?? '-'} </div>
      <div>Packet Loss: {packetsLost ?? '-'}</div>
    </div>
  );
}