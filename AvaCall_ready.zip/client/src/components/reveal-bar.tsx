import { useState } from "react";
import { Eye, EyeOff, Shield, Lock } from "lucide-react";

interface RevealBarProps {
  currentLevel: number;
  onLevelChange: (level: number) => void;
  className?: string;
  disabled?: boolean;
}

const REVEAL_LEVELS = [0, 25, 50, 75, 100] as const;

const getLevelIcon = (level: number) => {
  switch (level) {
    case 0: return <Lock className="w-4 h-4" />;
    case 25: return <Shield className="w-4 h-4" />;
    case 50: return <EyeOff className="w-4 h-4" />;
    case 75: return <Eye className="w-4 h-4" />;
    case 100: return <Eye className="w-4 h-4" />;
    default: return <Lock className="w-4 h-4" />;
  }
};

const getLevelLabel = (level: number) => {
  switch (level) {
    case 0: return "Private";
    case 25: return "Limited";
    case 50: return "Partial";
    case 75: return "Mostly";
    case 100: return "Full";
    default: return "Private";
  }
};

const getLevelDescription = (level: number) => {
  switch (level) {
    case 0: return "Completely hidden";
    case 25: return "Minimal visibility";
    case 50: return "Half revealed";
    case 75: return "Mostly visible";
    case 100: return "Fully revealed";
    default: return "Completely hidden";
  }
};

export default function RevealBar({ 
  currentLevel, 
  onLevelChange, 
  className = "",
  disabled = false 
}: RevealBarProps) {
  const [pendingLevel, setPendingLevel] = useState<number | null>(null);
  
  const handleLevelClick = (level: number) => {
    if (disabled) return;
    
    if (level === currentLevel) return; // No change needed
    
    // Set pending state to show user intent
    setPendingLevel(level);
    
    // Immediately call the change handler
    // In real implementation, this would trigger consent flow for level increases
    onLevelChange(level);
    
    // Clear pending state after a short delay
    setTimeout(() => setPendingLevel(null), 500);
  };

  return (
    <div className={`reveal-bar ${className}`} data-testid="reveal-bar">
      {/* Current Level Display */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2">
            {getLevelIcon(currentLevel)}
            <span className="text-sm font-medium text-gray-200">
              Privacy Level: {getLevelLabel(currentLevel)}
            </span>
          </div>
          <span className="text-lg font-bold text-primary">
            {currentLevel}%
          </span>
        </div>
        <p className="text-xs text-gray-400">
          {getLevelDescription(currentLevel)}
        </p>
      </div>

      {/* Level Selection Buttons */}
      <div className="space-y-2">
        <p className="text-xs font-medium text-gray-300 mb-3">
          Select reveal level:
        </p>
        
        <div className="grid grid-cols-5 gap-2">
          {REVEAL_LEVELS.map((level) => {
            const isActive = level === currentLevel;
            const isPending = level === pendingLevel;
            const isDisabled = disabled;
            
            return (
              <button
                key={level}
                onClick={() => handleLevelClick(level)}
                disabled={isDisabled}
                className={`
                  relative flex flex-col items-center justify-center p-3 rounded-lg
                  border-2 transition-all duration-200 min-h-[80px]
                  ${isActive 
                    ? 'border-primary bg-primary/20 text-primary' 
                    : 'border-gray-600 bg-gray-800/50 text-gray-300 hover:border-gray-500 hover:bg-gray-700/50'
                  }
                  ${isPending ? 'ring-2 ring-yellow-400 ring-opacity-50' : ''}
                  ${isDisabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
                `}
                data-testid={`reveal-level-${level}`}
              >
                {/* Icon */}
                <div className={`mb-1 ${isActive ? 'text-primary' : 'text-gray-400'}`}>
                  {getLevelIcon(level)}
                </div>
                
                {/* Percentage */}
                <span className={`text-sm font-bold ${isActive ? 'text-primary' : 'text-gray-200'}`}>
                  {level}%
                </span>
                
                {/* Label */}
                <span className={`text-xs ${isActive ? 'text-primary' : 'text-gray-400'}`}>
                  {getLevelLabel(level)}
                </span>
                
                {/* Active Indicator */}
                {isActive && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-primary rounded-full border-2 border-gray-900" />
                )}
                
                {/* Pending Indicator */}
                {isPending && (
                  <div className="absolute inset-0 bg-yellow-400/10 rounded-lg animate-pulse" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Privacy Notice */}
      <div className="mt-4 p-3 bg-gray-800/30 rounded-lg border border-gray-700">
        <div className="flex items-start space-x-2">
          <Shield className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-xs font-medium text-blue-400 mb-1">
              Privacy Protected
            </p>
            <p className="text-xs text-gray-400 leading-relaxed">
              Level increases require mutual consent. Your privacy is always under your control.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}