import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Send } from "lucide-react";
import { cn } from "@/lib/utils";

export interface ChatMessage {
  id: string;
  roomId: string;
  userId: string;
  message: string;
  messageType: 'text' | 'system' | 'join' | 'leave';
  timestamp: Date;
  senderClientId?: string;
}

interface InCallChatProps {
  roomId: string | null;
  currentUserId: string | null;
  currentClientId: string | null;
  onSendMessage: (message: string) => void;
  messages: ChatMessage[];
  className?: string;
}

export function InCallChat({ 
  roomId, 
  currentUserId, 
  currentClientId, 
  onSendMessage, 
  messages, 
  className 
}: InCallChatProps) {
  const [newMessage, setNewMessage] = useState("");
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollElement = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollElement) {
        scrollElement.scrollTop = scrollElement.scrollHeight;
      }
    }
  }, [messages]);

  const handleSendMessage = () => {
    if (newMessage.trim() && roomId) {
      onSendMessage(newMessage.trim());
      setNewMessage("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (timestamp: Date) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
  };

  const isOwnMessage = (message: ChatMessage) => {
    return message.senderClientId === currentClientId || message.userId === currentUserId;
  };

  const getUserDisplayName = (message: ChatMessage) => {
    if (isOwnMessage(message)) {
      return "You";
    }
    return `User ${message.userId?.slice(-4) || 'Unknown'}`;
  };

  return (
    <Card className={cn("flex flex-col h-full", className)} data-testid="chat-container">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          💬 Chat
          <span className="text-sm text-muted-foreground font-normal">
            ({messages.length} messages)
          </span>
        </CardTitle>
      </CardHeader>
      
      <Separator />
      
      <CardContent className="flex-1 flex flex-col p-4 space-y-4">
        {/* Chat Messages */}
        <ScrollArea ref={scrollAreaRef} className="flex-1 pr-4" data-testid="chat-messages">
          <div className="space-y-3">
            {messages.length === 0 ? (
              <div className="text-center text-muted-foreground py-8" data-testid="chat-empty">
                <p>No messages yet</p>
                <p className="text-sm">Start the conversation!</p>
              </div>
            ) : (
              messages.map((message) => (
                <div 
                  key={message.id} 
                  className={cn(
                    "flex flex-col space-y-1",
                    isOwnMessage(message) ? "items-end" : "items-start"
                  )}
                  data-testid={`chat-message-${message.id}`}
                >
                  {message.messageType === 'system' ? (
                    <div className="text-center w-full">
                      <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">
                        {message.message}
                      </span>
                    </div>
                  ) : (
                    <>
                      <div className={cn(
                        "max-w-[80%] rounded-lg px-3 py-2 text-sm",
                        isOwnMessage(message)
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground"
                      )}>
                        {message.message}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span data-testid={`chat-sender-${message.id}`}>
                          {getUserDisplayName(message)}
                        </span>
                        <span>•</span>
                        <span data-testid={`chat-timestamp-${message.id}`}>
                          {formatTime(message.timestamp)}
                        </span>
                      </div>
                    </>
                  )}
                </div>
              ))
            )}
          </div>
        </ScrollArea>

        {/* Message Input */}
        <div className="flex gap-2" data-testid="chat-input-container">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={roomId ? "Type a message..." : "Join a room to chat"}
            disabled={!roomId}
            className="flex-1"
            data-testid="input-chat-message"
          />
          <Button
            onClick={handleSendMessage}
            disabled={!newMessage.trim() || !roomId}
            size="icon"
            data-testid="button-send-message"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}