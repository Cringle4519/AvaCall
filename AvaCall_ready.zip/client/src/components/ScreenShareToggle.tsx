import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Monitor, MonitorOff } from "lucide-react";
import { cn } from "@/lib/utils";

interface ScreenShareToggleProps {
  isScreenSharing: boolean;
  onToggleScreenShare: () => Promise<void>;
  disabled?: boolean;
  className?: string;
}

export function ScreenShareToggle({ 
  isScreenSharing, 
  onToggleScreenShare, 
  disabled = false,
  className 
}: ScreenShareToggleProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleToggle = async () => {
    if (disabled || isLoading) return;
    
    setIsLoading(true);
    try {
      await onToggleScreenShare();
    } catch (error) {
      console.error('Screen share toggle error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getTooltipText = () => {
    if (disabled) return "Screen sharing not available";
    if (isScreenSharing) return "Stop screen sharing";
    return "Start screen sharing";
  };

  const getButtonText = () => {
    if (isLoading) return "Loading...";
    if (isScreenSharing) return "Stop Sharing";
    return "Share Screen";
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant={isScreenSharing ? "default" : "outline"}
            size="sm"
            onClick={handleToggle}
            disabled={disabled || isLoading}
            className={cn(
              "flex items-center gap-2 transition-all",
              isScreenSharing && "bg-blue-600 hover:bg-blue-700 text-white",
              className
            )}
            data-testid="button-screen-share"
          >
            {isScreenSharing ? (
              <MonitorOff className="h-4 w-4" data-testid="icon-screen-sharing-off" />
            ) : (
              <Monitor className="h-4 w-4" data-testid="icon-screen-sharing-on" />
            )}
            <span data-testid="text-screen-share-status">
              {getButtonText()}
            </span>
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{getTooltipText()}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}