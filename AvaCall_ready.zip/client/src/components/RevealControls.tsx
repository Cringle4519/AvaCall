import React from 'react';
import { ORDER, nextLevel, prevLevel, type RevealLevel } from '@/reveal/levels';

export default function RevealControls({
  level, onRequest
}: { level: RevealLevel; onRequest: (target: RevealLevel)=>void }) {
  return (
    <div className="flex items-center gap-2" data-testid="reveal-controls">
      <button 
        className="border rounded px-2 py-1 text-sm hover:bg-accent transition-colors" 
        onClick={()=> onRequest(prevLevel(level))}
        data-testid="button-reveal-hide"
      >
        Hide
      </button>
      <div className="text-sm opacity-80">Reveal: {level}%</div>
      <button 
        className="border rounded px-2 py-1 text-sm hover:bg-accent transition-colors" 
        onClick={()=> onRequest(nextLevel(level))}
        data-testid="button-reveal-more"
      >
        More
      </button>
      <div className="flex gap-1 ml-2">
        {ORDER.map(v => (
          <button key={v}
                  className={`w-8 h-6 rounded text-xs transition-colors ${v===level ? 'bg-blue-600 text-white':'border hover:bg-accent'}`}
                  onClick={()=> onRequest(v)}
                  data-testid={`button-reveal-level-${v}`}>{v}</button>
        ))}
      </div>
    </div>
  );
}