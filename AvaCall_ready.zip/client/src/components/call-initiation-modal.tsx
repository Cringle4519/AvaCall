import { useState } from "react";
import { Video, LogIn, Shuffle, X } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface CallInitiationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartCall: (roomId: string) => void;
  onJoinCall: (roomId: string) => void;
  generateRoomId: () => string;
}

export default function CallInitiationModal({
  isOpen,
  onClose,
  onStartCall,
  onJoinCall,
  generateRoomId
}: CallInitiationModalProps) {
  const [roomId, setRoomId] = useState("");

  const handleGenerateRoomId = () => {
    const newRoomId = generateRoomId();
    setRoomId(newRoomId);
  };

  const handleStartCall = () => {
    if (roomId.trim()) {
      onStartCall(roomId.trim());
    }
  };

  const handleJoinCall = () => {
    if (roomId.trim()) {
      onJoinCall(roomId.trim());
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-md bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center">
            Start Video Call
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 p-6">
          <div>
            <Label htmlFor="roomId" className="text-sm font-medium text-muted-foreground">
              Room ID
            </Label>
            <Input
              id="roomId"
              type="text"
              placeholder="Enter room ID or generate new"
              value={roomId}
              onChange={(e) => setRoomId(e.target.value)}
              className="mt-2"
              data-testid="input-room-id"
            />
          </div>
          
          <Button
            onClick={handleGenerateRoomId}
            variant="outline"
            className="w-full"
            data-testid="button-generate-room-id"
          >
            <Shuffle className="w-4 h-4 mr-2" />
            Generate Random Room ID
          </Button>
          
          <div className="flex space-x-3">
            <Button
              onClick={handleStartCall}
              className="flex-1"
              disabled={!roomId.trim()}
              data-testid="button-start-call"
            >
              <Video className="w-4 h-4 mr-2" />
              Start Call
            </Button>
            
            <Button
              onClick={handleJoinCall}
              variant="secondary"
              className="flex-1"
              disabled={!roomId.trim()}
              data-testid="button-join-call"
            >
              <LogIn className="w-4 h-4 mr-2" />
              Join Call
            </Button>
          </div>
          
          <Button
            onClick={onClose}
            variant="ghost"
            className="w-full"
            data-testid="button-cancel"
          >
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
