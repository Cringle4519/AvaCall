import React from 'react';

export default function AvatarMouth({ level }: { level: number }) {
  // 1.0..1.5 scale feels natural
  const s = 1 + Math.min(level * 0.5, 0.5);
  return (
    <div
      className="absolute left-1/2 -translate-x-1/2 rounded-full bg-black/70"
      style={{ bottom: 14, width: 64, height: 10, transform: `scaleY(${s})` }}
    />
  );
}