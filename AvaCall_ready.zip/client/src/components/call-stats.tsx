import { useState, useEffect } from "react";
import { Activity, Wifi, WifiOff } from "lucide-react";

interface CallStatsProps {
  peerConnection: RTCPeerConnection | null;
  isVisible?: boolean;
}

interface Stats {
  bitrate: number;
  jitter: number;
  packetLoss: number;
  packetsReceived: number;
  bytesSent: number;
  bytesReceived: number;
  connectionState: RTCPeerConnectionState;
}

export default function CallStats({ peerConnection, isVisible = true }: CallStatsProps) {
  const [stats, setStats] = useState<Stats>({
    bitrate: 0,
    jitter: 0,
    packetLoss: 0,
    packetsReceived: 0,
    bytesSent: 0,
    bytesReceived: 0,
    connectionState: 'new'
  });

  const [previousBytesSent, setPreviousBytesSent] = useState(0);
  const [previousPacketsReceived, setPreviousPacketsReceived] = useState(0);
  const [previousPacketsLost, setPreviousPacketsLost] = useState(0);
  const [previousTimestamp, setPreviousTimestamp] = useState(0);

  useEffect(() => {
    if (!peerConnection || !isVisible) return;

    const interval = setInterval(async () => {
      try {
        const reports = await peerConnection.getStats();
        let currentBytesSent = 0;
        let currentBytesReceived = 0;
        let currentPacketsReceived = 0;
        let currentPacketLoss = 0;
        let currentJitter = 0;
        let currentTimestamp = Date.now();

        reports.forEach(report => {
          const isVideo = report.kind === 'video' || report.mediaType === 'video';
          
          // Outbound video stats (sum across all video encodings for simulcast)
          if (report.type === 'outbound-rtp' && isVideo) {
            currentBytesSent += report.bytesSent || 0;
          }

          // Inbound video stats (for reception quality)
          if (report.type === 'inbound-rtp' && isVideo) {
            currentBytesReceived = report.bytesReceived || 0;
            currentPacketsReceived = report.packetsReceived || 0;
            currentPacketLoss = report.packetsLost || 0;
            currentJitter = Math.round((report.jitter || 0) * 1000); // Convert to ms
          }

          // Remote inbound stats (for RTT and quality feedback)
          if (report.type === 'remote-inbound-rtp' && isVideo) {
            const remotePacketLoss = report.packetsLost || 0;
            const remoteJitter = Math.round((report.jitter || 0) * 1000);
            
            // Use remote stats if available (more accurate)
            if (remotePacketLoss > currentPacketLoss) {
              currentPacketLoss = remotePacketLoss;
            }
            if (remoteJitter > currentJitter) {
              currentJitter = remoteJitter;
            }
          }
        });

        // Calculate bitrate (kbps)
        let bitrate = 0;
        if (previousBytesSent > 0 && previousTimestamp > 0) {
          const bytesDiff = currentBytesSent - previousBytesSent;
          const timeDiff = (currentTimestamp - previousTimestamp) / 1000; // seconds
          bitrate = Math.round((bytesDiff * 8) / timeDiff / 1000); // Convert to kbps
        }

        // Calculate packet loss percentage over interval
        let packetLossPercentage = 0;
        if (previousPacketsReceived > 0 && previousTimestamp > 0) {
          const packetsLostDiff = currentPacketLoss - previousPacketsLost;
          const packetsReceivedDiff = currentPacketsReceived - previousPacketsReceived;
          const totalPacketsDiff = packetsLostDiff + packetsReceivedDiff;
          
          if (totalPacketsDiff > 0) {
            packetLossPercentage = Math.round((packetsLostDiff / totalPacketsDiff) * 100);
          }
        }

        setPreviousBytesSent(currentBytesSent);
        setPreviousPacketsReceived(currentPacketsReceived);
        setPreviousPacketsLost(currentPacketLoss);
        setPreviousTimestamp(currentTimestamp);

        setStats({
          bitrate,
          jitter: currentJitter,
          packetLoss: packetLossPercentage,
          packetsReceived: currentPacketsReceived,
          bytesSent: currentBytesSent,
          bytesReceived: currentBytesReceived,
          connectionState: peerConnection.connectionState
        });

      } catch (error) {
        console.error('Error getting WebRTC stats:', error);
      }
    }, 2000); // Update every 2 seconds

    return () => clearInterval(interval);
  }, [peerConnection, isVisible, previousBytesSent, previousTimestamp]);

  if (!isVisible || !peerConnection) {
    return null;
  }

  const getConnectionIcon = () => {
    switch (stats.connectionState) {
      case 'connected':
        return <Wifi className="w-3 h-3 text-green-400" />;
      case 'connecting':
        return <Activity className="w-3 h-3 text-yellow-400 animate-pulse" />;
      case 'disconnected':
      case 'failed':
        return <WifiOff className="w-3 h-3 text-red-400" />;
      default:
        return <Activity className="w-3 h-3 text-gray-400" />;
    }
  };

  const getBitrateColor = () => {
    if (stats.bitrate > 1000) return "text-green-400";
    if (stats.bitrate > 500) return "text-yellow-400";
    return "text-red-400";
  };

  const getJitterColor = () => {
    if (stats.jitter < 30) return "text-green-400";
    if (stats.jitter < 100) return "text-yellow-400";
    return "text-red-400";
  };

  const getPacketLossColor = () => {
    if (stats.packetLoss === 0) return "text-green-400";
    if (stats.packetLoss < 5) return "text-yellow-400";
    return "text-red-400";
  };

  return (
    <div 
      className="absolute bottom-4 right-4 bg-black/80 backdrop-blur-sm text-white text-xs p-3 rounded-lg border border-gray-600 min-w-[180px]"
      data-testid="call-stats-overlay"
    >
      <div className="flex items-center justify-between mb-2">
        <span className="font-medium text-gray-300">Call Quality</span>
        {getConnectionIcon()}
      </div>
      
      <div className="space-y-1">
        <div className="flex justify-between items-center">
          <span className="text-gray-400">Bitrate:</span>
          <span className={`font-mono ${getBitrateColor()}`} data-testid="bitrate-value">
            {stats.bitrate} kbps
          </span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-gray-400">Jitter:</span>
          <span className={`font-mono ${getJitterColor()}`} data-testid="jitter-value">
            {stats.jitter}ms
          </span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-gray-400">Loss:</span>
          <span className={`font-mono ${getPacketLossColor()}`} data-testid="packet-loss-value">
            {stats.packetLoss}
          </span>
        </div>

        <div className="flex justify-between items-center text-gray-500 text-[10px] mt-2 pt-1 border-t border-gray-700">
          <span>State:</span>
          <span className="font-mono" data-testid="connection-state">
            {stats.connectionState}
          </span>
        </div>
      </div>
    </div>
  );
}