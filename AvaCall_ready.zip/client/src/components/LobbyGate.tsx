import React, { useEffect, useState } from 'react';

export default function LobbyGate({
  roomId,
  userId,
  onAdmitted
}: { roomId: string; userId: string; onAdmitted: () => void }) {
  const [state, setState] = useState<'knocking'|'waiting'|'admitted'|'denied'>('knocking');

  useEffect(() => {
    (async () => {
      // knock
      await fetch(`/api/room/${roomId}/knock`, {
        method: 'POST',
        headers: { 'Content-Type':'application/json', 'x-user-id': userId }
      });
      setState('waiting');

      // poll admission
      const id = setInterval(async () => {
        const r = await fetch(`/api/room/${roomId}/status`, { headers: { 'x-user-id': userId }});
        const j = await r.json();
        if (j.allowed) {
          clearInterval(id);
          setState('admitted');
          onAdmitted();
        }
      }, 1500);
      return () => clearInterval(id);
    })();
  }, [roomId, userId, onAdmitted]);

  return (
    <div className="p-4 border rounded bg-black/40">
      {state === 'waiting' && <div>Waiting for host approval…</div>}
      {state === 'admitted' && <div>Admitted. Connecting…</div>}
      {state === 'knocking' && <div>Requesting access…</div>}
      {state === 'denied' && <div>Access denied.</div>}
    </div>
  );
}