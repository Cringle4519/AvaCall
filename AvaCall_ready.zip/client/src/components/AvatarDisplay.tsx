import { useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { mount3DLikeness } from '@/lib/avatar/threeLikeness';
import type { UserAvatar } from '@shared/schema';

interface AvatarDisplayProps {
  userId: string;
  revealLevel: number; // 0, 25, 50, 75, 100
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  isLocal?: boolean; // Whether this is the local user's avatar
}

export default function AvatarDisplay({ 
  userId, 
  revealLevel, 
  className = '', 
  size = 'md',
  isLocal = false 
}: AvatarDisplayProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const stopRef = useRef<(() => void) | null>(null);
  const [avatarProcessed, setAvatarProcessed] = useState<string | null>(null);

  // Fetch user's avatar
  const { data: avatar } = useQuery({
    queryKey: ['/api/avatar', userId],
    queryFn: async (): Promise<UserAvatar | null> => {
      try {
        const response = await fetch(`/api/avatar/${userId}`);
        return response.json();
      } catch (error: any) {
        if (error.status === 404) {
          return null; // No avatar found
        }
        throw error;
      }
    },
    enabled: !!userId,
  });

  // Clean up 3D scene on unmount
  useEffect(() => {
    return () => {
      stopRef.current?.();
    };
  }, []);

  // Process avatar based on reveal level
  useEffect(() => {
    const processAvatar = async () => {
      if (!avatar?.avatarUrl) {
        setAvatarProcessed(null);
        return;
      }

      // For staged reveal, we create different versions based on reveal level
      if (revealLevel === 0) {
        // Pure avatar mode
        setAvatarProcessed(avatar.avatarUrl);
      } else if (revealLevel >= 100) {
        // Full reveal - would need actual video feed
        // For now, show avatar with watermark indicating full reveal
        setAvatarProcessed(avatar.avatarUrl);
      } else {
        // Partial reveal levels (25%, 50%, 75%)
        // For MVP, show avatar with transparency/overlay effects
        setAvatarProcessed(await createPartialReveal(avatar.avatarUrl, revealLevel));
      }
    };

    processAvatar();
  }, [avatar, revealLevel]);

  // Mount 3D avatar if applicable
  useEffect(() => {
    if (!avatar || !avatarProcessed || !containerRef.current || avatar.avatarType !== '3d') {
      stopRef.current?.();
      stopRef.current = null;
      return;
    }

    stopRef.current?.();
    stopRef.current = mount3DLikeness(containerRef.current, avatarProcessed, {
      headModelUrl: import.meta.env.VITE_HEAD_MODEL_URL
    });

    return () => {
      stopRef.current?.();
    };
  }, [avatar, avatarProcessed]);

  // Size configurations
  const sizeClasses = {
    sm: 'w-16 h-16',
    md: 'w-32 h-32',
    lg: 'w-48 h-48'
  };

  // Create partial reveal effect (simplified for MVP)
  const createPartialReveal = async (avatarUrl: string, level: number): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d')!;
        
        canvas.width = img.width;
        canvas.height = img.height;
        
        // Draw the avatar
        ctx.drawImage(img, 0, 0);
        
        // Apply reveal effect based on level
        if (level < 100) {
          // Add privacy overlay/blur effect
          ctx.fillStyle = `rgba(0, 0, 0, ${0.3 - (level / 100) * 0.3})`;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          
          // Add reveal level indicator
          ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
          ctx.font = '12px Inter, sans-serif';
          ctx.fillText(`${level}% REVEAL`, 10, 20);
        }
        
        resolve(canvas.toDataURL('image/png'));
      };
      img.src = avatarUrl;
    });
  };

  if (!avatar) {
    return (
      <div 
        className={`${sizeClasses[size]} ${className} rounded-full bg-muted/50 flex items-center justify-center border border-border`}
        data-testid="avatar-placeholder"
      >
        <div className="text-muted-foreground text-xl">
          {userId?.charAt(0)?.toUpperCase() || '?'}
        </div>
      </div>
    );
  }

  return (
    <div 
      className={`${sizeClasses[size]} ${className} rounded-full overflow-hidden border border-border bg-background relative`}
      data-testid="avatar-display"
      data-reveal-level={revealLevel}
      data-avatar-type={avatar.avatarType}
    >
      {avatar.avatarType === '3d' ? (
        <div 
          ref={containerRef} 
          className="w-full h-full"
          data-testid="avatar-3d-container"
        />
      ) : avatarProcessed ? (
        <img
          src={avatarProcessed}
          alt={`Avatar (${revealLevel}% reveal)`}
          className="w-full h-full object-cover"
          data-testid="avatar-2d-image"
        />
      ) : (
        <div className="w-full h-full bg-muted/50 flex items-center justify-center">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
        </div>
      )}

      {/* Reveal Level Indicator */}
      {revealLevel > 0 && revealLevel < 100 && (
        <div className="absolute bottom-0 left-0 right-0 bg-black/70 text-white text-xs px-2 py-1 text-center">
          {revealLevel}% Reveal
        </div>
      )}

      {/* Local User Indicator */}
      {isLocal && (
        <div className="absolute top-0 right-0 bg-primary text-primary-foreground text-xs px-1 py-0.5 rounded-bl-lg">
          You
        </div>
      )}
    </div>
  );
}