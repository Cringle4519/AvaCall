// Wake Lock API utility to prevent screen dimming during video calls

let wakeLockSentinel: WakeLockSentinel | null = null;

export async function requestWakeLock(): Promise<boolean> {
  try {
    // Check if Wake Lock API is supported
    if (!('wakeLock' in navigator)) {
      console.warn('Wake Lock API not supported in this browser');
      return false;
    }

    // Request a screen wake lock
    wakeLockSentinel = await navigator.wakeLock.request('screen');
    
    console.log('Wake lock acquired - screen will stay on during call');
    
    // Listen for wake lock release (happens when tab becomes hidden, device locks, etc.)
    wakeLockSentinel.addEventListener('release', () => {
      console.log('Wake lock released');
      wakeLockSentinel = null;
    });

    return true;
  } catch (error) {
    console.error('Failed to request wake lock:', error);
    return false;
  }
}

export async function releaseWakeLock(): Promise<void> {
  try {
    if (wakeLockSentinel) {
      await wakeLockSentinel.release();
      wakeLockSentinel = null;
      console.log('Wake lock manually released');
    }
  } catch (error) {
    console.error('Failed to release wake lock:', error);
  }
}

export function isWakeLockActive(): boolean {
  return wakeLockSentinel !== null && !wakeLockSentinel.released;
}

// Auto-reacquire wake lock when page becomes visible again
// (helpful for mobile users who switch apps and return)
export function setupWakeLockReacquisition(): void {
  if (!('wakeLock' in navigator)) return;

  document.addEventListener('visibilitychange', async () => {
    if (document.visibilityState === 'visible' && (!wakeLockSentinel || wakeLockSentinel.released)) {
      console.log('Page became visible - reacquiring wake lock');
      await requestWakeLock();
    }
  });
}