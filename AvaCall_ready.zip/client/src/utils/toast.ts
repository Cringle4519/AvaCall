let holder: HTMLDivElement | null = null;

function ensure() {
  if (holder) return holder;
  holder = document.createElement('div');
  holder.style.cssText = 'position:fixed;right:12px;bottom:12px;display:flex;flex-direction:column;gap:8px;z-index:99999';
  document.body.appendChild(holder);
  return holder;
}

export function toast(msg: string, ms = 3000) {
  const h = ensure();
  const el = document.createElement('div');
  el.textContent = msg;
  el.style.cssText = 'background:#111;color:#fff;padding:8px 12px;border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.3);font:12px system-ui';
  h.appendChild(el);
  setTimeout(() => { 
    el.style.opacity = '0'; 
    el.style.transition = 'opacity .3s'; 
    setTimeout(() => el.remove(), 300); 
  }, ms);
}