export type Preflight = { cam: boolean; mic: boolean; ice: boolean };

export async function runPreflight(iceServers: RTCIceServer[]): Promise<Preflight> {
  const out: Preflight = { cam: false, mic: false, ice: false };
  const devices = await navigator.mediaDevices.enumerateDevices();
  out.cam = devices.some(d => d.kind === 'videoinput');
  out.mic = devices.some(d => d.kind === 'audioinput');

  let stream: MediaStream | null = null;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
  } catch { 
    /* ignore - devices may not be available */ 
  }

  if (!stream) return out;
  
  const pc = new RTCPeerConnection({ iceServers });
  pc.addTrack(stream.getVideoTracks()[0], new MediaStream([stream.getVideoTracks()[0]]));
  pc.addTransceiver('video', { direction: 'recvonly' });
  await pc.setLocalDescription(await pc.createOffer());

  out.ice = await new Promise<boolean>(resolve => {
    const to = setTimeout(() => resolve(false), 8000);
    let candidatesGathered = false;
    
    pc.onicegatheringstatechange = () => {
      if (pc.iceGatheringState === 'complete') {
        candidatesGathered = true;
        clearTimeout(to);
        resolve(true);
      }
    };
    
    pc.onicecandidate = (event) => {
      if (event.candidate) {
        // Got at least one candidate, which means ICE gathering is working
        if (!candidatesGathered) {
          candidatesGathered = true;
          clearTimeout(to);
          resolve(true);
        }
      }
    };
  });

  stream.getTracks().forEach(t => t.stop());
  pc.close();
  return out;
}