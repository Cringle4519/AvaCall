export function logEvent(type: string, { roomId, extra }: { roomId?: string; extra?: any } = {}) {
  try {
    fetch('/analytics', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type, roomId, extra })
    }).catch(() => {});
  } catch {}
}