import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function Privacy() {
  const [, setLocation] = useLocation();

  return (
    <div className="container max-w-4xl mx-auto p-6">
      <div className="mb-6">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")}
          className="mb-4"
          data-testid="button-back"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Privacy Policy</CardTitle>
          <p className="text-sm text-muted-foreground">Last updated: September 22, 2025</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <section>
            <h2 className="text-xl font-semibold mb-3">Privacy-First Video Calling</h2>
            <p className="text-muted-foreground">
              AvaCall is designed with privacy as the core principle. Our Privacy-first Identity Reveal Protocol (PIRP) 
              ensures that you control what others see about you during video calls.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">Data Collection</h2>
            <div className="space-y-2 text-muted-foreground">
              <p><strong>What we collect:</strong></p>
              <ul className="list-disc list-inside ml-4 space-y-1">
                <li>Room participation logs (for audit purposes)</li>
                <li>Basic session metadata (duration, participant count)</li>
                <li>Technical diagnostics (connection quality, device compatibility)</li>
              </ul>
              <p className="mt-3"><strong>What we DON'T collect:</strong></p>
              <ul className="list-disc list-inside ml-4 space-y-1">
                <li>Video or audio content</li>
                <li>Personal identifying information</li>
                <li>Chat messages or communication content</li>
                <li>Biometric data from video streams</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">PIRP Technology</h2>
            <p className="text-muted-foreground">
              Our Privacy-first Identity Reveal Protocol processes video locally in your browser. 
              No video data is sent to our servers for processing. All background removal, 
              avatar overlays, and reveal controls happen on your device.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">Data Storage</h2>
            <p className="text-muted-foreground">
              Session logs are stored securely and automatically deleted after 30 days. 
              No persistent user profiles or personal data are maintained on our servers.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">Your Rights</h2>
            <div className="text-muted-foreground">
              <p>You have the right to:</p>
              <ul className="list-disc list-inside ml-4 space-y-1 mt-2">
                <li>Complete control over your video reveal settings</li>
                <li>Exit any call at any time</li>
                <li>Request deletion of session logs</li>
                <li>Use the service without providing personal information</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">Contact Us</h2>
            <p className="text-muted-foreground">
              If you have any questions about this Privacy Policy or our privacy practices, 
              please contact us through our support channels.
            </p>
          </section>
        </CardContent>
      </Card>
    </div>
  );
}