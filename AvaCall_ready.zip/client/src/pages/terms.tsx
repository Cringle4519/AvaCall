import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function Terms() {
  const [, setLocation] = useLocation();

  return (
    <div className="container max-w-4xl mx-auto p-6">
      <div className="mb-6">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")}
          className="mb-4"
          data-testid="button-back"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Terms of Service</CardTitle>
          <p className="text-sm text-muted-foreground">Last updated: September 22, 2025</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <section>
            <h2 className="text-xl font-semibold mb-3">Acceptance of Terms</h2>
            <p className="text-muted-foreground">
              By using AvaCall, you agree to these Terms of Service and our Privacy Policy. 
              If you disagree with any part of these terms, you may not use our service.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">Service Description</h2>
            <p className="text-muted-foreground">
              AvaCall provides privacy-first video calling with progressive identity reveal controls. 
              The service includes background segmentation, avatar overlays, and real-time communication features.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">User Responsibilities</h2>
            <div className="space-y-2 text-muted-foreground">
              <p><strong>You agree to:</strong></p>
              <ul className="list-disc list-inside ml-4 space-y-1">
                <li>Use the service in compliance with all applicable laws</li>
                <li>Respect other participants' privacy and reveal preferences</li>
                <li>Not record calls without explicit consent from all participants</li>
                <li>Not use the service for illegal, harmful, or abusive activities</li>
                <li>Not attempt to circumvent security or privacy features</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">Privacy & Consent</h2>
            <div className="text-muted-foreground">
              <p><strong>Recording Policy:</strong></p>
              <p className="mt-2">
                Recording of video calls is strictly prohibited without explicit consent from ALL participants. 
                Any unauthorized recording may result in immediate service termination and potential legal action.
              </p>
              <p className="mt-3"><strong>Reveal Controls:</strong></p>
              <p className="mt-2">
                Each participant controls their own identity reveal settings. Attempting to override or 
                circumvent another user's privacy controls is a violation of these terms.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">Service Availability</h2>
            <p className="text-muted-foreground">
              We strive to provide reliable service but do not guarantee 100% uptime. 
              The service may be temporarily unavailable for maintenance, updates, or technical issues.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">Limitation of Liability</h2>
            <p className="text-muted-foreground">
              AvaCall is provided "as is" without warranties. We are not liable for any damages 
              arising from the use or inability to use the service, including but not limited to 
              communication failures, privacy breaches by other users, or technical issues.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">Termination</h2>
            <p className="text-muted-foreground">
              We reserve the right to terminate or suspend access to our service immediately, 
              without prior notice, for any violation of these Terms of Service.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">Changes to Terms</h2>
            <p className="text-muted-foreground">
              We reserve the right to modify these terms at any time. Changes will be effective 
              immediately upon posting. Continued use of the service constitutes acceptance of the revised terms.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">Contact Information</h2>
            <p className="text-muted-foreground">
              If you have any questions about these Terms of Service, 
              please contact us through our support channels.
            </p>
          </section>
        </CardContent>
      </Card>
    </div>
  );
}