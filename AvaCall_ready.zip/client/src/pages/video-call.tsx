import { useState, useEffect, useCallback } from "react";
import { useParams } from "wouter";
import { Video, Settings, MessageCircle } from "lucide-react";
import AvatarSidebar from "@/components/avatar-sidebar";
import BackgroundSidebar from "@/components/background-sidebar";
import VideoDisplay from "@/components/video-display";
import RevealBar from "@/components/reveal-bar";
import RevealControls from "@/components/RevealControls";
import RevealStack from "@/components/RevealStack";
import ConsentModal from "@/components/consent-modal";
import CallInitiationModal from "@/components/call-initiation-modal";
import PreflightModal from "@/components/preflight-modal";
import CallStats from "@/components/call-stats";
import TrustBadge from "@/components/trust-badge";
import DeviceSwitcher from "@/components/DeviceSwitcher";
import { InCallChat, type ChatMessage } from "@/components/InCallChat";
import { ScreenShareToggle } from "@/components/ScreenShareToggle";
import { useWebRTC } from "@/hooks/use-webrtc";
import { useVirtualBackground } from "@/hooks/use-virtual-background";
import { useToast } from "@/hooks/use-toast";
import { useSceneHotkeys } from "@/hooks/useSceneHotkeys";
import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { usePirpAuth } from "@/hooks/use-pirp-auth";
import { SCENES, getSceneById } from "@/scenes/scenes";
import { BG_PRESETS, getBackgroundById } from "@/webrtc/backgrounds";
import { useAmbience } from "@/scenes/useAmbience";
import type { RevealLevel } from "@/reveal/levels";

export default function VideoCall() {
  const { roomId } = useParams<{ roomId?: string }>();
  const [showCallModal, setShowCallModal] = useState(!roomId);
  const [showPreflightModal, setShowPreflightModal] = useState(false);
  const [pendingRoomAction, setPendingRoomAction] = useState<{ type: 'start' | 'join', roomName: string } | null>(null);
  // currentRoomId now comes from useWebRTC hook
  const [selectedAvatar, setSelectedAvatar] = useState<number | string>(1);
  const [selectedAvatarUrl, setSelectedAvatarUrl] = useState<string>("");
  const [selectedBackground, setSelectedBackground] = useState("blur");
  const [selectedBackgroundUrl, setSelectedBackgroundUrl] = useState<string>("");
  const [avatarSize, setAvatarSize] = useState(80);
  const [avatarPosition, setAvatarPosition] = useState("bottom-right");
  const [blurIntensity, setBlurIntensity] = useState(75);
  
  // Scene Management
  const [sceneId, setSceneId] = useState('office-professional');
  const currentScene = getSceneById(sceneId);
  const currentBackground = currentScene ? getBackgroundById(currentScene.bgId) : null;
  
  
  // Ambience system
  const { isPlaying: isAmbiencePlaying, error: ambienceError } = useAmbience({
    ambienceType: currentScene?.ambience || 'none',
    volume: 0.3,
    enabled: true
  });

  // Scene hotkeys hook
  useSceneHotkeys(setSceneId);
  
  // PIRP Privacy Controls
  const [localRevealLevel, setLocalRevealLevel] = useState(0); // Start with maximum privacy
  const [remoteRevealLevel, setRemoteRevealLevel] = useState(0); // Remote user's reveal level
  
  // Consent Management
  const [showConsentModal, setShowConsentModal] = useState(false);
  const [currentConsentRequest, setCurrentConsentRequest] = useState<any>(null);
  const [isProcessingConsent, setIsProcessingConsent] = useState(false);
  
  // PIRP Authentication
  const { pirpUser, isAuthenticated, authenticate } = usePirpAuth();
  
  // Chat state
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [showChat, setShowChat] = useState(false);
  
  // Screen sharing state
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  
  // Enhanced ICE servers configuration for production
  const turnServer = import.meta.env.VITE_TURN_SERVER || 'localhost';
  const turnUsername = import.meta.env.VITE_TURN_USERNAME || 'turnuser';
  const turnPassword = import.meta.env.VITE_TURN_PASSWORD || 'turnpass';
  const enableTurns = import.meta.env.VITE_TURN_ENABLE_TLS === 'true';
  
  const iceServers: RTCIceServer[] = [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
    // TURN servers for NAT traversal with explicit transports
    { 
      urls: [
        // Multiple transport options for maximum compatibility
        `turn:${turnServer}:3478?transport=udp`,
        `turn:${turnServer}:3478?transport=tcp`,
        // TURNS only if TLS is enabled (production)
        ...(enableTurns ? [`turns:${turnServer}:5349?transport=tcp`] : [])
      ],
      username: turnUsername,
      credential: turnPassword
    }
  ];

  const { toast } = useToast();
  const {
    localVideoRef,
    remoteVideoRef,
    isConnected,
    isMuted,
    isCameraOn,
    participants,
    peerConnection,
    localStream,
    sendMessage,
    currentRoomId,
    currentClientId,
    updateLocalStream,
    toggleMicrophone,
    toggleCamera,
    startCall,
    joinCall,
    endCall,
    shareScreen
  } = useWebRTC(iceServers, (data: any) => {
    switch (data.type) {
      case 'chat-message':
        // Handle incoming chat messages
        const newMessage: ChatMessage = {
          id: data.messageId,
          roomId: data.roomId,
          userId: data.userId,
          message: data.message,
          messageType: data.messageType || 'text',
          timestamp: new Date(data.timestamp),
          senderClientId: data.senderClientId
        };
        setChatMessages(prev => [...prev, newMessage]);
        
        // Show notification for chat messages when chat is not open
        if (!showChat && data.senderClientId !== currentClientId) {
          toast({
            title: "New message",
            description: data.message.length > 50 ? data.message.substring(0, 50) + "..." : data.message,
          });
        }
        break;
        
      case 'REVEAL_REQUEST':
        // Show consent modal for incoming reveal request
        setCurrentConsentRequest({
          requestId: `${data.from}-${Date.now()}`,
          requesterId: data.from,
          requesterName: data.from, // Could be enhanced with user names
          currentLevel: localRevealLevel,
          requestedLevel: data.targetLevel,
          timestamp: new Date().toISOString(),
          expiresAt: new Date(Date.now() + 2 * 60 * 1000).toISOString() // 2 minutes
        });
        setShowConsentModal(true);
        
        toast({
          title: "Privacy Request",
          description: `Someone is requesting ${data.targetLevel}% reveal level`,
        });
        break;
        
      case 'REVEAL_DECISION':
        // Handle reveal decision feedback (approve/decline)
        if (data.approve) {
          toast({
            title: "Request Approved",
            description: `Your reveal request was approved`,
          });
        } else {
          toast({
            title: "Request Declined",
            description: `Your reveal request was declined`,
            variant: "destructive",
          });
        }
        break;
        
      case 'REVEAL_LEVEL':
        // Update reveal levels based on who changed
        if (data.userId === pirpUser?.userId) {
          // This is your own level being updated after approval
          setLocalRevealLevel(data.level);
        } else {
          // Someone else's level changed
          setRemoteRevealLevel(data.level);
        }
        break;
        
      case 'PIRP_ASSIGNED':
        // Server assigned secure pirpUserId - authenticate with PIRP system
        if (data.pirpUserId && currentRoomId) {
          authenticate(currentRoomId, data.pirpUserId).then(() => {
            toast({
              title: "Privacy System Ready",
              description: "Secure identity established for privacy controls",
            });
          }).catch((error) => {
            console.error('PIRP authentication failed:', error);
            toast({
              title: "Privacy System Error",
              description: "Failed to initialize privacy controls",
              variant: "destructive",
            });
          });
        }
        break;
    }
  });

  // Virtual background processing
  const { processedStream } = useVirtualBackground({
    videoElement: localVideoRef.current,
    selectedBackground,
    selectedBackgroundUrl,
    blurIntensity,
    isEnabled: selectedBackground !== 'none' // Enable when a background is selected
  });

  useEffect(() => {
    if (roomId && !showCallModal) {
      handleJoinCall(roomId);
    }
  }, [roomId]);

  // Keyboard shortcuts for scene switching
  useEffect(() => {
    let last = 0, count = 0;
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      const now = Date.now();
      const within = (ms: number) => now - last < ms;
      
      // double-c => Cabin (office)
      if (k === 'c') { 
        count = within(350) ? count + 1 : 1; 
        last = now; 
        if (count >= 2) setSceneId('office-professional'); 
        return; 
      }
      // r => Rooftop Night
      if (k === 'r') setSceneId('rooftop-night');
      // n => Neon City
      if (k === 'n') setSceneId('neon-city');
      // l => Library
      if (k === 'l') setSceneId('library-study');
      // o => Office
      if (k === 'o') setSceneId('office-professional');
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const handleStartCall = async (roomName: string) => {
    setPendingRoomAction({ type: 'start', roomName });
    setShowPreflightModal(true);
    setShowCallModal(false);
  };

  const executeStartCall = async (roomName: string) => {
    try {
      const success = await startCall(roomName);
      if (success) {
        // Note: currentRoomId now managed by useWebRTC hook
        
        // Note: pirpUserId now assigned server-side for security
        // Will receive it via joined-room message and authenticate via PIRP_ASSIGNED
        
        toast({
          title: "Call Started",
          description: `Room ${roomName} created successfully`,
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to start call",
        variant: "destructive",
      });
    }
  };

  const handleJoinCall = async (roomName: string) => {
    setPendingRoomAction({ type: 'join', roomName });
    setShowPreflightModal(true);
    setShowCallModal(false);
  };

  const executeJoinCall = async (roomName: string) => {
    try {
      const success = await joinCall(roomName);
      if (success) {
        // currentRoomId managed by useWebRTC hook
        
        // Note: pirpUserId now assigned server-side for security
        // Will receive it via joined-room message and authenticate via PIRP_ASSIGNED
        
        toast({
          title: "Joined Call",
          description: `Connected to room ${roomName}`,
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to join call",
        variant: "destructive",
      });
    }
  };

  const handlePreflightSuccess = async () => {
    if (pendingRoomAction) {
      if (pendingRoomAction.type === 'start') {
        await executeStartCall(pendingRoomAction.roomName);
      } else {
        await executeJoinCall(pendingRoomAction.roomName);
      }
      setPendingRoomAction(null);
    }
    setShowPreflightModal(false);
  };

  const handlePreflightClose = () => {
    setShowPreflightModal(false);
    setPendingRoomAction(null);
    setShowCallModal(true);
  };

  const handleEndCall = () => {
    endCall();
    // currentRoomId managed by useWebRTC hook
    setShowCallModal(true);
    toast({
      title: "Call Ended",
      description: "You have left the call",
    });
  };

  const generateRoomId = () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  // Poll for incoming consent requests (only when connected and authenticated)
  const { data: pendingRequests } = useQuery({
    queryKey: ['/api/pirp/requests'],
    enabled: !!currentRoomId && isConnected && isAuthenticated,
    refetchInterval: 2000, // Poll every 2 seconds
  });

  // Poll for PIRP status to get reveal level updates
  const { data: pirpStatus } = useQuery({
    queryKey: ['/api/pirp/status'],
    enabled: !!currentRoomId && isConnected && isAuthenticated,
    refetchInterval: 3000, // Poll every 3 seconds for status updates
  });

  // Update reveal levels from PIRP status
  useEffect(() => {
    if (pirpStatus && typeof pirpStatus === 'object') {
      const status = pirpStatus as any;
      if (typeof status.localRevealLevel === 'number') {
        setLocalRevealLevel(status.localRevealLevel);
      }
      if (typeof status.remoteRevealLevel === 'number') {
        setRemoteRevealLevel(status.remoteRevealLevel);
      }
    }
  }, [pirpStatus]);

  // Current participant info for TrustBadge
  const currentParticipant = {
    id: "current-user",
    userId: pirpUser?.userId || null,
    roomId: currentRoomId,
    trustScore: (pirpStatus as any)?.trustScore || 0,
    currentLevel: (pirpStatus as any)?.currentLevel || 0,
    role: (pirpStatus as any)?.role || "participant",
    joinedAt: new Date(),
    leftAt: null,
    isActive: true
  };

  // Handle incoming consent requests
  useEffect(() => {
    if (pendingRequests && Array.isArray(pendingRequests) && pendingRequests.length > 0 && !showConsentModal) {
      const latestRequest = pendingRequests[0]; // Show the most recent request
      setCurrentConsentRequest(latestRequest);
      setShowConsentModal(true);
    }
  }, [pendingRequests, showConsentModal]);

  // PIRP Reveal Request Mutation
  const revealRequestMutation = useMutation({
    mutationFn: async ({ targetUserId, level }: { targetUserId: string; level: number }) => {
      const response = await apiRequest('POST', '/api/pirp/reveal/request', { targetUserId, level }, true);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Consent Request Sent",
        description: "Waiting for other participants to approve your reveal level increase",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Request Failed",
        description: error.message || "Unable to send consent request",
        variant: "destructive",
      });
    }
  });

  // PIRP Privacy Control Handler
  const handleRevealLevelChange = async (newLevel: number) => {
    const currentLevel = localRevealLevel;
    
    // Allow immediate decreases (more privacy)
    if (newLevel <= currentLevel) {
      setLocalRevealLevel(newLevel);
      toast({
        title: "Privacy Level Updated",
        description: `Your reveal level decreased to ${newLevel}%`,
      });
      return;
    }
    
    // For increases, send consent request to other participants
    if (!currentRoomId) {
      toast({
        title: "Not Connected",
        description: "You must be in a call to change privacy levels",
        variant: "destructive",
      });
      return;
    }

    try {
      // Check if there are other participants in the call
      if (participants <= 1) {
        toast({
          title: "No Other Participants",
          description: "No other participants to send consent request to",
          variant: "destructive",
        });
        return;
      }
      
      // For now, use a placeholder for the other participant ID
      // In a full implementation, this would come from proper participant tracking
      const targetUserId = "other_participant";
      await revealRequestMutation.mutateAsync({ 
        targetUserId, 
        level: newLevel 
      });
    } catch (error) {
      // Error already handled by mutation onError
    }
  };

  // PIRP Consent Decision Mutation
  const consentDecisionMutation = useMutation({
    mutationFn: async ({ consentId, approve }: { consentId: string; approve: boolean }) => {
      const response = await apiRequest('POST', '/api/pirp/reveal/decide', { consentId, approve }, true);
      return response.json();
    },
    onSuccess: (data: any, variables: { consentId: string; approve: boolean }) => {
      if (variables.approve) {
        toast({
          title: "Consent Approved",
          description: "The participant's reveal level has been updated",
        });
      } else {
        toast({
          title: "Consent Denied", 
          description: "The reveal request has been declined",
        });
      }
      
      // Close modal and reset state
      setShowConsentModal(false);
      setCurrentConsentRequest(null);
      
      // Invalidate relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/pirp/requests'] });
      queryClient.invalidateQueries({ queryKey: ['/api/pirp/status'] });
    },
    onError: (error: any) => {
      toast({
        title: "Decision Failed",
        description: error.message || "Failed to process consent decision",
        variant: "destructive",
      });
    }
  });

  // Handle consent decision using WebSocket
  const handleConsentDecision = async (consentId: string, approved: boolean) => {
    if (!currentConsentRequest || !sendMessage || !currentRoomId || !pirpUser) {
      toast({
        title: "Privacy System Error",
        description: "Privacy system not ready yet. Please wait for authentication to complete.",
        variant: "destructive",
      });
      return;
    }
    
    setIsProcessingConsent(true);
    
    try {
      // Send WebSocket decision message
      sendMessage({
        type: 'REVEAL_DECISION',
        roomId: currentRoomId,
        consentId: consentId,
        subjectUserId: pirpUser?.userId || '',
        approve: approved,
        level: currentConsentRequest.requestedLevel
      });
      
      toast({
        title: approved ? "Request Approved" : "Request Denied",
        description: approved 
          ? `Privacy level increased to ${currentConsentRequest.requestedLevel}%`
          : "Privacy request has been declined",
        variant: approved ? "default" : "destructive",
      });
      
      if (approved) {
        setLocalRevealLevel(currentConsentRequest.requestedLevel);
      }
      
    } catch (error: any) {
      toast({
        title: "Error Processing Decision",
        description: error.message || "Failed to process consent decision",
        variant: "destructive",
      });
    } finally {
      setIsProcessingConsent(false);
      setShowConsentModal(false);
      setCurrentConsentRequest(null);
    }
  };

  // Chat message handling
  const handleSendChatMessage = useCallback((message: string) => {
    if (!currentRoomId || !sendMessage) return;
    
    sendMessage({
      type: 'chat-message',
      roomId: currentRoomId,
      message: message,
      messageType: 'text'
    });
  }, [currentRoomId, sendMessage]);

  // Screen sharing handling - using the existing shareScreen function from the hook
  const handleToggleScreenShare = useCallback(async () => {
    try {
      // For now, use the existing shareScreen function
      // TODO: Enhance to properly track screen sharing state
      await shareScreen();
      
      // Toggle screen sharing state
      setIsScreenSharing(!isScreenSharing);
      
      toast({
        title: isScreenSharing ? "Screen Sharing Stopped" : "Screen Sharing Started",
        description: isScreenSharing ? "Switched back to camera view" : "Your screen is now being shared",
      });
    } catch (error) {
      console.error('Screen share toggle error:', error);
      toast({
        title: "Screen Share Error",
        description: "Failed to toggle screen sharing",
        variant: "destructive",
      });
    }
  }, [shareScreen, isScreenSharing, toast]);

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Header */}
      <header className="flex items-center justify-between p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Video className="text-primary-foreground text-sm" />
          </div>
          <h1 className="text-xl font-semibold">AvaCall</h1>
        </div>
        
        <div className="flex items-center space-x-4">
          {currentRoomId && (
            <span className="text-sm text-muted-foreground">
              Room: #{currentRoomId}
            </span>
          )}
          
          {/* Screen Sharing Toggle */}
          <ScreenShareToggle
            isScreenSharing={isScreenSharing}
            onToggleScreenShare={handleToggleScreenShare}
            disabled={!isConnected}
          />
          
          {/* Chat Toggle */}
          <button
            onClick={() => setShowChat(!showChat)}
            className={`px-4 py-2 rounded-lg transition-colors ${
              showChat 
                ? "bg-primary text-primary-foreground" 
                : "bg-muted text-muted-foreground hover:bg-accent"
            }`}
            data-testid="button-toggle-chat"
          >
            <MessageCircle className="w-4 h-4 mr-2 inline" />
            Chat
            {chatMessages.length > 0 && !showChat && (
              <span className="ml-2 bg-red-500 text-white text-xs rounded-full px-2 py-1">
                {chatMessages.length}
              </span>
            )}
          </button>
          
          <button 
            className="px-4 py-2 bg-muted text-muted-foreground rounded-lg hover:bg-accent transition-colors"
            data-testid="button-settings"
          >
            <Settings className="w-4 h-4 mr-2 inline" />
            Settings
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 flex">
        {/* Left Sidebar - Avatar Selection */}
        <AvatarSidebar
          selectedAvatar={selectedAvatar}
          onAvatarSelect={(avatarId, avatarUrl) => {
            setSelectedAvatar(avatarId);
            if (avatarUrl) setSelectedAvatarUrl(avatarUrl);
          }}
          avatarSize={avatarSize}
          onAvatarSizeChange={(size) => {
            console.log('Video call received avatar size change:', size);
            setAvatarSize(size);
          }}
          avatarPosition={avatarPosition}
          onAvatarPositionChange={setAvatarPosition}
        />

        {/* Center Video Area */}
        <div className="relative flex-1">
          <VideoDisplay
            localVideoRef={localVideoRef}
            remoteVideoRef={remoteVideoRef}
            selectedAvatar={selectedAvatar}
            selectedAvatarUrl={selectedAvatarUrl}
            selectedBackground={currentBackground?.id || selectedBackground}
            selectedBackgroundUrl={currentBackground?.image || selectedBackgroundUrl}
            avatarSize={avatarSize}
            avatarPosition={avatarPosition}
            isConnected={isConnected}
            isMuted={isMuted}
            isCameraOn={isCameraOn}
            participants={participants}
            onToggleMicrophone={toggleMicrophone}
            onToggleCamera={toggleCamera}
            onEndCall={handleEndCall}
            onShareScreen={shareScreen}
            remoteRevealLevel={remoteRevealLevel}
            localRevealLevel={localRevealLevel}
            localUserId={pirpUser?.userId}
            remoteUserId={participants > 1 ? 'remote-participant-1' : undefined}
            onCopyInviteLink={() => {
              const roomId = currentRoomId;
              const inviteUrl = `${window.location.origin}/room/${roomId}/lobby`;
              navigator.clipboard.writeText(inviteUrl).then(() => {
                toast({
                  title: "Invite Link Copied",
                  description: "Share this link to invite others to join the call",
                });
              }).catch(() => {
                toast({
                  title: "Copy Failed",
                  description: "Unable to copy invite link to clipboard",
                  variant: "destructive",
                });
              });
            }}
            onToggleCallStats={() => {
              toast({
                title: "Call Stats",
                description: "Real-time connection statistics are displayed in the overlay",
              });
            }}
            localStream={localStream}
            peerConnection={peerConnection}
            onStreamReplace={(newStream: MediaStream) => {
              // Update both the video element and the hook's local stream state
              if (localVideoRef.current) {
                localVideoRef.current.srcObject = newStream;
              }
              updateLocalStream(newStream);
            }}
          />
          
          {/* LUT overlays - positioned after VideoDisplay for proper stacking */}
          {currentScene?.lut === 'warm' && (
            <div 
              className="pointer-events-none absolute inset-0 z-50"
              data-testid="lut-overlay-warm"
              style={{ background: 'radial-gradient(1200px 500px at 80% 120%, rgba(255,180,120,.20), transparent), radial-gradient(1000px 400px at 0% -20%, rgba(255,160,100,.10), transparent)' }} 
            />
          )}
          {currentScene?.lut === 'cool' && (
            <div 
              className="pointer-events-none absolute inset-0 z-50"
              data-testid="lut-overlay-cool"
              style={{ background: 'radial-gradient(1000px 500px at 20% 120%, rgba(120,190,255,.18), transparent), radial-gradient(700px 400px at 100% 0%, rgba(80,160,255,.10), transparent)' }} 
            />
          )}
          {currentScene?.lut === 'neon' && (
            <div 
              className="pointer-events-none absolute inset-0 z-50"
              data-testid="lut-overlay-neon"
              style={{ background: 'radial-gradient(1200px 600px at 90% 110%, rgba(255,60,180,.20), transparent), radial-gradient(900px 500px at 0% -10%, rgba(0,255,200,.12), transparent)' }} 
            />
          )}
          
          {/* CallStats Overlay */}
          <CallStats 
            peerConnection={peerConnection}
            isVisible={!!peerConnection}
          />
        </div>

        {/* Right Sidebar - Background Selection or Chat */}
        {showChat ? (
          <div className="w-80 border-l border-border bg-card">
            <InCallChat
              roomId={currentRoomId}
              currentUserId={pirpUser?.userId || null}
              currentClientId={currentClientId}
              onSendMessage={handleSendChatMessage}
              messages={chatMessages}
              className="h-full"
            />
          </div>
        ) : (
          <BackgroundSidebar
            selectedBackground={selectedBackground}
            onBackgroundSelect={(backgroundId, backgroundUrl) => {
              setSelectedBackground(backgroundId);
              if (backgroundUrl) setSelectedBackgroundUrl(backgroundUrl);
            }}
            onSceneSelect={setSceneId}
            blurIntensity={blurIntensity}
            onBlurIntensityChange={setBlurIntensity}
          />
        )}

        {/* Far Right Sidebar - Privacy Controls */}
        <div className="w-80 p-6 border-l border-border">
          <div className="sidebar-panel p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center">
              <Video className="mr-2 text-secondary w-5 h-5" />
              Privacy Controls (PIRP)
            </h2>
            
            {/* Device Controls */}
            {isConnected && (
              <div className="mb-6 p-4 border border-border rounded-lg bg-muted/50">
                <h3 className="text-sm font-medium text-foreground mb-3">Device Controls</h3>
                <DeviceSwitcher 
                  pc={peerConnection}
                  localStream={localStream}
                  onStreamReplace={(newStream) => {
                    // Update the local video element with new stream
                    if (localVideoRef.current) {
                      localVideoRef.current.srcObject = newStream;
                    }
                  }}
                />
              </div>
            )}
            
            <RevealControls
              level={localRevealLevel as RevealLevel}
              onRequest={(targetLevel) => {
                if (!currentRoomId || !sendMessage) {
                  toast({
                    title: "Not Connected",
                    description: "You must be in a call to change privacy levels",
                    variant: "destructive",
                  });
                  return;
                }
                
                // Send WebSocket reveal request
                sendMessage({
                  type: 'REVEAL_REQUEST',
                  roomId: currentRoomId,
                  from: pirpUser?.userId || '',
                  to: null, // Broadcast to all
                  targetLevel
                });
                
                toast({
                  title: "Reveal Request Sent",
                  description: `Requesting ${targetLevel}% reveal level from participants`,
                });
              }}
            />
            
            {/* Trust Score Display */}
            {isConnected && isAuthenticated && currentParticipant.userId && (
              <div className="mt-6 pt-4 border-t border-border">
                <TrustBadge 
                  participant={currentParticipant}
                  roomId={currentRoomId || ''}
                  className="bg-slate-50/50 dark:bg-slate-800/50"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Call Initiation Modal */}
      <CallInitiationModal
        isOpen={showCallModal}
        onClose={() => setShowCallModal(false)}
        onStartCall={handleStartCall}
        onJoinCall={handleJoinCall}
        generateRoomId={generateRoomId}
      />

      {/* Pre-Call System Check Modal */}
      <PreflightModal
        isOpen={showPreflightModal}
        onClose={handlePreflightClose}
        onSuccess={handlePreflightSuccess}
        iceServers={iceServers}
      />

      {/* PIRP Consent Modal */}
      <ConsentModal
        isOpen={showConsentModal}
        onClose={() => {
          setShowConsentModal(false);
          setCurrentConsentRequest(null);
        }}
        request={currentConsentRequest}
        onDecision={handleConsentDecision}
        isProcessing={isProcessingConsent}
      />
    </div>
  );
}
