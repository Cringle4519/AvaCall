import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import AvatarMaker from '@/components/AvatarMaker';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Plus, Eye, Download, Trash2, Wand2 } from 'lucide-react';
import type { UserAvatar } from '@shared/schema';

// Get user ID from PIRP authentication
import { usePirpAuth } from '@/hooks/use-pirp-auth';

// This will be replaced with the auth hook inside the component

export default function AvatarManager() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCreator, setShowCreator] = useState(false);
  
  // Get authenticated user ID from PIRP system
  const { pirpUser, isAuthenticated } = usePirpAuth();
  const userId = pirpUser?.userId;
  
  // Require authentication for avatar management
  if (!isAuthenticated || !userId) {
    return (
      <div className="min-h-screen bg-background p-4 flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>
              You need to join a video call to authenticate before creating avatars.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => setLocation('/')}
              className="w-full"
              data-testid="button-back-to-home-auth"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Fetch user's current avatar
  const { data: avatar, isLoading } = useQuery({
    queryKey: ['/api/avatar', userId],
    queryFn: async (): Promise<UserAvatar | null> => {
      try {
        const response = await apiRequest('GET', `/api/avatar/${userId}`, {});
        return response.json();
      } catch (error: any) {
        if (error.status === 404) {
          return null; // No avatar found
        }
        throw error;
      }
    },
    enabled: !!userId, // Only fetch when we have a user ID
  });

  // Delete avatar mutation
  const deleteMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('DELETE', `/api/avatar/${userId}`, {});
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Avatar deleted',
        description: 'Your avatar has been removed from your profile.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/avatar', userId] });
    },
    onError: () => {
      toast({
        title: 'Delete failed',
        description: 'Please try again.',
        variant: 'destructive',
      });
    },
  });

  const handleAvatarCreated = (newAvatar: UserAvatar) => {
    setShowCreator(false);
    queryClient.invalidateQueries({ queryKey: ['/api/avatar', userId] });
    toast({
      title: 'Avatar ready!',
      description: 'Your new avatar is now available for video calls with PIRP staged reveal.',
    });
  };

  const handleDownload = (avatarUrl: string, avatarType: string) => {
    const link = document.createElement('a');
    link.href = avatarUrl;
    link.download = `my-avatar-${avatarType}-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (showCreator) {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <Button
              variant="ghost"
              onClick={() => setShowCreator(false)}
              className="mb-4"
              data-testid="button-back-to-manager"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Avatar Manager
            </Button>
          </div>
          
          <AvatarMaker
            userId={userId}
            onDone={handleAvatarCreated}
            onClose={() => setShowCreator(false)}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation('/')}
            className="mb-4"
            data-testid="button-back-to-home"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
          
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Avatar Manager</h1>
              <p className="text-muted-foreground">
                Create and manage your privacy-first avatars for AvaCall video calls
              </p>
            </div>
            <Button
              onClick={() => setShowCreator(true)}
              className="bg-primary hover:bg-primary/90"
              data-testid="button-create-new-avatar"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create New Avatar
            </Button>
          </div>
        </div>

        {/* Avatar Status */}
        <Card className="mb-8 bg-card/80 backdrop-blur-sm border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wand2 className="h-5 w-5 text-primary" />
              Your Current Avatar
            </CardTitle>
            <CardDescription>
              This avatar will be used for PIRP staged reveal during video calls (25% → 50% → 75% → 100%)
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : avatar ? (
              <div className="flex flex-col md:flex-row gap-6">
                {/* Avatar Preview */}
                <div className="flex-shrink-0">
                  <div className="w-32 h-32 rounded-lg border border-border overflow-hidden bg-muted/50">
                    <img
                      src={avatar.avatarUrl}
                      alt="Your avatar"
                      className="w-full h-full object-cover"
                      data-testid="current-avatar-preview"
                    />
                  </div>
                </div>
                
                {/* Avatar Info */}
                <div className="flex-grow space-y-4">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" data-testid="avatar-type-badge">
                      {avatar.avatarType === '3d' ? '🎭 3D Avatar Likeness' : '✨ Stylized Avatar Likeness'}
                    </Badge>
                    <Badge variant="outline" className="text-green-600 border-green-600">
                      Active
                    </Badge>
                  </div>
                  
                  <div className="text-sm text-muted-foreground">
                    <p>Created: {new Date(avatar.createdAt || '').toLocaleDateString()}</p>
                    <p>Type: {avatar.avatarType === '3d' ? '3D Avatar with realistic appearance and gentle animation' : 'Professional stylized avatar with privacy protection'}</p>
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDownload(avatar.avatarUrl, avatar.avatarType)}
                      data-testid="button-download-current-avatar"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowCreator(true)}
                      data-testid="button-replace-avatar"
                    >
                      <Wand2 className="h-4 w-4 mr-2" />
                      Replace
                    </Button>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deleteMutation.mutate()}
                      disabled={deleteMutation.isPending}
                      className="text-destructive hover:text-destructive"
                      data-testid="button-delete-avatar"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      {deleteMutation.isPending ? 'Deleting...' : 'Delete'}
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted/50 flex items-center justify-center">
                  <Eye className="h-8 w-8 text-muted-foreground opacity-50" />
                </div>
                <h3 className="text-lg font-medium text-foreground mb-2">No Avatar Yet</h3>
                <p className="text-muted-foreground mb-4">
                  Create your first privacy-first avatar for AvaCall video calls
                </p>
                <Button
                  onClick={() => setShowCreator(true)}
                  className="bg-primary hover:bg-primary/90"
                  data-testid="button-create-first-avatar"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create Your Avatar
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* PIRP Integration Info */}
        <Card className="bg-card/80 backdrop-blur-sm border-border">
          <CardHeader>
            <CardTitle className="text-lg">How Your Avatar Works with PIRP</CardTitle>
            <CardDescription>
              Privacy-first Identity Reveal Protocol ensures you control when others see your real face
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-4">
              <div className="text-center p-3 rounded-lg bg-muted/50">
                <div className="text-2xl mb-2">🎭</div>
                <div className="font-medium text-sm">0% Reveal</div>
                <div className="text-xs text-muted-foreground">Avatar Only</div>
              </div>
              <div className="text-center p-3 rounded-lg bg-muted/50">
                <div className="text-2xl mb-2">👤</div>
                <div className="font-medium text-sm">25% Reveal</div>
                <div className="text-xs text-muted-foreground">Subtle Features</div>
              </div>
              <div className="text-center p-3 rounded-lg bg-muted/50">
                <div className="text-2xl mb-2">👥</div>
                <div className="font-medium text-sm">50% Reveal</div>
                <div className="text-xs text-muted-foreground">Partial Face</div>
              </div>
              <div className="text-center p-3 rounded-lg bg-muted/50">
                <div className="text-2xl mb-2">👨‍💼</div>
                <div className="font-medium text-sm">100% Reveal</div>
                <div className="text-xs text-muted-foreground">Full Identity</div>
              </div>
            </div>
            
            <div className="pt-4 text-sm text-muted-foreground">
              <p>
                <strong>Your avatar provides privacy protection</strong> while maintaining your likeness. 
                Participants can request higher reveal levels, but you always control the final decision.
                All consent decisions are logged for audit purposes.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}