import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Room, Participant } from "@shared/schema";
import PreCallCheck from "@/components/PreCallCheck";
import { usePirpAuth } from "@/hooks/use-pirp-auth";

import { 
  Video, VideoOff, Mic, MicOff, Settings, Users, Copy, 
  CheckCircle, Clock, ArrowRight, Monitor, LogOut, Wand2 
} from "lucide-react";

const joinRoomSchema = z.object({
  username: z.string().min(1, "Username is required").max(30, "Username too long"),
});

type JoinRoomData = z.infer<typeof joinRoomSchema>;

export default function Lobby() {
  const { roomId } = useParams<{ roomId: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { authenticate, isAuthenticated, pirpUser } = usePirpAuth();
  
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [isAudioOn, setIsAudioOn] = useState(true);
  const [isJoined, setIsJoined] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  // Join form
  const joinForm = useForm<JoinRoomData>({
    resolver: zodResolver(joinRoomSchema),
    defaultValues: { username: "" },
  });

  // Fetch room details
  const { data: room, isLoading: isLoadingRoom, error: roomError } = useQuery<Room>({
    queryKey: ["/api/rooms", roomId],
    enabled: !!roomId,
  });

  // Fetch participants - show before joining for better UX
  const { data: participants = [], isLoading: isLoadingParticipants } = useQuery<Participant[]>({
    queryKey: ["/api/rooms", roomId, "participants"],
    enabled: !!roomId, // Show participants even before joining
    refetchInterval: 3000, // Refresh every 3 seconds to show real-time participants
  });

  // Join room mutation
  const joinRoomMutation = useMutation({
    mutationFn: async (data: JoinRoomData) => {
      // Create a guest user (anonymous) instead of persistent account
      const userResponse = await apiRequest("POST", "/api/users", {
        username: data.username,
        password: `guest-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`, // Unique temporary password
      });
      const guestUser = await userResponse.json();
      
      // Use roomId substring for invite code as expected by server
      const inviteCode = `${roomId!.substring(0, 8)}-invite`;
      
      const participantResponse = await apiRequest("POST", "/api/participants", {
        roomId: roomId!,
        userId: guestUser.id,
        inviteCode,
      });
      const participant = await participantResponse.json();
      
      return { user: guestUser, participant };
    },
    onSuccess: async ({ user, participant }) => {
      setCurrentUserId(user.id);
      setIsJoined(true);
      
      // Authenticate with PIRP system for avatar access
      try {
        await authenticate(roomId!, user.id);
        toast({
          title: "Welcome to the room!",
          description: `You've joined as ${user.username}. Avatar features are now available!`,
        });
      } catch (error) {
        console.error('PIRP authentication failed:', error);
        toast({
          title: "Welcome to the room!",
          description: `You've joined as ${user.username}. Ready to start the call?`,
        });
      }
      
      // Invalidate participants query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/rooms", roomId, "participants"] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to join room",
        description: error.message || "Please check the room ID and try again.",
        variant: "destructive",
      });
    },
  });

  // Handle join room
  const onJoinRoom = (data: JoinRoomData) => {
    joinRoomMutation.mutate(data);
  };

  // Copy invite link
  const copyInviteLink = async () => {
    const inviteLink = `${window.location.origin}/room/${roomId}/lobby`;
    
    try {
      await navigator.clipboard.writeText(inviteLink);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
      
      toast({
        title: "Invite link copied!",
        description: "Share this link to invite others to the room.",
      });
    } catch (err) {
      toast({
        title: "Failed to copy link",
        description: "Please copy the link manually from the address bar.",
        variant: "destructive",
      });
    }
  };

  // Start the video call
  const startCall = () => {
    setLocation(`/room/${roomId}/call`);
  };

  // Leave the lobby
  const leaveLobby = () => {
    setLocation("/");
  };

  // Handle room loading states
  if (isLoadingRoom) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Clock className="h-12 w-12 mx-auto mb-4 text-blue-600 animate-spin" />
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Loading room...</h2>
        </div>
      </div>
    );
  }

  if (roomError || !room) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="text-red-600">Room Not Found</CardTitle>
            <CardDescription>
              The room you're looking for doesn't exist or may have been deleted.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={leaveLobby} className="w-full" data-testid="button-back-home">
              <ArrowRight className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-2 bg-blue-600 rounded-full">
              <Video className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
              {room.name}
            </h1>
          </div>
          <div className="flex items-center justify-center gap-4">
            <Badge variant="outline" className="bg-white/80 dark:bg-slate-800/80">
              <Clock className="h-3 w-3 mr-1" />
              Lobby
            </Badge>
            <Button
              variant="outline"
              size="sm"
              onClick={copyInviteLink}
              data-testid="button-copy-invite-link"
              className="bg-white/80 dark:bg-slate-800/80"
            >
              {copiedLink ? (
                <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
              ) : (
                <Copy className="h-4 w-4 mr-2" />
              )}
              {copiedLink ? "Copied!" : "Copy Invite Link"}
            </Button>
          </div>
        </div>

        <div className="max-w-6xl mx-auto grid gap-8 lg:grid-cols-3">
          {/* Main Content - Video Preview & Join */}
          <div className="lg:col-span-2 space-y-6">
            {/* Video Preview */}
            <Card className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Monitor className="h-5 w-5" />
                  Camera & Microphone Setup
                </CardTitle>
                <CardDescription>
                  Test your camera and microphone before joining the call
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative bg-slate-100 dark:bg-slate-700 rounded-lg aspect-video flex items-center justify-center mb-6">
                  {isVideoOn ? (
                    <div className="text-slate-500 dark:text-slate-400">
                      <Video className="h-12 w-12 mx-auto mb-2" />
                      <p className="text-sm">Camera preview would appear here</p>
                    </div>
                  ) : (
                    <div className="text-slate-500 dark:text-slate-400">
                      <VideoOff className="h-12 w-12 mx-auto mb-2" />
                      <p className="text-sm">Camera is off</p>
                    </div>
                  )}
                </div>
                
                {/* Controls */}
                <div className="flex justify-center gap-4 mb-4">
                  <Button
                    variant={isVideoOn ? "default" : "outline"}
                    size="sm"
                    onClick={() => setIsVideoOn(!isVideoOn)}
                    data-testid="button-toggle-video"
                  >
                    {isVideoOn ? (
                      <Video className="h-4 w-4 mr-2" />
                    ) : (
                      <VideoOff className="h-4 w-4 mr-2" />
                    )}
                    {isVideoOn ? "Camera On" : "Camera Off"}
                  </Button>
                  
                  <Button
                    variant={isAudioOn ? "default" : "outline"}
                    size="sm"
                    onClick={() => setIsAudioOn(!isAudioOn)}
                    data-testid="button-toggle-audio"
                  >
                    {isAudioOn ? (
                      <Mic className="h-4 w-4 mr-2" />
                    ) : (
                      <MicOff className="h-4 w-4 mr-2" />
                    )}
                    {isAudioOn ? "Mic On" : "Mic Off"}
                  </Button>
                </div>

                {/* Pre-call diagnostics */}
                <div className="flex justify-center">
                  <PreCallCheck />
                </div>
              </CardContent>
            </Card>

            {/* Join Form or Call Controls */}
            {!isJoined ? (
              <Card className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Join the Room</CardTitle>
                  <CardDescription>
                    Enter your name to join the video call
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...joinForm}>
                    <form onSubmit={joinForm.handleSubmit(onJoinRoom)} className="space-y-4">
                      <FormField
                        control={joinForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Your Name</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Enter your name"
                                data-testid="input-username"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="flex gap-4">
                        <Button
                          type="submit"
                          className="flex-1"
                          disabled={joinRoomMutation.isPending}
                          data-testid="button-join-lobby"
                        >
                          {joinRoomMutation.isPending ? (
                            "Joining..."
                          ) : (
                            <>
                              <Users className="h-4 w-4 mr-2" />
                              Join Lobby
                            </>
                          )}
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={leaveLobby}
                          data-testid="button-leave-lobby"
                        >
                          <LogOut className="h-4 w-4 mr-2" />
                          Back
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Ready to Start?</CardTitle>
                  <CardDescription>
                    You're in the lobby. Click "Start Call" when ready to begin the video call.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4">
                    <Button
                      onClick={startCall}
                      className="flex-1"
                      data-testid="button-start-call"
                    >
                      <Video className="h-4 w-4 mr-2" />
                      Start Call
                    </Button>
                    <Button
                      variant="outline"
                      onClick={leaveLobby}
                      data-testid="button-leave-room"
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Leave
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar - Participants */}
          <div className="space-y-6">
            <Card className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Participants ({participants.length})
                </CardTitle>
                <CardDescription>
                  People in this room
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {participants.length === 0 ? (
                    <p className="text-sm text-slate-500 dark:text-slate-400 text-center py-4">
                      No participants yet
                    </p>
                  ) : (
                    participants.map((participant) => (
                      <div
                        key={participant.id}
                        className="flex items-center gap-3 p-2 bg-slate-50 dark:bg-slate-700 rounded-lg"
                        data-testid={`participant-${participant.id}`}
                      >
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="bg-blue-100 dark:bg-blue-900 text-blue-600 text-xs">
                            {participant.userId?.substring(0, 2).toUpperCase() || "??"}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">
                            User {participant.userId?.substring(0, 8)}
                            {participant.userId === currentUserId && " (You)"}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {participant.role === "host" ? "Host" : "Participant"}
                          </p>
                        </div>
                        {participant.role === "host" && (
                          <Badge variant="secondary" className="text-xs">
                            Host
                          </Badge>
                        )}
                        {!isJoined && (
                          <Badge variant="outline" className="text-xs">
                            Preview
                          </Badge>
                        )}
                      </div>
                    ))
                  )}
                  {!isJoined && participants.length > 0 && (
                    <p className="text-xs text-slate-500 dark:text-slate-400 text-center pt-2">
                      {participants.length} participant{participants.length === 1 ? '' : 's'} in this room
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Room Info */}
            <Card className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Room Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-slate-900 dark:text-white">Room ID</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                    {roomId}
                  </p>
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-900 dark:text-white">Created</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {room.createdAt ? new Date(room.createdAt).toLocaleString() : "Recently"}
                  </p>
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-900 dark:text-white">Privacy</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    PIRP-enabled with progressive reveal controls
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Avatar Setup - Show after joining */}
            {isJoined && (
              <Card className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Wand2 className="h-5 w-5" />
                    Avatar Setup
                  </CardTitle>
                  <CardDescription>
                    Customize your appearance for the call
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <Button
                      asChild
                      variant="outline"
                      size="sm"
                      className="w-full"
                      data-testid="button-create-avatar-lobby"
                    >
                      <a href="/avatar/create" target="_blank" rel="noopener noreferrer">
                        <Wand2 className="h-4 w-4 mr-2" />
                        Create New Avatar
                      </a>
                    </Button>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Links open in new tab so you don't lose your room connection
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}