import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { z } from "zod";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Room } from "@shared/schema";

import { Video, Plus, Users, Copy, CheckCircle, Shield, Lock, Eye } from "lucide-react";

const createRoomSchema = z.object({
  name: z.string().min(1, "Room name is required").max(50, "Room name too long"),
});

const joinRoomSchema = z.object({
  roomUrl: z.string().min(1, "Room URL or ID is required"),
});

type CreateRoomData = z.infer<typeof createRoomSchema>;
type JoinRoomData = z.infer<typeof joinRoomSchema>;

export default function Home() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  // Create room form
  const createForm = useForm<CreateRoomData>({
    resolver: zodResolver(createRoomSchema),
    defaultValues: { name: "" },
  });

  // Join room form
  const joinForm = useForm<JoinRoomData>({
    resolver: zodResolver(joinRoomSchema),
    defaultValues: { roomUrl: "" },
  });

  // Create room mutation
  const createRoomMutation = useMutation({
    mutationFn: async (data: CreateRoomData): Promise<Room> => {
      const response = await apiRequest("POST", "/api/rooms", {
        name: data.name,
        createdBy: null, // For MVP, not requiring user auth to create rooms
      });
      return response.json();
    },
    onSuccess: (room: Room) => {
      toast({
        title: "Room created successfully!",
        description: `Room "${room.name}" is ready for video calls.`,
      });
      
      // Navigate to the lobby for the new room
      setLocation(`/room/${room.id}/lobby`);
      
      // Reset form
      createForm.reset();
      
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["/api/rooms"] });
    },
    onError: () => {
      toast({
        title: "Failed to create room",
        description: "Please try again or check your connection.",
        variant: "destructive",
      });
    },
  });

  // Handle create room
  const onCreateRoom = (data: CreateRoomData) => {
    createRoomMutation.mutate(data);
  };

  // Handle join room with better error handling
  const onJoinRoom = (data: JoinRoomData) => {
    let roomId = data.roomUrl.trim();
    
    if (!roomId) {
      toast({
        title: "Room ID required",
        description: "Please enter a room URL or ID.",
        variant: "destructive",
      });
      return;
    }
    
    // Extract room ID from various URL formats
    if (data.roomUrl.includes('/room/')) {
      const match = data.roomUrl.match(/\/room\/([^\/\?]+)/);
      if (match) {
        roomId = match[1];
      }
    }
    
    // Remove any additional path parts (like /lobby or /call)
    roomId = roomId.split('/')[0].split('?')[0];
    
    // Validate roomId format (basic validation)
    if (roomId.length < 3) {
      toast({
        title: "Invalid room ID",
        description: "Please enter a valid room ID or URL.",
        variant: "destructive",
      });
      return;
    }
    
    // Navigate to the lobby
    setLocation(`/room/${roomId}/lobby`);
    
    // Reset form
    joinForm.reset();
  };

  // Copy invite link to clipboard
  const copyInviteLink = async (roomId: string, roomName: string) => {
    const inviteLink = `${window.location.origin}/room/${roomId}/lobby`;
    
    try {
      await navigator.clipboard.writeText(inviteLink);
      setCopiedLink(roomId);
      setTimeout(() => setCopiedLink(null), 2000);
      
      toast({
        title: "Invite link copied!",
        description: `Share this link to invite others to "${roomName}".`,
      });
    } catch (err) {
      toast({
        title: "Failed to copy link",
        description: "Please copy the link manually.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden text-foreground">
        {/* Highway night background with animated light trails */}
        <div className="absolute inset-0 w-full h-full -z-10">
          {/* Base solid background for mobile compatibility */}
          <div className="absolute inset-0 bg-slate-900" />
          
          {/* Night highway gradient - mobile optimized */}
          <div className="absolute inset-0" style={{
            background: 'linear-gradient(135deg, #0f172a 0%, #1e3a8a 40%, #581c87 100%)',
            opacity: '1'
          }} />
          
          {/* Mobile-compatible overlay */}
          <div className="absolute inset-0" style={{
            background: 'linear-gradient(to bottom, rgba(30, 58, 138, 0.3) 0%, rgba(88, 28, 135, 0.4) 50%, rgba(15, 23, 42, 0.6) 100%)',
            opacity: '1'
          }} />
          
          {/* Simplified light trails for mobile compatibility */}
          <div className="absolute inset-0 w-full h-full opacity-60">
            {/* Larger, more visible light streaks */}
            <div className="absolute top-1/4 left-0 w-full h-3" 
                 style={{ 
                   background: 'linear-gradient(to right, transparent 0%, rgba(59, 130, 246, 0.8) 50%, transparent 100%)',
                   animation: 'moveRight 4s ease-in-out infinite',
                   willChange: 'transform'
                 }} />
            <div className="absolute top-1/2 left-0 w-full h-2" 
                 style={{ 
                   background: 'linear-gradient(to right, transparent 0%, rgba(239, 68, 68, 0.6) 50%, transparent 100%)',
                   animation: 'moveLeft 5s ease-in-out infinite',
                   animationDelay: '1s',
                   willChange: 'transform'
                 }} />
            <div className="absolute top-3/4 left-0 w-full h-2" 
                 style={{ 
                   background: 'linear-gradient(to right, transparent 0%, rgba(255, 255, 255, 0.5) 50%, transparent 100%)',
                   animation: 'moveRight 3s ease-in-out infinite',
                   animationDelay: '0.5s',
                   willChange: 'transform'
                 }} />
          </div>
        </div>
        
        {/* Dark gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-tr from-black/80 via-black/60 to-blue-900/40 -z-10" />
        
        {/* Mobile-optimized CSS animations */}
        <style dangerouslySetInnerHTML={{
          __html: `
            @keyframes moveRight {
              0% { transform: translateX(-100%); opacity: 0; }
              20% { opacity: 0.8; }
              80% { opacity: 0.8; }
              100% { transform: translateX(100%); opacity: 0; }
            }
            @keyframes moveLeft {
              0% { transform: translateX(100%); opacity: 0; }
              20% { opacity: 0.8; }
              80% { opacity: 0.8; }
              100% { transform: translateX(-100%); opacity: 0; }
            }
            
            /* Ensure background is visible on all devices */
            @media (max-width: 768px) {
              .absolute.inset-0.bg-gradient-to-br {
                background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 50%, #581c87 100%) !important;
                opacity: 1 !important;
              }
            }
          `
        }} />

        <div className="max-w-5xl mx-auto px-6 py-24 text-center">
          {/* Brand first */}
          <div className="text-5xl md:text-6xl font-extrabold tracking-tight drop-shadow-lg">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary via-secondary to-primary">
              AvaCall
            </span>
          </div>

          {/* Tagline */}
          <h1 className="mt-3 text-4xl md:text-6xl font-extrabold tracking-tight drop-shadow-lg">
            Be seen when <span className="text-primary">you're ready</span>.
          </h1>

          {/* Staged reveal line */}
          <p className="mt-5 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Call as your avatar. Reveal your real self step by step —
            <span className="font-semibold text-foreground"> 25%</span> → 
            <span className="font-semibold text-foreground"> 50%</span> → 
            <span className="font-semibold text-foreground"> 75%</span> → 
            <span className="font-semibold text-foreground"> 100%</span>. 
            Privacy is built-in with the IronWall PIRP protocol.
          </p>

          {/* Call-to-action buttons */}
          <div className="mt-9 flex flex-wrap justify-center gap-4">
            <Button
              size="lg"
              className="px-6 py-3 bg-gradient-to-r from-primary to-secondary hover:opacity-90 font-semibold shadow-lg transition"
              data-testid="button-start-private-call"
              onClick={() => {
                const createRoomSection = document.getElementById('create-room');
                if (createRoomSection) {
                  createRoomSection.scrollIntoView({ behavior: 'smooth' });
                  // Focus on the room name input for better mobile UX
                  setTimeout(() => {
                    const roomNameInput = document.querySelector('[data-testid="input-room-name"]') as HTMLInputElement;
                    if (roomNameInput) {
                      roomNameInput.focus();
                    }
                  }, 500);
                }
              }}
            >
              Start a Private Call
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="px-6 py-3 border-border/40 hover:bg-muted/10 font-semibold transition"
              data-testid="button-create-avatar"
            >
              <Link href="/avatar/gallery">
                Create Your Avatar
              </Link>
            </Button>
          </div>

          {/* Trust bullets */}
          <div className="mt-14 grid gap-6 md:grid-cols-3 text-sm text-muted-foreground">
            <div className="bg-card/40 rounded-lg p-4 backdrop-blur-md border border-border/10 hover:border-primary/40 transition">
              <Shield className="w-5 h-5 mx-auto mb-2 text-primary" />
              <div><b className="text-foreground">No surprise reveals.</b> You control every step.</div>
            </div>
            <div className="bg-card/40 rounded-lg p-4 backdrop-blur-md border border-border/10 hover:border-primary/40 transition">
              <Lock className="w-5 h-5 mx-auto mb-2 text-primary" />
              <div><b className="text-foreground">On-device privacy.</b> Peer-to-peer video with consent logs.</div>
            </div>
            <div className="bg-card/40 rounded-lg p-4 backdrop-blur-md border border-border/10 hover:border-primary/40 transition">
              <Eye className="w-5 h-5 mx-auto mb-2 text-primary" />
              <div><b className="text-foreground">Your likeness protected.</b> Private avatars by default.</div>
            </div>
          </div>

          {/* Consent footer line */}
          <p className="mt-8 text-xs text-muted-foreground">
            By joining, you agree to staged reveal and consent rules.
          </p>
        </div>
      </section>

      {/* Room Creation Section */}
      <div className="container mx-auto px-4 py-16" id="create-room">

        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground mb-4">Start Your Private Call</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Create a room or join with an invite link to experience privacy-first video calling.
          </p>
        </div>

        <div className="max-w-4xl mx-auto grid gap-8 md:grid-cols-2">
          {/* Create Room */}
          <Card className="bg-card/80 backdrop-blur-sm border-border">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Plus className="h-5 w-5 text-blue-600" />
                <CardTitle>Create New Room</CardTitle>
              </div>
              <CardDescription>
                Start a new video call and invite others with a shareable link
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...createForm}>
                <form onSubmit={createForm.handleSubmit(onCreateRoom)} className="space-y-4">
                  <FormField
                    control={createForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Room Name</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Enter room name (e.g., Team Meeting)"
                            data-testid="input-room-name"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90"
                    disabled={createRoomMutation.isPending}
                    data-testid="button-create-room"
                  >
                    {createRoomMutation.isPending ? (
                      "Creating..."
                    ) : (
                      <>
                        <Plus className="h-4 w-4 mr-2" />
                        Create Room
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* Join Room */}
          <Card className="bg-card/80 backdrop-blur-sm border-border">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-green-600" />
                <CardTitle>Join Room</CardTitle>
              </div>
              <CardDescription>
                Enter a room URL or ID to join an existing video call
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...joinForm}>
                <form onSubmit={joinForm.handleSubmit(onJoinRoom)} className="space-y-4">
                  <FormField
                    control={joinForm.control}
                    name="roomUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Room URL or ID</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Paste invite link or enter room ID"
                            data-testid="input-room-url"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button
                    type="submit"
                    variant="outline"
                    className="w-full"
                    data-testid="button-join-room"
                  >
                    <Users className="h-4 w-4 mr-2" />
                    Join Room
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>

        {/* Features Overview */}
        <div className="max-w-4xl mx-auto mt-16" id="features">
          <h2 className="text-2xl font-bold text-center mb-8 text-foreground">
            How AvaCall Protects Your Privacy
          </h2>
          
          <div className="grid gap-6 md:grid-cols-3">
            <div className="text-center p-6 bg-card/60 rounded-lg backdrop-blur-sm border border-border/20">
              <div className="w-12 h-12 mx-auto mb-4 bg-primary/20 rounded-full flex items-center justify-center">
                <Video className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2 text-foreground">Progressive Reveal</h3>
              <p className="text-sm text-muted-foreground">
                Control your identity reveal from 0% to 100% with consent-based levels. Start as an avatar, reveal gradually.
              </p>
            </div>
            
            <div className="text-center p-6 bg-card/60 rounded-lg backdrop-blur-sm border border-border/20">
              <div className="w-12 h-12 mx-auto mb-4 bg-secondary/20 rounded-full flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-secondary" />
              </div>
              <h3 className="font-semibold mb-2 text-foreground">Trust Scoring</h3>
              <p className="text-sm text-muted-foreground">
                Build trust through positive interactions and earn reveal privileges from other participants.
              </p>
            </div>
            
            <div className="text-center p-6 bg-card/60 rounded-lg backdrop-blur-sm border border-border/20">
              <div className="w-12 h-12 mx-auto mb-4 bg-accent/50 rounded-full flex items-center justify-center">
                <Copy className="h-6 w-6 text-accent-foreground" />
              </div>
              <h3 className="font-semibold mb-2 text-foreground">Easy Sharing</h3>
              <p className="text-sm text-muted-foreground">
                Share rooms instantly with secure invite links - no accounts required. Just click and call.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}