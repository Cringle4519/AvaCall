import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import AvatarMaker from '@/components/AvatarMaker';
import { usePirpAuth } from '@/hooks/use-pirp-auth';

export default function AvatarCreate() {
  const [, setLocation] = useLocation();
  const { pirpUser, isAuthenticated } = usePirpAuth();
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);

  // Give time for authentication to load from localStorage
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsCheckingAuth(false);
    }, 100); // Small delay to allow useEffect in usePirpAuth to run
    return () => clearTimeout(timer);
  }, []);

  // Show loading while checking authentication
  if (isCheckingAuth) {
    return (
      <div className="min-h-screen bg-background p-4 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  // Require authentication for avatar creation
  if (!isAuthenticated || !pirpUser?.userId) {
    return (
      <div className="min-h-screen bg-background p-4 flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>
              You need to join a video call to authenticate before creating avatars.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => setLocation('/')}
              className="w-full"
              data-testid="button-back-to-home-auth"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            onClick={() => setLocation('/')}
            data-testid="button-back-to-home"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-foreground">Create Avatar</h1>
            <p className="text-muted-foreground">
              Upload a photo to generate your privacy-first avatar
            </p>
          </div>
        </div>

        {/* Avatar Creation Component */}
        <div className="max-w-4xl mx-auto">
          <AvatarMaker userId={pirpUser.userId} />
        </div>
      </div>
    </div>
  );
}