export function attachAutoReconnect(
  pc: RTCPeerConnection,
  renegotiate: () => Promise<void>
) {
  pc.addEventListener('iceconnectionstatechange', () => {
    const st = pc.iceConnectionState;
    if (st === 'disconnected' || st === 'failed') {
      // Try ICE restart via renegotiation
      renegotiate().catch(() => {
        // swallow; next state change may succeed
      });
    }
  });
}