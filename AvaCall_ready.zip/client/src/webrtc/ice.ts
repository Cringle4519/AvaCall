export const ICE_SERVERS: RTCIceServer[] = [
  { urls: 'stun:stun.l.google.com:19302' },
  {
    urls: ['turns:your.turn.host:5349', 'turn:your.turn.host:3478'],
    username: 'turnuser',
    credential: 'turnpass'
  }
];