// Background presets for virtual background system

export interface BackgroundPreset {
  id: string;
  label: string;
  image: string;
  position: string;
  size: string;
}

export const BG_PRESETS: BackgroundPreset[] = [
  // Existing presets (keeping compatibility with current system)
  {
    id: 'office',
    label: 'Office',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080',
    position: 'center center',
    size: 'cover'
  },
  {
    id: 'library',
    label: 'Library',
    image: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080',
    position: 'center center',
    size: 'cover'
  },
  {
    id: 'nature',
    label: 'Nature',
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080',
    position: 'center center',
    size: 'cover'
  },
  {
    id: 'bedroom',
    label: 'Bedroom',
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080',
    position: 'center center',
    size: 'cover'
  },
  {
    id: 'cafe',
    label: 'Café',
    image: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080',
    position: 'center center',
    size: 'cover'
  },
  // ⭐ New scene backgrounds
  {
    id: 'rooftop-night',
    label: 'Rooftop Night',
    image: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?q=80&w=1920&auto=format&fit=crop',
    position: 'center center',
    size: 'cover'
  },
  {
    id: 'neon-city',
    label: 'Neon City',
    image: 'https://images.unsplash.com/photo-1518306727298-4c0dcea0e6f3?q=80&w=1920&auto=format&fit=crop',
    position: 'center center',
    size: 'cover'
  }
];

// Helper function to get background by ID
export function getBackgroundById(id: string): BackgroundPreset | undefined {
  return BG_PRESETS.find(preset => preset.id === id);
}

// Helper function to get all background IDs
export function getBackgroundIds(): string[] {
  return BG_PRESETS.map(preset => preset.id);
}