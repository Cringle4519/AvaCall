// Ambience audio system for scenes

import { useEffect, useRef, useState } from 'react';

// Ambience audio URLs - Disabled for now due to CORS and autoplay issues
const AMBIENCE: Record<string, string> = {
  fireplace: '', // Disabled - no reliable CORS-free source
  forest: '', // Disabled - no reliable CORS-free source
  city: '', // Disabled - no reliable CORS-free source
  none: ''
};

interface UseAmbienceProps {
  ambienceType: string;
  volume?: number;
  enabled?: boolean;
}

export function useAmbience({ 
  ambienceType, 
  volume = 0.3, 
  enabled = true 
}: UseAmbienceProps) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Cleanup previous audio
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
      setIsPlaying(false);
    }

    // Skip if disabled or no ambience
    if (!enabled || ambienceType === 'none' || !AMBIENCE[ambienceType]) {
      return;
    }

    const audioUrl = AMBIENCE[ambienceType];
    setIsLoading(true);
    setError(null);

    // Create new audio element
    const audio = new Audio(audioUrl);
    audio.loop = true;
    audio.volume = volume;
    
    // Handle audio events
    audio.addEventListener('canplaythrough', () => {
      setIsLoading(false);
      audio.play().then(() => {
        setIsPlaying(true);
      }).catch((err) => {
        setError('Failed to play audio: ' + err.message);
        setIsLoading(false);
      });
    });

    audio.addEventListener('error', () => {
      setError('Failed to load audio');
      setIsLoading(false);
    });

    audioRef.current = audio;

    // Cleanup function
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      setIsPlaying(false);
      setIsLoading(false);
    };
  }, [ambienceType, enabled]);

  // Update volume when it changes
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const togglePlayback = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch((err) => {
        setError('Failed to play audio: ' + err.message);
      });
    }
  };

  const stop = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setIsPlaying(false);
    }
  };

  return {
    isPlaying,
    isLoading,
    error,
    togglePlayback,
    stop,
    hasAmbience: ambienceType !== 'none' && !!AMBIENCE[ambienceType]
  };
}

// Helper function to get available ambience types
export function getAmbienceTypes(): string[] {
  return Object.keys(AMBIENCE).filter(type => type !== 'none');
}

// Helper function to check if ambience type exists
export function isValidAmbienceType(type: string): boolean {
  return type in AMBIENCE;
}