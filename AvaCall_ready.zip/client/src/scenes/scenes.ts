// Scene configuration system with background, LUT, and ambience settings

export interface Scene {
  id: string;
  label: string;
  bgId: string;  // References background preset ID
  lut: string;   // LUT filter type
  ambience: string; // Ambience audio type
}

export const SCENES: Scene[] = [
  // Existing scenes (mapped to current backgrounds)
  { 
    id: 'office-professional', 
    label: 'Professional Office', 
    bgId: 'office', 
    lut: 'none', 
    ambience: 'none' 
  },
  { 
    id: 'library-study', 
    label: 'Study Library', 
    bgId: 'library', 
    lut: 'warm', 
    ambience: 'none' 
  },
  { 
    id: 'nature-calm', 
    label: 'Calm Nature', 
    bgId: 'nature', 
    lut: 'cool', 
    ambience: 'forest' 
  },
  { 
    id: 'bedroom-cozy', 
    label: 'Cozy Bedroom', 
    bgId: 'bedroom', 
    lut: 'warm', 
    ambience: 'none' 
  },
  { 
    id: 'cafe-casual', 
    label: 'Casual Café', 
    bgId: 'cafe', 
    lut: 'warm', 
    ambience: 'none' 
  },
  // ⭐ New city scenes
  { 
    id: 'rooftop-night', 
    label: 'Rooftop Night', 
    bgId: 'rooftop-night', 
    lut: 'cool', 
    ambience: 'city' 
  },
  { 
    id: 'neon-city', 
    label: 'Neon City', 
    bgId: 'neon-city', 
    lut: 'neon', 
    ambience: 'city' 
  }
];

// Helper function to get scene by ID
export function getSceneById(id: string): Scene | undefined {
  return SCENES.find(scene => scene.id === id);
}

// Helper function to get all scene IDs
export function getSceneIds(): string[] {
  return SCENES.map(scene => scene.id);
}

// Helper function to get scenes by LUT type
export function getScenesByLut(lut: string): Scene[] {
  return SCENES.filter(scene => scene.lut === lut);
}

// Helper function to get scenes by ambience type  
export function getScenesByAmbience(ambience: string): Scene[] {
  return SCENES.filter(scene => scene.ambience === ambience);
}