import express, { type Request, Response, NextFunction } from "express";
import path from "path";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import lobbyRouter from "./lobby.router";
import avatarRoutes from "./avatar.routes";
import { corsTight, cspTight, rateLimit } from './security.middleware';
import { requireAuth } from './auth';
import authRoutes from './auth.routes';
import reportRoutes from './report.routes';
import analyticsRoutes from './analytics.routes';

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Security middleware
app.use(corsTight);
app.use(cspTight);

// Simple auth middleware for lobby system
app.use((req: any, _res, next) => {
  // Only set for lobby routes to avoid conflicts with JWT system
  if (req.path.startsWith('/api/room')) {
    req.user = { id: req.header('x-user-id') ?? 'anon' };
  }
  next();
});

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Rate-limit specific endpoints
  app.use('/room', rateLimit(20, 60_000));
  app.use('/api/room', rateLimit(20, 60_000));
  app.use('/api/room/:id/knock', rateLimit(30, 60_000));

  // Public routes (no auth required)
  app.use(authRoutes);
  app.use(reportRoutes);
  app.use(analyticsRoutes);

  // Mount lobby routes
  app.use('/api', lobbyRouter);
  
  // Mount avatar routes
  app.use('/api/avatar', avatarRoutes);
  
  // Serve static avatar uploads
  app.use('/uploads/avatars', express.static(path.join(process.cwd(), 'uploads', 'avatars')));
  
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || '5000', 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
