import { Router } from 'express';
import { rateLimit } from './security.middleware';

const r = Router();
type Report = { roomId?: string; userId?: string; reason: string; ts: number };
const reports: Report[] = [];

r.post('/report', rateLimit(10, 60_000), (req, res) => {
  const { roomId, reason } = req.body ?? {};
  const userId = (req as any).user?.id ?? 'anon';
  if (!reason || String(reason).length < 3) return res.status(400).json({ error: 'reason_required' });
  reports.push({ roomId, userId, reason: String(reason).slice(0, 500), ts: Date.now() });
  res.json({ ok: true });
});

export default r;