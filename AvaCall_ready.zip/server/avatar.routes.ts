import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs/promises';
import { storage } from './storage';
import { insertUserAvatarSchema } from '@shared/schema';
import { z } from 'zod';

const router = Router();

// In-memory file processing configuration for privacy-first avatar creation
const upload = multer({
  storage: multer.memoryStorage(), // Process in memory only - no disk storage
  limits: { fileSize: 8 * 1024 * 1024 }, // 8MB limit
  fileFilter: (_req, file, cb) => {
    const allowedTypes = /image\/(jpeg|png|webp)/;
    const isValidType = allowedTypes.test(file.mimetype);
    if (isValidType) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG, PNG, and WebP are allowed.'));
    }
  }
});

// POST /api/avatar/process - Process uploaded photo in-memory (no storage of originals)
router.post('/process', upload.single('file'), async (req, res) => {
  try {
    // TODO: Add authentication middleware to verify user is authenticated
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    console.log(`Processing uploaded file: ${req.file.originalname}, size: ${req.file.size} bytes, type: ${req.file.mimetype}`);

    // Convert uploaded file buffer to data URL for client-side processing
    const base64Data = req.file.buffer.toString('base64');
    const dataUrl = `data:${req.file.mimetype};base64,${base64Data}`;

    // Return the data URL so the client can process it (3D rendering, stylization, etc.)
    res.json({ 
      success: true, 
      url: dataUrl,
      originalName: req.file.originalname,
      size: req.file.size,
      type: req.file.mimetype,
      message: 'Photo uploaded successfully - ready for avatar generation'
    });

    // Original file buffer is discarded after this response - never stored permanently
  } catch (error) {
    console.error('Avatar processing error:', error);
    if (error instanceof multer.MulterError) {
      if (error.code === 'LIMIT_FILE_SIZE') {
        return res.status(413).json({ error: 'File too large. Maximum size is 8MB.' });
      }
    }
    res.status(500).json({ error: 'Avatar processing failed' });
  }
});

// POST /api/avatar/create - Create user avatar record
router.post('/create', async (req, res) => {
  try {
    // TODO: Replace with proper session-based auth when implemented
    // For now, validate that userId is provided and consistent
    const avatarData = insertUserAvatarSchema.parse(req.body);
    if (!avatarData.userId) {
      return res.status(401).json({ error: 'Authentication required - userId missing' });
    }
    
    const avatar = await storage.createUserAvatar(avatarData);
    res.json(avatar);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Invalid avatar data', details: error.errors });
    }
    console.error('Avatar creation error:', error);
    res.status(500).json({ error: 'Failed to create avatar' });
  }
});

// GET /api/avatar/:userId - Get user's current avatar
router.get('/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    // TODO: Add proper auth middleware - for now allow all reads for MVP
    // In production, should verify requester has permission to view this avatar
    
    const avatar = await storage.getUserAvatar(userId);
    
    if (!avatar) {
      return res.status(404).json({ error: 'Avatar not found' });
    }
    
    res.json(avatar);
  } catch (error) {
    console.error('Get avatar error:', error);
    res.status(500).json({ error: 'Failed to get avatar' });
  }
});

// PUT /api/avatar/:userId - Update user avatar
router.put('/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    // TODO: Add auth middleware - verify req.user.id === userId
    const updates = req.body;
    
    const updatedAvatar = await storage.updateUserAvatar(userId, updates);
    
    if (!updatedAvatar) {
      return res.status(404).json({ error: 'Avatar not found' });
    }
    
    res.json(updatedAvatar);
  } catch (error) {
    console.error('Update avatar error:', error);
    res.status(500).json({ error: 'Failed to update avatar' });
  }
});

// DELETE /api/avatar/:userId - Delete user avatar
router.delete('/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    // TODO: Add auth middleware - verify req.user.id === userId
    await storage.deleteUserAvatar(userId);
    res.json({ success: true });
  } catch (error) {
    console.error('Delete avatar error:', error);
    res.status(500).json({ error: 'Failed to delete avatar' });
  }
});

export default router;