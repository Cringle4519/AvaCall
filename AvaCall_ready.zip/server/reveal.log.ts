import fs from 'fs';
import path from 'path';

export type RevealEvent =
  | { type:'request'; roomId:string; from:string; to:string|null; target:number; ts:number }
  | { type:'decision'; roomId:string; subject:string; by:string; level:number; approve:boolean; ts:number }
  | { type:'level'; roomId:string; userId:string; level:number; ts:number };

const DATA_DIR = path.join(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

function fileFor(roomId: string) { return path.join(DATA_DIR, `reveal-${roomId}.log`); }

export function logEvent(e: RevealEvent) {
  const line = JSON.stringify(e) + '\n';
  fs.appendFile(fileFor(e.roomId), line, () => {});
}

export function getRoomLogs(roomId: string): RevealEvent[] {
  try {
    const text = fs.readFileSync(fileFor(roomId), 'utf-8');
    return text.split('\n').filter(Boolean).map(l => JSON.parse(l));
  } catch { return []; }
}