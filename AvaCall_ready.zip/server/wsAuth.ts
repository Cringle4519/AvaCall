import jwt from 'jsonwebtoken';
const JWT_SECRET = process.env.JWT_SECRET || process.env.SESSION_SECRET || 'dev-secret-change-me';

export function parseTokenFromUrl(url: string) {
  try {
    const u = new URL(url, 'http://localhost'); // base ignored
    const t = u.searchParams.get('token');
    if (!t) return null;
    const claims = jwt.verify(t, JWT_SECRET) as any;
    return { userId: claims.sub as string, roomId: claims.roomId as string, role: claims.role as 'host'|'guest' };
  } catch {
    return null;
  }
}