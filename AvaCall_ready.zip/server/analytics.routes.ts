import { Router } from 'express';
import { rateLimit } from './security.middleware';

const r = Router();
type Event = { type: string; roomId?: string; userId?: string; at: number; extra?: any };
const events: Event[] = [];

r.post('/analytics', rateLimit(60, 60_000), (req, res) => {
  const { type, roomId, extra } = req.body ?? {};
  const userId = (req as any).user?.id ?? 'anon';
  if (!type) return res.status(400).json({ error: 'type_required' });
  events.push({ type, roomId, userId, extra, at: Date.now() });
  res.json({ ok: true });
});

r.get('/analytics/debug', (req, res) => res.json({ count: events.length, sample: events.slice(-20) }));
export default r;