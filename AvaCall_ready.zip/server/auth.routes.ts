import { Router } from 'express';
import { signJoinToken, requireAuth } from './auth';

const r = Router();

/**
 * Issue a short-lived room token.
 * Body: { userId: string, roomId: string, role: 'host'|'guest' }
 */
r.post('/auth/join', (req, res) => {
  const { userId, roomId, role } = req.body || {};
  if (!userId || !roomId || (role !== 'host' && role !== 'guest')) {
    return res.status(400).json({ error: 'bad_request' });
  }
  const token = signJoinToken(String(userId), String(roomId), role);
  res.json({ token });
});

/** Who am I? (debug) */
r.get('/auth/me', requireAuth, (req: any, res) => res.json({ user: req.user }));

export default r;