import { Router } from 'express';
import { getRoomLogs } from './reveal.log';

const r = Router();

r.get('/pirp/reveal/logs/:roomId', (req, res) => {
  res.json({ roomId: req.params.roomId, events: getRoomLogs(req.params.roomId) });
});

r.get('/pirp/reveal/report/:roomId', (req, res) => {
  const roomId = req.params.roomId, events = getRoomLogs(roomId);
  const started = events[0]?.ts ? new Date(events[0].ts).toLocaleString() : 'N/A';
  const ended = events[events.length-1]?.ts ? new Date(events[events.length-1].ts).toLocaleString() : 'N/A';
  const rows = events.map(e => {
    const t = new Date(e.ts).toLocaleString();
    if (e.type==='request')  return `<tr><td>${t}</td><td>REQUEST</td><td>${e.from} → ${e.to ?? 'all'}</td><td>Target ${e.target}%</td></tr>`;
    if (e.type==='decision') return `<tr><td>${t}</td><td>${e.approve?'APPROVE':'DENY'}</td><td>${e.by} → ${e.subject}</td><td>Level ${e.level}%</td></tr>`;
    return `<tr><td>${t}</td><td>LEVEL</td><td>${e.userId}</td><td>Set to ${e.level}%</td></tr>`;
  }).join('');
  res.setHeader('Content-Type','text/html; charset=utf-8');
  res.send(`<!doctype html><html><head><meta charset="utf-8"/>
<title>AvaCall Consent Certificate – Room ${roomId}</title>
<style>body{font:14px/1.4 system-ui,-apple-system,Segoe UI,Roboto;padding:24px;color:#111}
h1,h2{margin:0 0 8px}.card{border:1px solid #ddd;border-radius:8px;padding:16px;margin:12px 0}
table{width:100%;border-collapse:collapse;margin-top:8px}th,td{border-bottom:1px solid #eee;padding:8px;text-align:left}
.muted{color:#666}@media print{.noprint{display:none}}
.header{display:flex;justify-content:space-between;align-items:center}.badge{background:#111;color:#fff;padding:6px 10px;border-radius:8px;font-weight:600}
.footer{margin-top:16px;font-size:12px;color:#666}</style></head>
<body>
<div class="header"><h1>AvaCall Consent Certificate</h1><div class="badge">Room ${roomId}</div></div>
<div class="card"><div><strong>Session start:</strong> ${started}</div><div><strong>Session end:</strong> ${ended}</div>
<div class="muted">Each reveal step requires mutual consent. This report is an append-only log.</div></div>
<div class="card"><h2>Reveal Timeline</h2>
<table><thead><tr><th>Time</th><th>Action</th><th>Actors</th><th>Details</th></tr></thead>
<tbody>${rows || `<tr><td colspan="4" class="muted">No events recorded.</td></tr>`}</tbody></table></div>
<div class="noprint"><button onclick="window.print()" style="padding:10px 14px;border:1px solid #222;border-radius:8px;background:#fff;cursor:pointer">Download as PDF</button></div>
<div class="footer">© ${new Date().getFullYear()} AvaCall • IronWall PIRP</div></body></html>`);
});

export default r;