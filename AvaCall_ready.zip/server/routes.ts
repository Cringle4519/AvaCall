import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { insertUserSchema, insertRoomSchema, insertParticipantSchema, insertConsentSchema, insertTrustEventSchema, insertRevealLogSchema, insertChatMessageSchema } from "@shared/schema";
import { z } from "zod";
import { generateJWT, authMiddleware, requireRoomAccess, requireHostRole, type AuthenticatedRequest } from "./auth";
import revealRoutes from './reveal.routes';
import { logEvent } from './reveal.log';

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Ensure upload directories exist
  const uploadsDir = path.join(process.cwd(), 'uploads');
  const avatarsDir = path.join(uploadsDir, 'avatars');
  const backgroundsDir = path.join(uploadsDir, 'backgrounds');
  
  [uploadsDir, avatarsDir, backgroundsDir].forEach(dir => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  });

  // Configure multer for file uploads
  const avatarStorage = multer.diskStorage({
    destination: avatarsDir,
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, `avatar-${uniqueSuffix}${path.extname(file.originalname)}`);
    }
  });

  const backgroundStorage = multer.diskStorage({
    destination: backgroundsDir,
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, `background-${uniqueSuffix}${path.extname(file.originalname)}`);
    }
  });

  const uploadAvatar = multer({ 
    storage: avatarStorage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
    fileFilter: (req, file, cb) => {
      if (file.mimetype.startsWith('image/')) {
        cb(null, true);
      } else {
        cb(new Error('Only image files are allowed'));
      }
    }
  });

  const uploadBackground = multer({ 
    storage: backgroundStorage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
    fileFilter: (req, file, cb) => {
      if (file.mimetype.startsWith('image/')) {
        cb(null, true);
      } else {
        cb(new Error('Only image files are allowed'));
      }
    }
  });

  // WebSocket server for WebRTC signaling
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Store active connections
  const connections = new Map<string, WebSocket>();
  const roomConnections = new Map<string, Set<string>>();
  // Track user identity for security (clientId -> pirpUserId mapping)
  const clientToUser = new Map<string, string>();

  wss.on('connection', (ws) => {
    let clientId: string;
    let roomId: string;

    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        switch (data.type) {
          case 'join-room':
            clientId = data.clientId;
            roomId = data.roomId;
            
            // Generate secure server-side pirpUserId to prevent client forgery
            const pirpUserId = `user_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
            
            connections.set(clientId, ws);
            // Immediately establish secure identity mapping
            clientToUser.set(clientId, pirpUserId);
            
            if (!roomConnections.has(roomId)) {
              roomConnections.set(roomId, new Set());
            }
            roomConnections.get(roomId)!.add(clientId);

            // Notify other participants in the room
            const roomParticipants = roomConnections.get(roomId)!;
            roomParticipants.forEach(participantId => {
              if (participantId !== clientId) {
                const participantWs = connections.get(participantId);
                if (participantWs && participantWs.readyState === WebSocket.OPEN) {
                  participantWs.send(JSON.stringify({
                    type: 'user-joined',
                    clientId: clientId
                  }));
                }
              }
            });

            ws.send(JSON.stringify({
              type: 'joined-room',
              roomId: roomId,
              participants: Array.from(roomParticipants).filter(id => id !== clientId),
              // Send assigned pirpUserId back to client securely
              pirpUserId: pirpUserId
            }));
            
            console.log(`Secure PIRP identity assigned: clientId ${clientId} -> user ${pirpUserId}`);
            break;

          case 'webrtc-offer':
          case 'webrtc-answer':
          case 'webrtc-ice-candidate':
            // Forward WebRTC signaling messages to the target peer
            const targetWs = connections.get(data.targetId);
            if (targetWs && targetWs.readyState === WebSocket.OPEN) {
              targetWs.send(JSON.stringify({
                ...data,
                senderId: clientId
              }));
            }
            break;

          case 'PIRP_AUTH':
            // DEPRECATED: pirpUserId now assigned server-side during join-room for security
            // This message type is preserved for compatibility but ignored
            console.log(`Ignoring client PIRP_AUTH - using server-assigned identity for security`);
            break;

          case 'leave-room':
            if (roomId && clientId) {
              const roomParticipants = roomConnections.get(roomId);
              if (roomParticipants) {
                roomParticipants.delete(clientId);
                
                // Notify other participants
                roomParticipants.forEach(participantId => {
                  const participantWs = connections.get(participantId);
                  if (participantWs && participantWs.readyState === WebSocket.OPEN) {
                    participantWs.send(JSON.stringify({
                      type: 'user-left',
                      clientId: clientId
                    }));
                  }
                });
              }
              connections.delete(clientId);
            }
            break;

          case 'REVEAL_REQUEST':
            // Log the reveal request for audit trail
            if (roomId && clientId) {
              const fromUserId = clientToUser.get(clientId);
              if (fromUserId) {
                logEvent({
                  type: 'request',
                  roomId: roomId,
                  from: fromUserId,
                  to: data.to || null,
                  target: data.targetLevel,
                  ts: Date.now()
                });
              }
            }
            
            // Forward reveal request to target participant(s)
            if (roomId) {
              const roomParticipants = roomConnections.get(roomId);
              if (roomParticipants) {
                const targetId = data.to;
                if (targetId) {
                  // Send to specific participant
                  const targetWs = connections.get(targetId);
                  if (targetWs && targetWs.readyState === WebSocket.OPEN) {
                    targetWs.send(JSON.stringify({
                      type: 'REVEAL_REQUEST',
                      roomId: roomId,
                      from: clientId,
                      to: targetId,
                      targetLevel: data.targetLevel
                    }));
                  }
                } else {
                  // Broadcast to all participants
                  roomParticipants.forEach(participantId => {
                    if (participantId !== clientId) {
                      const participantWs = connections.get(participantId);
                      if (participantWs && participantWs.readyState === WebSocket.OPEN) {
                        participantWs.send(JSON.stringify({
                          type: 'REVEAL_REQUEST',
                          roomId: roomId,
                          from: clientId,
                          to: null,
                          targetLevel: data.targetLevel
                        }));
                      }
                    }
                  });
                }
              }
            }
            break;

          case 'REVEAL_DECISION':
            // Security: Only allow approving your own reveal level
            if (roomId && clientId) {
              const approverUserId = clientToUser.get(clientId);
              
              // Validate that the approver can only approve their own reveal
              if (approverUserId && approverUserId === data.subjectUserId) {
                const roomParticipants = roomConnections.get(roomId);
                
                // Log the decision for audit trail
                logEvent({
                  type: 'decision',
                  roomId: roomId,
                  subject: data.subjectUserId,
                  by: approverUserId,
                  level: data.level,
                  approve: data.approve,
                  ts: Date.now()
                });
                
                // Send decision feedback to the requester
                roomParticipants?.forEach(participantId => {
                  const participantWs = connections.get(participantId);
                  if (participantWs && participantWs.readyState === WebSocket.OPEN) {
                    participantWs.send(JSON.stringify({
                      type: 'REVEAL_DECISION',
                      roomId: roomId,
                      consentId: data.consentId,
                      approve: data.approve,
                      level: data.level,
                      subjectUserId: data.subjectUserId
                    }));
                  }
                });
                
                // If approved, broadcast authoritative level update
                if (data.approve && roomParticipants) {
                  // Log the level change for audit trail
                  logEvent({
                    type: 'level',
                    roomId: roomId,
                    userId: approverUserId,
                    level: data.level,
                    ts: Date.now()
                  });
                  
                  roomParticipants.forEach(participantId => {
                    const participantWs = connections.get(participantId);
                    if (participantWs && participantWs.readyState === WebSocket.OPEN) {
                      participantWs.send(JSON.stringify({
                        type: 'REVEAL_LEVEL',
                        roomId: roomId,
                        userId: approverUserId,
                        level: data.level
                      }));
                    }
                  });
                }
              } else {
                // Security violation: client tried to approve someone else's reveal
                console.warn(`Security violation: Client ${clientId} (user: ${approverUserId}) tried to approve reveal for user ${data.subjectUserId}`);
                ws.send(JSON.stringify({
                  type: 'error',
                  message: 'Unauthorized: You can only approve your own reveal level'
                }));
              }
            }
            break;

          case 'chat-message':
            // Handle chat messages during calls
            if (roomId && clientId && data.message) {
              try {
                // Get the user ID for this client
                const fromUserId = clientToUser.get(clientId);
                
                if (fromUserId) {
                  // Validate and create chat message
                  const messageData = insertChatMessageSchema.parse({
                    roomId: roomId,
                    userId: fromUserId,
                    message: data.message,
                    messageType: data.messageType || 'text'
                  });

                  // Store message in database
                  const chatMessage = await storage.createChatMessage(messageData);

                  // Broadcast message to all participants in the room
                  const roomParticipants = roomConnections.get(roomId);
                  if (roomParticipants) {
                    roomParticipants.forEach(participantId => {
                      const participantWs = connections.get(participantId);
                      if (participantWs && participantWs.readyState === WebSocket.OPEN) {
                        participantWs.send(JSON.stringify({
                          type: 'chat-message',
                          messageId: chatMessage.id,
                          roomId: roomId,
                          userId: fromUserId,
                          message: chatMessage.message,
                          messageType: chatMessage.messageType,
                          timestamp: chatMessage.timestamp,
                          senderClientId: clientId // Include sender client ID for UI purposes
                        }));
                      }
                    });
                  }
                }
              } catch (error) {
                console.error('Chat message error:', error);
                ws.send(JSON.stringify({
                  type: 'error',
                  message: 'Failed to send chat message'
                }));
              }
            }
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      if (roomId && clientId) {
        const roomParticipants = roomConnections.get(roomId);
        if (roomParticipants) {
          roomParticipants.delete(clientId);
          
          // Notify other participants
          roomParticipants.forEach(participantId => {
            const participantWs = connections.get(participantId);
            if (participantWs && participantWs.readyState === WebSocket.OPEN) {
              participantWs.send(JSON.stringify({
                type: 'user-left',
                clientId: clientId
              }));
            }
          });
        }
        connections.delete(clientId);
      }
    });
  });

  // REST API routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  app.post("/api/rooms", async (req, res) => {
    try {
      const roomData = insertRoomSchema.parse(req.body);
      const room = await storage.createRoom(roomData);
      res.json(room);
    } catch (error) {
      res.status(400).json({ message: "Invalid room data" });
    }
  });

  app.get("/api/rooms/:id", async (req, res) => {
    try {
      const room = await storage.getRoom(req.params.id);
      if (!room) {
        return res.status(404).json({ message: "Room not found" });
      }
      res.json(room);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/participants", async (req, res) => {
    try {
      const { roomId, userId, inviteCode } = req.body;
      
      if (!roomId || !userId) {
        return res.status(400).json({ message: "roomId and userId are required" });
      }

      // SECURITY: Require invite code or verify room is publicly joinable
      const room = await storage.getRoom(roomId);
      if (!room) {
        return res.status(404).json({ message: "Room not found" });
      }

      // Simple invite code check (in production, use cryptographically secure codes)
      const expectedInviteCode = `${roomId.substring(0, 8)}-invite`;
      if (inviteCode !== expectedInviteCode) {
        return res.status(403).json({ message: "Invalid invite code" });
      }

      // Check if user is already a participant
      const existingParticipants = await storage.getParticipantsByRoom(roomId);
      const existingParticipant = existingParticipants.find(p => p.userId === userId);
      
      if (existingParticipant) {
        return res.status(409).json({ message: "User already in room" });
      }

      const participantData = insertParticipantSchema.parse({
        roomId,
        userId,
        role: existingParticipants.length === 0 ? 'host' : 'participant', // First user becomes host
        currentLevel: 0,
        trustScore: 0
      });
      
      const participant = await storage.createParticipant(participantData);
      res.json(participant);
    } catch (error) {
      console.error('Participant creation error:', error);
      res.status(400).json({ message: "Invalid participant data" });
    }
  });

  app.get("/api/rooms/:roomId/participants", async (req, res) => {
    try {
      const participants = await storage.getParticipantsByRoom(req.params.roomId);
      res.json(participants);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get chat messages for a room
  app.get("/api/rooms/:roomId/messages", async (req, res) => {
    try {
      const messages = await storage.getChatMessagesByRoom(req.params.roomId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // File upload routes
  app.post("/api/upload/avatar", uploadAvatar.single('avatar'), (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const fileUrl = `/uploads/avatars/${req.file.filename}`;
      res.json({ 
        message: "Avatar uploaded successfully",
        url: fileUrl,
        filename: req.file.filename
      });
    } catch (error) {
      console.error('Avatar upload error:', error);
      res.status(500).json({ message: "Upload failed" });
    }
  });

  app.post("/api/upload/background", uploadBackground.single('background'), (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const fileUrl = `/uploads/backgrounds/${req.file.filename}`;
      res.json({ 
        message: "Background uploaded successfully",
        url: fileUrl,
        filename: req.file.filename
      });
    } catch (error) {
      console.error('Background upload error:', error);
      res.status(500).json({ message: "Upload failed" });
    }
  });

  // Serve uploaded files
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

  // JWT Authentication endpoint for PIRP
  app.post("/api/auth/pirp-token", async (req, res) => {
    try {
      const { roomId, userId } = req.body;
      
      if (!roomId || !userId) {
        return res.status(400).json({ error: 'roomId and userId are required' });
      }

      // Verify room exists
      const room = await storage.getRoom(roomId);
      if (!room) {
        return res.status(404).json({ error: 'Room not found' });
      }

      // CRITICAL SECURITY: Verify user is an actual participant in the room
      const participants = await storage.getParticipantsByRoom(roomId);
      const participant = participants.find(p => p.userId === userId && p.isActive);
      
      if (!participant) {
        return res.status(403).json({ error: 'Unauthorized: Not a participant in this room' });
      }

      // Generate JWT token with verified participant data
      const role = (participant.role === 'host' ? 'host' : 'participant') as 'host' | 'participant';
      const token = generateJWT({ 
        roomId, 
        userId, 
        role
      });
      
      res.json({ 
        token,
        expiresIn: '2h',
        user: { 
          roomId, 
          userId, 
          role: participant.role || 'participant',
          currentLevel: participant.currentLevel || 0,
          trustScore: participant.trustScore || 0
        }
      });
    } catch (error) {
      console.error('PIRP token generation error:', error);
      res.status(500).json({ error: 'Failed to generate token' });
    }
  });

  // PIRP API Routes - All protected with JWT and room scope
  app.use('/api/pirp', authMiddleware);
  
  // PIRP Audit/Certificate Routes
  app.use(revealRoutes);

  // Request a reveal step (25/50/75/100)
  app.post('/api/pirp/reveal/request', requireRoomAccess, async (req, res) => {
    try {
      const authReq = req as AuthenticatedRequest;
      const { targetUserId, level } = req.body;
      
      if (!targetUserId || !level || ![25, 50, 75, 100].includes(level)) {
        return res.status(400).json({ error: 'Valid targetUserId and level (25/50/75/100) required' });
      }

      // Get participants to check current levels and request history
      const participants = await storage.getParticipantsByRoom(authReq.user.roomId);
      const requesterParticipant = participants.find(p => p.userId === authReq.user.userId);
      const targetParticipant = participants.find(p => p.userId === targetUserId);

      if (!requesterParticipant || !targetParticipant) {
        return res.status(404).json({ error: 'Participants not found' });
      }

      // Check for spam: get recent requests from this user (last 5 minutes)
      const recentRequests = await storage.getConsentsByFromUser(authReq.user.userId);
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
      const recentSpamRequests = recentRequests.filter(r => 
        r.createdAt && r.createdAt > fiveMinutesAgo
      );

      // Evaluate request appropriateness
      const currentLevel = requesterParticipant.currentLevel || 0;
      const requestedLevel = level;
      const isAppropriateProgression = requestedLevel > currentLevel && requestedLevel <= currentLevel + 50;
      const isSpamming = recentSpamRequests.length > 3; // More than 3 requests in 5 minutes

      let trustDelta = 0;
      let trustReason = '';

      if (isSpamming) {
        // 🚨 SPAM DETECTION: -20 points for excessive requests
        trustDelta = -20;
        trustReason = `Spam detection: ${recentSpamRequests.length} requests in 5 minutes`;
      } else if (isAppropriateProgression) {
        // ✅ APPROPRIATE REQUEST: +5 points for reasonable progression
        trustDelta = 5;
        trustReason = `Appropriate reveal request: ${currentLevel}% → ${requestedLevel}%`;
      }
      // No points for inappropriate but non-spam requests (e.g., jumping too many levels)

      const consentData = insertConsentSchema.parse({
        roomId: authReq.user.roomId,
        fromUserId: authReq.user.userId,
        toUserId: targetUserId,
        levelRequested: level,
        status: 'pending'
      });

      const consent = await storage.createConsent(consentData);

      // 🎯 AUTOMATIC TRUST SCORING: Award/deduct points based on request appropriateness
      if (trustDelta !== 0) {
        try {
          await awardTrustPoints(
            authReq.user.roomId,
            authReq.user.userId,
            trustDelta,
            trustReason
          );
        } catch (trustError) {
          console.error('Failed to award trust points for request:', trustError);
          // Don't fail the main operation if trust scoring fails
        }
      }
      
      res.json({ 
        ok: true, 
        consentId: consent.id,
        message: `Reveal request sent for level ${level}%`,
        trustDelta: trustDelta !== 0 ? trustDelta : undefined // Include trust change in response
      });
    } catch (error) {
      console.error('Reveal request error:', error);
      res.status(500).json({ error: 'Failed to create reveal request' });
    }
  });

  // Approve/deny a reveal request
  app.post('/api/pirp/reveal/decide', requireRoomAccess, async (req, res) => {
    try {
      const authReq = req as AuthenticatedRequest;
      const { consentId, approve } = req.body;
      
      if (!consentId || typeof approve !== 'boolean') {
        return res.status(400).json({ error: 'consentId and approve (boolean) required' });
      }

      const consent = await storage.getConsent(consentId);
      if (!consent || consent.toUserId !== authReq.user.userId) {
        return res.status(404).json({ error: 'Consent not found or unauthorized' });
      }

      const status = approve ? 'approved' : 'rejected';
      const updatedConsent = await storage.updateConsentStatus(consentId, status);

      if (approve && updatedConsent) {
        // Update participant's current level
        const participants = await storage.getParticipantsByRoom(authReq.user.roomId);
        const fromParticipant = participants.find(p => p.userId === consent.fromUserId);
        const toParticipant = participants.find(p => p.userId === consent.toUserId);

        if (fromParticipant && toParticipant) {
          // Update both participants to the approved level
          await storage.updateParticipant(fromParticipant.id, { currentLevel: consent.levelRequested });
          await storage.updateParticipant(toParticipant.id, { currentLevel: consent.levelRequested });

          // Log the reveal event
          await storage.createRevealLog({
            roomId: authReq.user.roomId,
            userId: consent.fromUserId,
            level: consent.levelRequested,
            approvedBy: authReq.user.userId
          });

          // 🎯 AUTOMATIC TRUST SCORING: Award +10 points for approving consent
          try {
            await awardTrustPoints(
              authReq.user.roomId,
              authReq.user.userId, // Person who approved gets the points
              10,
              `Granted consent for ${consent.levelRequested}% reveal level`
            );
          } catch (trustError) {
            console.error('Failed to award trust points for consent approval:', trustError);
            // Don't fail the main operation if trust scoring fails
          }
        }
      }

      res.json({ 
        ok: true, 
        decision: status,
        level: approve ? consent.levelRequested : null
      });
    } catch (error) {
      console.error('Reveal decision error:', error);
      res.status(500).json({ error: 'Failed to process reveal decision' });
    }
  });

  // Helper function to award trust points automatically
  async function awardTrustPoints(
    roomId: string, 
    targetUserId: string, 
    delta: number, 
    reason: string
  ): Promise<{ newScore: number; milestone: number | null }> {
    // Get current participant to calculate new score
    const participants = await storage.getParticipantsByRoom(roomId);
    const targetParticipant = participants.find(p => p.userId === targetUserId);
    
    if (!targetParticipant) {
      throw new Error('Target participant not found');
    }

    const currentScore = targetParticipant.trustScore || 0;
    const newScore = Math.max(0, currentScore + delta); // Don't allow negative scores

    // Create trust event
    await storage.createTrustEvent({
      roomId,
      userId: targetUserId,
      delta,
      reason,
      newScore
    });

    // Update participant's trust score
    await storage.updateParticipant(targetParticipant.id, { trustScore: newScore });

    // Check if reached milestone (25/50/75/100)
    const milestones = [25, 50, 75, 100];
    const reachedMilestone = milestones.find(milestone => 
      currentScore < milestone && newScore >= milestone
    );

    return { newScore, milestone: reachedMilestone || null };
  }

  // Add trust score event (manual endpoint)
  app.post('/api/pirp/trust/add', requireRoomAccess, async (req, res) => {
    try {
      const authReq = req as AuthenticatedRequest;
      const { targetUserId, delta, reason } = req.body;
      
      if (!targetUserId || typeof delta !== 'number' || !reason) {
        return res.status(400).json({ error: 'targetUserId, delta (number), and reason required' });
      }

      // Get current participant to calculate new score
      const participants = await storage.getParticipantsByRoom(authReq.user.roomId);
      const targetParticipant = participants.find(p => p.userId === targetUserId);
      
      if (!targetParticipant) {
        return res.status(404).json({ error: 'Target participant not found' });
      }

      const currentScore = targetParticipant.trustScore || 0;
      const newScore = Math.max(0, currentScore + delta); // Don't allow negative scores

      // Create trust event
      const trustEvent = await storage.createTrustEvent({
        roomId: authReq.user.roomId,
        userId: targetUserId,
        delta,
        reason,
        newScore
      });

      // Update participant's trust score
      await storage.updateParticipant(targetParticipant.id, { trustScore: newScore });

      // Check if reached milestone (25/50/75/100)
      const milestones = [25, 50, 75, 100];
      const reachedMilestone = milestones.find(milestone => 
        currentScore < milestone && newScore >= milestone
      );

      res.json({ 
        ok: true, 
        newScore,
        milestone: reachedMilestone || null,
        delta,
        reason
      });
    } catch (error) {
      console.error('Trust score error:', error);
      res.status(500).json({ error: 'Failed to update trust score' });
    }
  });

  // Get pending consent requests for current user
  app.get('/api/pirp/requests', requireRoomAccess, async (req, res) => {
    try {
      const authReq = req as AuthenticatedRequest;
      
      // Get pending consents that need this user's decision
      const pendingConsents = await storage.getPendingConsentsForUser(authReq.user.userId);
      
      // Transform to format expected by frontend
      const requests = pendingConsents.map(consent => ({
        requestId: consent.id,
        requesterId: consent.fromUserId,
        requesterName: `User ${consent.fromUserId}`, // TODO: Get actual username
        currentLevel: 0, // TODO: Get from participant data
        requestedLevel: consent.levelRequested,
        timestamp: consent.createdAt?.toISOString() || new Date().toISOString(),
        expiresAt: new Date(Date.now() + 5 * 60 * 1000).toISOString() // 5 minutes from now
      }));
      
      res.json(requests);
    } catch (error) {
      console.error('PIRP requests error:', error);
      res.status(500).json({ error: 'Failed to get pending requests' });
    }
  });

  // Get PIRP status for current user in room
  app.get('/api/pirp/status', requireRoomAccess, async (req, res) => {
    try {
      const authReq = req as AuthenticatedRequest;
      
      // Get participants in room
      const participants = await storage.getParticipantsByRoom(authReq.user.roomId);
      const currentParticipant = participants.find(p => p.userId === authReq.user.userId);
      const otherParticipants = participants.filter(p => p.userId !== authReq.user.userId);
      
      // Get pending consents for user
      const pendingConsents = await storage.getPendingConsentsForUser(authReq.user.userId);
      
      // Get recent trust events
      const trustEvents = await storage.getTrustEventsByUser(authReq.user.userId, authReq.user.roomId);
      
      res.json({
        // Legacy fields
        currentLevel: currentParticipant?.currentLevel || 0,
        trustScore: currentParticipant?.trustScore || 0,
        role: currentParticipant?.role || 'participant',
        pendingConsents: pendingConsents.length,
        recentTrustEvents: trustEvents.slice(-5), // Last 5 events
        
        // Frontend expected fields for reveal levels
        localRevealLevel: currentParticipant?.currentLevel || 0,
        remoteRevealLevel: otherParticipants[0]?.currentLevel || 0 // First other participant
      });
    } catch (error) {
      console.error('PIRP status error:', error);
      res.status(500).json({ error: 'Failed to get PIRP status' });
    }
  });

  // Get reveal audit logs for room (host-only for compliance)
  app.get('/api/pirp/audit/reveals', requireRoomAccess, requireHostRole, async (req, res) => {
    try {
      const authReq = req as AuthenticatedRequest;
      const revealLogs = await storage.getRevealLogsByRoom(authReq.user.roomId);
      
      res.json({
        roomId: authReq.user.roomId,
        totalReveals: revealLogs.length,
        logs: revealLogs.sort((a, b) => 
          new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime()
        )
      });
    } catch (error) {
      console.error('Reveal audit error:', error);
      res.status(500).json({ error: 'Failed to get reveal audit logs' });
    }
  });

  return httpServer;
}
