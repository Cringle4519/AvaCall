import jwt from 'jsonwebtoken';
import type { Request, Response, NextFunction } from 'express';

const JWT_SECRET = process.env.JWT_SECRET || process.env.SESSION_SECRET;

if (!JWT_SECRET) {
  throw new Error('JWT_SECRET or SESSION_SECRET environment variable is required for secure token generation');
}

// Type assertion since we've validated the secret exists
const secret: string = JWT_SECRET;
export type Role = 'host' | 'guest';
export type TokenClaims = { sub: string; roomId: string; role: Role; iat: number; exp: number };

export interface JWTPayload {
  id: string;
  roomId: string;
  userId: string;
  role: 'host' | 'guest';
}

// Update the request interface to be compatible with existing simple auth
export interface AuthenticatedRequest extends Request {
  user?: JWTPayload;
}

// New bundle-compatible functions
export function signJoinToken(userId: string, roomId: string, role: Role, ttlSec = 60 * 60) {
  return jwt.sign({ sub: userId, roomId, role } as Partial<TokenClaims>, secret, { expiresIn: ttlSec });
}

export function requireAuth(req: Request & { user?: any }, res: Response, next: NextFunction) {
  const hdr = req.headers.authorization || '';
  const m = /^Bearer\s+(.+)$/.exec(hdr);
  if (!m) return res.status(401).json({ error: 'missing_token' });
  try {
    const claims = jwt.verify(m[1], secret) as TokenClaims;
    req.user = { 
      id: claims.sub, 
      roomId: claims.roomId, 
      userId: claims.sub, 
      role: claims.role
    };
    next();
  } catch {
    return res.status(401).json({ error: 'invalid_token' });
  }
}

export function requireRole(role: Role) {
  return (req: Request & { user?: any }, res: Response, next: NextFunction) => {
    if (req.user?.role !== role) return res.status(403).json({ error: 'forbidden' });
    next();
  };
}

// Existing legacy functions for compatibility
export function generateJWT(payload: JWTPayload): string {
  return jwt.sign(payload, secret, { 
    expiresIn: '2h',
    issuer: 'avacall-pirp'
  });
}

export function verifyJWT(token: string): JWTPayload {
  return jwt.verify(token, secret, { issuer: 'avacall-pirp' }) as JWTPayload;
}

export function authMiddleware(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Missing or invalid authorization header' });
    return;
  }
  
  const token = authHeader.substring(7); // Remove 'Bearer ' prefix
  
  try {
    const decoded = verifyJWT(token);
    (req as AuthenticatedRequest).user = decoded;
    next();
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      res.status(401).json({ error: 'Token expired' });
    } else if (error instanceof jwt.JsonWebTokenError) {
      res.status(401).json({ error: 'Invalid token' });
    } else {
      res.status(500).json({ error: 'Authentication error' });
    }
  }
}

export function requireRoomAccess(req: Request, res: Response, next: NextFunction): void {
  const authReq = req as AuthenticatedRequest;
  
  if (!authReq.user || !authReq.user.roomId) {
    res.status(401).json({ error: 'Invalid token: missing room scope' });
    return;
  }
  
  next();
}

export function requireHostRole(req: Request, res: Response, next: NextFunction): void {
  const authReq = req as AuthenticatedRequest;
  
  if (!authReq.user || authReq.user.role !== 'host') {
    res.status(403).json({ error: 'Host role required for this operation' });
    return;
  }
  
  next();
}