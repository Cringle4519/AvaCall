import { Request, Response, NextFunction } from 'express';

const ALLOW_ORIGIN = process.env.APP_ORIGIN ?? '*'; // set your domain when you have it

// Simple per-IP in-memory limiter (route-scoped)
type Bucket = { count: number; resetAt: number };
const buckets: Record<string, Bucket> = {};
function key(req: Request) { return `${req.ip}:${req.path}`; }

export function rateLimit(max = 30, windowMs = 60_000) {
  return (req: Request, res: Response, next: NextFunction) => {
    const k = key(req);
    const now = Date.now();
    const b = buckets[k] ?? (buckets[k] = { count: 0, resetAt: now + windowMs });
    if (now > b.resetAt) { b.count = 0; b.resetAt = now + windowMs; }
    b.count++;
    if (b.count > max) return res.status(429).json({ error: 'rate_limited', retryIn: b.resetAt - now });
    next();
  };
}

export function corsTight(req: Request, res: Response, next: NextFunction) {
  res.header('Vary', 'Origin');
  res.header('Access-Control-Allow-Origin', ALLOW_ORIGIN);
  res.header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-user-id');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
}

export function cspTight(_: Request, res: Response, next: NextFunction) {
  // Adjust image/audio CDNs you use below
  const img = "img-src 'self' data: https://images.unsplash.com https://cdn.pixabay.com;";
  const media = "media-src 'self' https://cdn.pixabay.com;";
  const def = "default-src 'self';";
  const con = "connect-src 'self' wss: https:;";
  const scr = "script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';";
  res.setHeader('Content-Security-Policy', [def, con, img, media, scr].join(' '));
  next();
}