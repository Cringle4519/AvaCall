import { Router, Request } from 'express';
import crypto from 'crypto';

// Extend Express Request type to include user
declare global {
  namespace Express {
    interface Request {
      user?: { id: string };
    }
  }
}

type Room = {
  id: string;
  hostId: string;
  waiting: string[];   // userIds knocking
  allowed: Set<string>; // admitted userIds
};
const rooms: Record<string, Room> = {};
const router = Router();

// Create a room & return invite URL
router.post('/room', (req, res) => {
  const hostId = String(req.user?.id ?? 'host'); // set by your auth middleware
  const id = crypto.randomUUID().slice(0, 8);
  rooms[id] = { id, hostId, waiting: [], allowed: new Set([hostId]) };
  const origin = process.env.APP_ORIGIN || 'http://localhost:5000';
  res.json({ roomId: id, invite: `${origin}/room/${id}` });
});

// Knock to join
router.post('/room/:id/knock', (req, res) => {
  const room = rooms[req.params.id];
  if (!room) return res.status(404).json({ error: 'room_not_found' });
  const userId = String(req.user?.id ?? 'guest-' + crypto.randomUUID().slice(0,4));
  if (!room.waiting.includes(userId) && !room.allowed.has(userId)) room.waiting.push(userId);
  res.json({ ok: true, queued: true });
});

// Host decision
router.post('/room/:id/decide', (req, res) => {
  const room = rooms[req.params.id];
  if (!room) return res.status(404).json({ error: 'room_not_found' });
  const hostId = String(req.user?.id ?? '');
  if (hostId !== room.hostId) return res.status(403).json({ error: 'not_host' });
  const { userId, approve } = req.body as { userId: string; approve: boolean };
  room.waiting = room.waiting.filter(u => u !== userId);
  if (approve) room.allowed.add(userId);
  res.json({ ok: true, approved: approve });
});

// Check admission (client polls before connecting)
router.get('/room/:id/status', (req, res) => {
  const room = rooms[req.params.id];
  if (!room) return res.status(404).json({ error: 'room_not_found' });
  const userId = String(req.user?.id ?? '');
  res.json({ allowed: room.allowed.has(userId), waiting: room.waiting.includes(userId) });
});

export default router;