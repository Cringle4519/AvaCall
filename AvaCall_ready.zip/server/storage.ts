import { 
  type User, type InsertUser, type Room, type InsertRoom, type Participant, type InsertParticipant,
  type Consent, type InsertConsent, type TrustEvent, type InsertTrustEvent, type RevealLog, type InsertRevealLog,
  type ChatMessage, type InsertChatMessage, type UserAvatar, type InsertUserAvatar
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getRoom(id: string): Promise<Room | undefined>;
  createRoom(room: InsertRoom): Promise<Room>;
  getRoomsByUser(userId: string): Promise<Room[]>;
  
  getParticipant(id: string): Promise<Participant | undefined>;
  createParticipant(participant: InsertParticipant): Promise<Participant>;
  getParticipantsByRoom(roomId: string): Promise<Participant[]>;
  updateParticipant(id: string, updates: Partial<Participant>): Promise<Participant | undefined>;
  removeParticipant(id: string): Promise<void>;

  // PIRP consent management
  getConsent(id: string): Promise<Consent | undefined>;
  createConsent(consent: InsertConsent): Promise<Consent>;
  getConsentsByRoom(roomId: string): Promise<Consent[]>;
  getPendingConsentsForUser(userId: string): Promise<Consent[]>;
  getConsentsByFromUser(userId: string): Promise<Consent[]>;
  updateConsentStatus(id: string, status: 'approved' | 'rejected'): Promise<Consent | undefined>;

  // PIRP trust events
  createTrustEvent(event: InsertTrustEvent): Promise<TrustEvent>;
  getTrustEventsByUser(userId: string, roomId: string): Promise<TrustEvent[]>;
  
  // PIRP reveal logs
  createRevealLog(log: InsertRevealLog): Promise<RevealLog>;
  getRevealLogsByRoom(roomId: string): Promise<RevealLog[]>;

  // Chat messages
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  getChatMessagesByRoom(roomId: string): Promise<ChatMessage[]>;

  // Avatar management
  getUserAvatar(userId: string): Promise<UserAvatar | undefined>;
  createUserAvatar(avatar: InsertUserAvatar): Promise<UserAvatar>;
  updateUserAvatar(userId: string, updates: Partial<UserAvatar>): Promise<UserAvatar | undefined>;
  deleteUserAvatar(userId: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private rooms: Map<string, Room>;
  private participants: Map<string, Participant>;
  private consents: Map<string, Consent>;
  private trustEvents: Map<string, TrustEvent>;
  private revealLogs: Map<string, RevealLog>;
  private chatMessages: Map<string, ChatMessage>;
  private userAvatars: Map<string, UserAvatar>;

  constructor() {
    this.users = new Map();
    this.rooms = new Map();
    this.participants = new Map();
    this.consents = new Map();
    this.trustEvents = new Map();
    this.revealLogs = new Map();
    this.chatMessages = new Map();
    this.userAvatars = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getRoom(id: string): Promise<Room | undefined> {
    return this.rooms.get(id);
  }

  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const id = randomUUID();
    const room: Room = { 
      id,
      name: insertRoom.name,
      createdBy: insertRoom.createdBy || null,
      createdAt: new Date(),
      isActive: true
    };
    this.rooms.set(id, room);
    return room;
  }

  async getRoomsByUser(userId: string): Promise<Room[]> {
    return Array.from(this.rooms.values()).filter(
      (room) => room.createdBy === userId
    );
  }

  async getParticipant(id: string): Promise<Participant | undefined> {
    return this.participants.get(id);
  }

  async createParticipant(insertParticipant: InsertParticipant): Promise<Participant> {
    const id = randomUUID();
    const participant: Participant = {
      id,
      roomId: insertParticipant.roomId || null,
      userId: insertParticipant.userId || null,
      joinedAt: new Date(),
      leftAt: null,
      isActive: true,
      role: insertParticipant.role || "participant",
      currentLevel: insertParticipant.currentLevel || 0,
      trustScore: insertParticipant.trustScore || 0
    };
    this.participants.set(id, participant);
    return participant;
  }

  async getParticipantsByRoom(roomId: string): Promise<Participant[]> {
    return Array.from(this.participants.values()).filter(
      (participant) => participant.roomId === roomId && participant.isActive
    );
  }

  async updateParticipant(id: string, updates: Partial<Participant>): Promise<Participant | undefined> {
    const participant = this.participants.get(id);
    if (participant) {
      const updated = { ...participant, ...updates };
      this.participants.set(id, updated);
      return updated;
    }
    return undefined;
  }

  async removeParticipant(id: string): Promise<void> {
    const participant = this.participants.get(id);
    if (participant) {
      participant.isActive = false;
      participant.leftAt = new Date();
      this.participants.set(id, participant);
    }
  }

  // PIRP consent management
  async getConsent(id: string): Promise<Consent | undefined> {
    return this.consents.get(id);
  }

  async createConsent(insertConsent: InsertConsent): Promise<Consent> {
    const id = randomUUID();
    const consent: Consent = {
      id,
      roomId: insertConsent.roomId || null,
      fromUserId: insertConsent.fromUserId || null,
      toUserId: insertConsent.toUserId || null,
      levelRequested: insertConsent.levelRequested,
      status: insertConsent.status || "pending",
      createdAt: new Date(),
      decidedAt: null
    };
    this.consents.set(id, consent);
    return consent;
  }

  async getConsentsByRoom(roomId: string): Promise<Consent[]> {
    return Array.from(this.consents.values()).filter(
      (consent) => consent.roomId === roomId
    );
  }

  async getPendingConsentsForUser(userId: string): Promise<Consent[]> {
    return Array.from(this.consents.values()).filter(
      (consent) => consent.toUserId === userId && consent.status === "pending"
    );
  }

  async getConsentsByFromUser(userId: string): Promise<Consent[]> {
    return Array.from(this.consents.values()).filter(
      (consent) => consent.fromUserId === userId
    );
  }

  async updateConsentStatus(id: string, status: 'approved' | 'rejected'): Promise<Consent | undefined> {
    const consent = this.consents.get(id);
    if (consent) {
      consent.status = status;
      consent.decidedAt = new Date();
      this.consents.set(id, consent);
      return consent;
    }
    return undefined;
  }

  // PIRP trust events
  async createTrustEvent(insertEvent: InsertTrustEvent): Promise<TrustEvent> {
    const id = randomUUID();
    const event: TrustEvent = {
      id,
      roomId: insertEvent.roomId || null,
      userId: insertEvent.userId || null,
      delta: insertEvent.delta,
      reason: insertEvent.reason,
      newScore: insertEvent.newScore,
      timestamp: new Date()
    };
    this.trustEvents.set(id, event);
    return event;
  }

  async getTrustEventsByUser(userId: string, roomId: string): Promise<TrustEvent[]> {
    return Array.from(this.trustEvents.values()).filter(
      (event) => event.userId === userId && event.roomId === roomId
    );
  }

  // PIRP reveal logs
  async createRevealLog(insertLog: InsertRevealLog): Promise<RevealLog> {
    const id = randomUUID();
    const log: RevealLog = {
      id,
      roomId: insertLog.roomId || null,
      userId: insertLog.userId || null,
      level: insertLog.level,
      approvedBy: insertLog.approvedBy || null,
      timestamp: new Date()
    };
    this.revealLogs.set(id, log);
    return log;
  }

  async getRevealLogsByRoom(roomId: string): Promise<RevealLog[]> {
    return Array.from(this.revealLogs.values()).filter(
      (log) => log.roomId === roomId
    );
  }

  // Chat messages
  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const message: ChatMessage = {
      id,
      roomId: insertMessage.roomId || null,
      userId: insertMessage.userId || null,
      message: insertMessage.message,
      messageType: insertMessage.messageType || "text",
      timestamp: new Date()
    };
    this.chatMessages.set(id, message);
    return message;
  }

  async getChatMessagesByRoom(roomId: string): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter((message) => message.roomId === roomId)
      .sort((a, b) => (a.timestamp?.getTime() || 0) - (b.timestamp?.getTime() || 0));
  }

  // Avatar management methods
  async getUserAvatar(userId: string): Promise<UserAvatar | undefined> {
    return Array.from(this.userAvatars.values()).find(
      (avatar) => avatar.userId === userId && avatar.isActive,
    );
  }

  async createUserAvatar(insertAvatar: InsertUserAvatar): Promise<UserAvatar> {
    if (!insertAvatar.userId) {
      throw new Error('userId is required');
    }
    
    // Mark other avatars as inactive for this user
    const existingAvatars = Array.from(this.userAvatars.values())
      .filter(a => a.userId === insertAvatar.userId && a.isActive);
    existingAvatars.forEach(a => {
      this.userAvatars.set(a.id, { ...a, isActive: false });
    });
    
    const id = randomUUID();
    const avatar: UserAvatar = {
      id,
      userId: insertAvatar.userId,
      avatarType: insertAvatar.avatarType,
      avatarUrl: insertAvatar.avatarUrl,
      isActive: insertAvatar.isActive ?? true,
      createdAt: new Date(),
    };
    this.userAvatars.set(id, avatar);
    return avatar;
  }

  async updateUserAvatar(userId: string, updates: Partial<UserAvatar>): Promise<UserAvatar | undefined> {
    const avatar = await this.getUserAvatar(userId);
    if (!avatar) return undefined;

    const updated = { ...avatar, ...updates };
    this.userAvatars.set(avatar.id, updated);
    return updated;
  }

  async deleteUserAvatar(userId: string): Promise<void> {
    const avatar = await this.getUserAvatar(userId);
    if (avatar) {
      this.userAvatars.delete(avatar.id);
    }
  }
}

export const storage = new MemStorage();
