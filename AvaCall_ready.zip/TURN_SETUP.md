# TURN Server Setup for AvaCall

## Quick Start

```bash
# Start TURN server
docker compose up -d

# Check logs
docker compose logs -f turn

# Stop TURN server  
docker compose down
```

## Configuration

- **TURN/STUN ports**: 3478 (UDP/TCP)
- **TURNS port**: 5349 (UDP/TCP) - requires TLS certs for production
- **Media ports**: 49152-50000 (UDP) - expanded range for better throughput
- **Credentials**: turnuser / turnpass (replace with TURN REST for production)
- **Realm**: avacall.turn

## Production Setup (CRITICAL)

### 1. TLS Configuration
Add TLS certificates to `turnserver.conf`:
```
cert=/path/to/your/certificate.pem
pkey=/path/to/your/private.key
# Remove the no-tls and no-dtls lines
```

### 2. Domain Configuration
Replace `localhost` with your domain in `client/src/pages/video-call.tsx`:
```javascript
urls: [
  'turn:your.domain:3478?transport=udp',
  'turn:your.domain:3478?transport=tcp', 
  'turns:your.domain:5349?transport=tcp'
]
```

### 3. External IP Setup
Update `turnserver.conf` with your server's public IP:
```
external-ip=YOUR_PUBLIC_IP
# Remove auto-ip line
```

### 4. Security (MANDATORY)
- Implement TURN REST API for time-limited credentials
- Set up `static-auth-secret` in coturn
- Generate HMAC-based temporary credentials server-side
- Remove static credentials from client code

### 5. Environment Variables

**Development (.env.local):**
```bash
VITE_TURN_SERVER=localhost
VITE_TURN_USERNAME=turnuser
VITE_TURN_PASSWORD=turnpass
VITE_TURN_ENABLE_TLS=false
```

**Production (.env.production):**
```bash
VITE_TURN_SERVER=turn.your-domain.com
VITE_TURN_USERNAME=your_username
VITE_TURN_PASSWORD=your_password
VITE_TURN_ENABLE_TLS=true
```

### 6. Firewall Rules
Open these ports on your server:
- 3478 (UDP/TCP) - STUN/TURN
- 5349 (UDP/TCP) - TURNS (secure)
- 49152-50000 (UDP) - Media relay

## Development vs Production

### Development (Current)
- Uses localhost URLs (configurable via VITE_TURN_SERVER)
- TLS disabled (no-tls, no-dtls) for simplicity
- Static credentials (secure for localhost only)
- Port range: 49152-50000 (aligned with Docker)

### Production Requirements (CRITICAL)
- Domain-based URLs via VITE_TURN_SERVER environment variable
- TLS certificates for TURNS (enable with VITE_TURN_ENABLE_TLS=true)
- TURN REST API for secure credential generation (replaces static credentials)
- External IP configuration (external-ip=PUBLIC_IP in turnserver.conf)
- Rate limiting and monitoring enabled
- Port range: 49152-50000 (properly aligned)

## Testing Connectivity

Test WebRTC connectivity at: https://webrtc.github.io/samples/src/content/peerconnection/trickle-ice/

The TURN server dramatically improves connection reliability for users behind:
- Corporate firewalls and NATs (up to 90% success rate)
- Hotel/public WiFi with restrictions  
- Mobile networks with symmetric NATs
- Home routers with strict firewall settings

Expected improvement: ~50% more successful connections in real-world networks.