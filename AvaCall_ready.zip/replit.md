# AvaCall - Video Calling Application

## Overview

This is a modern video calling application built with React on the frontend and Express.js on the backend. The application provides WebRTC-powered video conferencing capabilities with virtual backgrounds, avatar overlays, screen sharing, in-call chat, and real-time communication features. Users can create or join video call rooms, customize their appearance with various backgrounds and avatars, share their screen with participants, send chat messages during calls, and participate in peer-to-peer video calls.

## Recent Changes

### Screen Sharing and In-Call Chat Features (September 22, 2025)
- **Screen Sharing Integration**: Added comprehensive screen sharing functionality using the getDisplayMedia() API with WebRTC track replacement. Users can now share their entire screen or specific application windows during video calls.
- **In-Call Chat System**: Implemented real-time chat messaging system with WebSocket-based communication and database persistence. Users can send and receive chat messages during video calls with message history.
- **Enhanced UI Components**: Created new React components (InCallChat, ScreenShareToggle) with proper TypeScript integration, accessibility features, and test IDs for automated testing.
- **Database Schema Extension**: Added chatMessages table to support persistent chat history with room and user associations.
- **WebSocket Message Handling**: Extended existing WebSocket infrastructure to handle 'chat-message' events for real-time chat communication between participants.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side application is built using React with TypeScript and follows a component-based architecture:

**UI Framework**: Uses shadcn/ui components built on Radix UI primitives for consistent, accessible interface elements. The design system leverages Tailwind CSS for styling with a dark theme configuration.

**State Management**: Utilizes React hooks and context for local state management, with TanStack Query for server state and caching. Custom hooks like `useWebRTC` and `useWebSocket` encapsulate complex functionality.

**Routing**: Implements client-side routing using Wouter, a lightweight React router. Routes include the main video call interface and room-specific URLs.

**Video Processing**: Implements canvas-based video processing for virtual backgrounds and avatar overlays through dedicated classes (`VirtualBackground`, `AvatarOverlay`) that manipulate video streams in real-time.

### Backend Architecture
The server-side follows a REST API pattern with WebSocket integration:

**Web Framework**: Express.js server handling HTTP requests and serving the React application in production. Includes middleware for request logging and error handling.

**WebSocket Server**: Dedicated WebSocket server for real-time signaling required for WebRTC peer connections. Handles room management, user joining/leaving, and WebRTC signaling messages.

**Storage Layer**: Abstracted storage interface (`IStorage`) with an in-memory implementation (`MemStorage`) for development. The schema supports users, rooms, and participants with proper relationships.

**WebRTC Signaling**: Implements a complete WebRTC signaling flow including offer/answer exchange and ICE candidate handling through WebSocket messages.

### Data Storage Solutions
**Database**: Configured to use PostgreSQL with Drizzle ORM for production deployments. The schema includes tables for users, rooms, and participants with proper foreign key relationships.

**Development Storage**: In-memory storage implementation for development and testing, providing the same interface as the database layer.

**Session Management**: Uses connect-pg-simple for PostgreSQL-backed session storage in production environments.

### Authentication and Authorization
The application includes user management infrastructure with username/password authentication schema, though the current implementation focuses on room-based access rather than strict user authentication.

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL database using `@neondatabase/serverless` driver
- **Drizzle ORM**: Type-safe database operations with PostgreSQL dialect
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### UI and Styling
- **Radix UI**: Comprehensive set of accessible UI primitives including dialogs, buttons, and form components
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Lucide React**: Icon library providing consistent iconography
- **shadcn/ui**: Pre-built component library combining Radix UI with Tailwind styling

### Real-time Communication
- **WebSocket (ws)**: Native WebSocket implementation for signaling server
- **WebRTC APIs**: Browser-native WebRTC for peer-to-peer video/audio communication
- **MediaStream APIs**: Browser APIs for camera and microphone access

### Development and Build Tools
- **Vite**: Modern build tool with HMR support and optimized production builds
- **TypeScript**: Type safety across the entire application
- **ESBuild**: Fast JavaScript bundler for server-side code
- **React Router (Wouter)**: Lightweight client-side routing

### Form Handling and Validation
- **React Hook Form**: Performant form library with validation
- **Zod**: TypeScript-first schema validation
- **@hookform/resolvers**: Integration between React Hook Form and Zod

### State Management
- **TanStack React Query**: Server state management with caching and synchronization
- **React Context**: Built-in state management for component trees